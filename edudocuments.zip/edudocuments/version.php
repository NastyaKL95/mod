<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_edudocuments';
$plugin->version   = 2026102700;
$plugin->requires  = 2026100500; // Moodle 5.3.0+.
$plugin->supported = [503, 503];
$plugin->incompatible = 504;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '5.3.0';
