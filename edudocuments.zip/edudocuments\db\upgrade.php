<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_edudocuments_upgrade($oldversion) {
    if ($oldversion < 2024051504) {
        require_once(__DIR__ . '/../lib.php');
        local_edudocuments_refresh_legacy_templates();
        upgrade_plugin_savepoint(true, 2024051504, 'local', 'edudocuments');
    }

    if ($oldversion < 2024051505) {
        upgrade_plugin_savepoint(true, 2024051505, 'local', 'edudocuments');
    }

    if ($oldversion < 2024051506) {
        require_once(__DIR__ . '/../lib.php');
        local_edudocuments_refresh_legacy_templates();
        upgrade_plugin_savepoint(true, 2024051506, 'local', 'edudocuments');
    }

    if ($oldversion < 2024051507) {
        require_once(__DIR__ . '/../lib.php');
        local_edudocuments_refresh_legacy_templates();
        upgrade_plugin_savepoint(true, 2024051507, 'local', 'edudocuments');
    }

    if ($oldversion < 2024051508) {
        require_once(__DIR__ . '/../lib.php');
        local_edudocuments_refresh_legacy_templates();
        upgrade_plugin_savepoint(true, 2024051508, 'local', 'edudocuments');
    }

    if ($oldversion < 2024051509) {
        require_once(__DIR__ . '/../lib.php');
        local_edudocuments_refresh_legacy_templates();
        upgrade_plugin_savepoint(true, 2024051509, 'local', 'edudocuments');
    }

    if ($oldversion < 2024051510) {
        require_once(__DIR__ . '/../lib.php');
        local_edudocuments_refresh_legacy_templates();
        upgrade_plugin_savepoint(true, 2024051510, 'local', 'edudocuments');
    }

    return true;
}
