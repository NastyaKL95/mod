<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Шаблоны заявления и договора';
$string['settingsintro'] = 'Здесь задаются HTML-шаблоны PDF для элементов курса «Заявление» и «Договор-оферта». Изменения применяются ко всем курсам. Оставьте поле пустым и сохраните — будет использоваться текст по умолчанию.';
$string['placeholdersheading'] = 'Подстановки в шаблонах';
$string['placeholderscontract'] = '<b>Договор:</b> {{program}} — название курса; {{hours_number}}, {{hours_propis}}, {{hours_label}} — объём программы (цифрами, прописью и «час»); {{representative}} — лицо исполнителя в п. 2.1; {{footer_columns}} — реквизиты и обучающийся.';
$string['placeholdersstatement'] = '<b>Заявление:</b> {{addressee}} — адресат; {{user_firstname}} — имя в шапке; {{listener_signature_block}} — имя, линия и ПЭП (после устава и в подтверждении); {{title}}, {{body_intro}}, {{about_header}}, {{learner_rows}}, {{charter}}, {{charter_date_line}}, {{confirm_header}}, {{agreed_header}}, {{agreed_body}}.';
$string['contracthtml'] = 'HTML-шаблон договора-оферты';
$string['contracthtml_help'] = 'Полный HTML-текст договора для PDF. Печать и подпись по-прежнему загружаются в настройках элемента курса «Договор».';
$string['statementhtml'] = 'HTML-шаблон заявления';
$string['statementhtml_help'] = 'HTML-шаблон заявления для PDF. Адресат, институт и руководитель курса по-прежнему задаются в настройках элемента курса «Заявление».';
$string['resetheading'] = 'Восстановить текст по умолчанию';
$string['resetcontract'] = 'Сбросить шаблон договора';
$string['resetstatement'] = 'Сбросить шаблон заявления';
$string['resetcontractconfirm'] = 'Сбросить сохранённый шаблон договора и использовать текст по умолчанию?';
$string['resetstatementconfirm'] = 'Сбросить сохранённый шаблон заявления и использовать текст по умолчанию?';
$string['resetcontractdone'] = 'Шаблон договора сброшен. Отображается текст по умолчанию.';
$string['resetstatementdone'] = 'Шаблон заявления сброшен. Отображается текст по умолчанию.';
