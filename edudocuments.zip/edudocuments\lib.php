<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * HTML-шаблон договора-оферты (из настроек сайта или файл по умолчанию).
 *
 * @return string
 */
function local_edudocuments_get_contract_template(): string {
    $default = local_edudocuments_default_contract_html();
    $saved = get_config('local_edudocuments', 'contracthtml');
    if (!is_string($saved) || trim($saved) === '') {
        return $default;
    }
    if (local_edudocuments_contract_template_is_legacy($saved)) {
        return $default;
    }
    return $saved;
}

/**
 * HTML-шаблон заявления (из настроек сайта или файл по умолчанию).
 *
 * @return string
 */
function local_edudocuments_get_statement_template(): string {
    $default = local_edudocuments_default_statement_html();
    $saved = get_config('local_edudocuments', 'statementhtml');
    if (!is_string($saved) || trim($saved) === '') {
        return $default;
    }
    if (local_edudocuments_statement_template_is_legacy($saved)) {
        return $default;
    }
    return $saved;
}

/**
 * Сохранённый шаблон заявления устарел (нет плейсхолдеров новой вёрстки PDF).
 *
 * @param string $html
 * @return bool
 */
function local_edudocuments_statement_template_is_legacy(string $html): bool {
    if (trim($html) === '') {
        return true;
    }
    $required = ['{{charter_date_line}}', '{{user_firstname}}'];
    foreach ($required as $token) {
        if (strpos($html, $token) === false) {
            return true;
        }
    }
    // Справа от даты после устава — имя, не полное ФИО.
    if (preg_match('/\{\{charter_date_line\}\}[\s\S]*?\{\{user_fullname\}\}/', $html)) {
        return true;
    }
    // Два отдельных div в шапке — неравномерные отступы при переносе.
    if (preg_match('/userstatement-pdf-header/', $html) === 0
        && preg_match('/\{\{addressee\}\}[\s\S]*?<\/div>\s*<div[^>]*>\s*\{\{user_firstname\}\}/', $html)) {
        return true;
    }
    if (strpos($html, '{{charter_date_line}}') !== false && strpos($html, 'line-height:0.75') === false) {
        return true;
    }
    if (strpos($html, '{{listener_signature_block}}') === false
        || strpos($html, '{{listener_signature_block_confirm}}') === false) {
        return true;
    }
    return false;
}

/**
 * @param string $html
 * @return bool
 */
function local_edudocuments_contract_template_is_legacy(string $html): bool {
    return trim($html) === '';
}

/**
 * Обновить устаревшие шаблоны в config из файлов defaults/ (после обновления плагина).
 */
function local_edudocuments_refresh_legacy_templates(): void {
    $savedstatement = get_config('local_edudocuments', 'statementhtml');
    if (!is_string($savedstatement) || local_edudocuments_statement_template_is_legacy($savedstatement)) {
        set_config('statementhtml', local_edudocuments_default_statement_html(), 'local_edudocuments');
    }
    $savedcontract = get_config('local_edudocuments', 'contracthtml');
    if (!is_string($savedcontract) || local_edudocuments_contract_template_is_legacy($savedcontract)) {
        set_config('contracthtml', local_edudocuments_default_contract_html(), 'local_edudocuments');
    }
    set_config('templatebuild', 2024051510, 'local_edudocuments');
}

/**
 * @return string
 */
function local_edudocuments_default_contract_html(): string {
    return local_edudocuments_read_default_file('contract.html');
}

/**
 * @return string
 */
function local_edudocuments_default_statement_html(): string {
    return local_edudocuments_read_default_file('statement.html');
}

/**
 * Сбросить сохранённый шаблон к тексту по умолчанию.
 *
 * @param string $type contract|statement
 */
function local_edudocuments_reset_template(string $type): void {
    if ($type === 'contract') {
        unset_config('contracthtml', 'local_edudocuments');
    } else if ($type === 'statement') {
        unset_config('statementhtml', 'local_edudocuments');
    }
}

/**
 * @param string $filename
 * @return string
 */
function local_edudocuments_read_default_file(string $filename): string {
    global $CFG;

    $path = __DIR__ . '/defaults/' . $filename;
    if (is_readable($path)) {
        return (string) file_get_contents($path);
    }

    if ($filename === 'contract.html') {
        $fallback = $CFG->dirroot . '/mod/usercontract/classes/local/contract_static.html';
        if (is_readable($fallback)) {
            return (string) file_get_contents($fallback);
        }
    }

    return '';
}
