<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$type = required_param('type', PARAM_ALPHA);
if (!in_array($type, ['contract', 'statement'], true)) {
    throw new moodle_exception('invalidparameter');
}

$confirm = optional_param('confirm', 0, PARAM_INT);
$PAGE->set_url(new moodle_url('/local/edudocuments/reset.php', ['type' => $type]));
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');

if ($confirm) {
    require_sesskey();
    local_edudocuments_reset_template($type);
    redirect(
        new moodle_url('/admin/settings.php', ['section' => 'local_edudocuments']),
        get_string($type === 'contract' ? 'resetcontractdone' : 'resetstatementdone', 'local_edudocuments'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$stredit = get_string($type === 'contract' ? 'resetcontract' : 'resetstatement', 'local_edudocuments');
$PAGE->set_title($stredit);
$PAGE->set_heading($stredit);

echo $OUTPUT->header();
echo $OUTPUT->confirm(
    get_string($type === 'contract' ? 'resetcontractconfirm' : 'resetstatementconfirm', 'local_edudocuments'),
    new moodle_url('/local/edudocuments/reset.php', [
        'type' => $type,
        'confirm' => 1,
        'sesskey' => sesskey(),
    ]),
    new moodle_url('/admin/settings.php', ['section' => 'local_edudocuments'])
);
echo $OUTPUT->footer();
