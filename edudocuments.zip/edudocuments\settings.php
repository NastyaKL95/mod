<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    require_once(__DIR__ . '/lib.php');

    $settings = new admin_settingpage('local_edudocuments', get_string('pluginname', 'local_edudocuments'));

    $settings->add(new admin_setting_heading(
        'local_edudocuments/intro',
        '',
        get_string('settingsintro', 'local_edudocuments')
    ));

    $settings->add(new admin_setting_description(
        'local_edudocuments/placeholders',
        get_string('placeholdersheading', 'local_edudocuments'),
        get_string('placeholderscontract', 'local_edudocuments')
        . '<br/><br/>'
        . get_string('placeholdersstatement', 'local_edudocuments')
    ));

    $settings->add(new admin_setting_configtextarea(
        'local_edudocuments/contracthtml',
        get_string('contracthtml', 'local_edudocuments'),
        get_string('contracthtml_help', 'local_edudocuments'),
        local_edudocuments_default_contract_html(),
        PARAM_RAW,
        120,
        18
    ));

    $settings->add(new admin_setting_configtextarea(
        'local_edudocuments/statementhtml',
        get_string('statementhtml', 'local_edudocuments'),
        get_string('statementhtml_help', 'local_edudocuments'),
        local_edudocuments_default_statement_html(),
        PARAM_RAW,
        80,
        18
    ));

    $resetcontracturl = new moodle_url('/local/edudocuments/reset.php', ['type' => 'contract']);
    $resetstatementurl = new moodle_url('/local/edudocuments/reset.php', ['type' => 'statement']);
    $settings->add(new admin_setting_description(
        'local_edudocuments/reset',
        get_string('resetheading', 'local_edudocuments'),
        html_writer::link($resetcontracturl, get_string('resetcontract', 'local_edudocuments'))
        . ' | '
        . html_writer::link($resetstatementurl, get_string('resetstatement', 'local_edudocuments'))
    ));

    $ADMIN->add('localplugins', $settings);
}
