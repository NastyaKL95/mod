<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_edudocuments';
$plugin->version   = 2024051510;
$plugin->requires  = 2019111800; // Moodle 3.8.0+ (в т.ч. 3.8.4).
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0';
