<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_edudocuments';
$plugin->version   = 2026102700;
$plugin->requires  = 2024100700; // Moodle 4.5.0+.
$plugin->supported = [405, 405];
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '4.5.0';
