<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_usercontract';
$plugin->version   = 2026111800;
$plugin->requires  = 2024100700; // Moodle 4.5.0+.
$plugin->supported = [405, 405];
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '4.5.1';
