<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Перенос отметок «Проверено» в журнал оценок после обновления плагина.
 */
class sync_grades extends \core\task\adhoc_task {

    /**
     * @return string
     */
    public function get_name() {
        return get_string('tasksyncgrades', 'mod_userstatement');
    }

    /**
     * @return void
     */
    public function execute() {
        global $DB;

        require_once(__DIR__ . '/../../lib.php');

        $instances = $DB->get_records('userstatement');
        foreach ($instances as $instance) {
            if (!isset($instance->grade)) {
                $instance->grade = 100;
            }
            userstatement_update_grades($instance);
        }
    }
}
