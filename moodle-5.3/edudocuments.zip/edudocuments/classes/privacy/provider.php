<?php
// This file is part of Moodle - http://moodle.org/

namespace local_edudocuments\privacy;

/**
 * Плагин хранит только шаблоны документов в настройках сайта, персональных данных нет.
 */
class provider implements \core_privacy\local\metadata\null_provider {

    /**
     * @return string
     */
    public static function get_reason(): string {
        return 'privacy:metadata';
    }
}
