<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Statement and contract templates';
$string['settingsintro'] = 'Configure HTML templates for PDF output of the Statement and Contract offer activities. Changes apply site-wide. Leave a field empty and save to use the default text.';
$string['placeholdersheading'] = 'Template placeholders';
$string['placeholderscontract'] = '<b>Contract:</b> {{program}} — course name; {{hours_number}}, {{hours_propis}}, {{hours_label}} — program hours (digits, words, label); {{representative}} — signatory in clause 2.1; {{footer_columns}} — footer columns.';
$string['placeholdersstatement'] = '<b>Statement:</b> {{addressee}}, {{title}}, {{body_intro}}, {{about_header}}, {{learner_rows}}, {{charter}}, {{user_fullname}}, {{simple_sign}}, {{confirm_header}}, {{agreed_header}}, {{agreed_body}}.';
$string['contracthtml'] = 'Contract offer HTML template';
$string['contracthtml_help'] = 'Full contract HTML for PDF. Stamp and signature images are still set in each Contract activity.';
$string['statementhtml'] = 'Statement HTML template';
$string['statementhtml_help'] = 'Statement HTML for PDF. Addressee, institute and course leader are still set in each Statement activity.';
$string['resetheading'] = 'Restore default text';
$string['resetcontract'] = 'Reset contract template';
$string['resetstatement'] = 'Reset statement template';
$string['resetcontractconfirm'] = 'Reset the saved contract template to the default text?';
$string['resetstatementconfirm'] = 'Reset the saved statement template to the default text?';
$string['resetcontractdone'] = 'Contract template reset to default.';
$string['resetstatementdone'] = 'Statement template reset to default.';
$string['privacy:metadata'] = 'The plugin only stores document templates in site settings and does not store any personal data.';
