<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

$course = $DB->get_record('course', ['id' => $id], '*', MUST_EXIST);
require_course_login($course);

$PAGE->set_url('/mod/userstatement/index.php', ['id' => $id]);
$PAGE->set_title(format_string($course->shortname) . ': ' . get_string('modulenameplural', 'userstatement'));
$PAGE->set_heading($course->fullname);
$PAGE->set_pagelayout('incourse');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('modulenameplural', 'userstatement'));

$table = new html_table();
$table->head = [get_string('name'), get_string('moduleintro')];
$table->attributes['class'] = 'generaltable';
foreach (get_fast_modinfo($course)->get_instances_of('userstatement') as $cm) {
    if (!$cm->uservisible) {
        continue;
    }
    $inst = $DB->get_record('userstatement', ['id' => $cm->instance], 'id,name,intro,introformat', MUST_EXIST);
    $link = html_writer::link($cm->url, $cm->get_formatted_name());
    $intro = format_module_intro('userstatement', $inst, $cm->id);
    $table->data[] = [$link, $intro];
}
if (empty($table->data)) {
    echo $OUTPUT->notification(get_string('norecords', 'userstatement'), 'notifymessage');
} else {
    echo html_writer::table($table);
}

echo $OUTPUT->footer();
