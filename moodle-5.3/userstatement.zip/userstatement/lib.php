<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * Поддерживаемые возможности модуля.
 *
 * @param string $feature
 * @return mixed
 */
function userstatement_supports($feature) {
    switch ($feature) {
        case FEATURE_MOD_INTRO:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return false;
        case FEATURE_COMPLETION_HAS_RULES:
            return true;
        case FEATURE_GRADE_HAS_GRADE:
            return false;
        case FEATURE_BACKUP_MOODLE2:
            return false;
        case FEATURE_GROUPS:
            return true;
        case FEATURE_GROUPINGS:
            return true;
        default:
            return null;
    }
}

/**
 * @param stdClass $data
 * @return int id
 */
function userstatement_add_instance($data, $mform = null) {
    global $DB;

    $data->timemodified = time();
    $data->coursestart = userstatement_coursestart_to_unix($data->coursestart ?? null);
    if (!isset($data->completionverified)) {
        $data->completionverified = 1;
    }
    $data->id = $DB->insert_record('userstatement', $data);

    return $data->id;
}

/**
 * @param stdClass $data
 * @return bool
 */
function userstatement_update_instance($data, $mform = null) {
    global $DB;

    $data->id = $data->instance;
    $data->timemodified = time();
    if (property_exists($data, 'coursestart')) {
        $data->coursestart = userstatement_coursestart_to_unix($data->coursestart);
    } else {
        $old = $DB->get_record('userstatement', ['id' => $data->instance], 'coursestart', MUST_EXIST);
        $data->coursestart = $old->coursestart;
    }
    $DB->update_record('userstatement', $data);

    return true;
}

/**
 * Удалить все данные одного элемента «Заявление» (submissions, фоновые экспорты).
 *
 * @param int $instanceid
 */
function userstatement_purge_instance_data(int $instanceid): void {
    global $DB;

    $DB->delete_records('userstatement_submission', ['userstatement' => $instanceid]);
    $DB->delete_records('userstatement_export', ['userstatement' => $instanceid]);
}

/**
 * Удалить все сохранённые заявления в курсе.
 *
 * @param int $courseid
 */
function userstatement_delete_all_submissions_in_course(int $courseid): void {
    global $DB;

    $instanceids = $DB->get_fieldset_select('userstatement', 'id', 'course = ?', [$courseid]);
    if (!$instanceids) {
        return;
    }
    [$insql, $params] = $DB->get_in_or_equal($instanceids);
    $DB->delete_records_select('userstatement_submission', 'userstatement ' . $insql, $params);
}

/**
 * Удалить сохранённые заявления и договоры участника в курсе.
 *
 * @param int $courseid
 * @param int $userid
 * @param bool $includepartner false — только заявления (внутренний вызов).
 */
function userstatement_delete_user_submissions_in_course(int $courseid, int $userid, bool $includepartner = true): void {
    global $DB;

    static $cascade = 0;
    $instanceids = $DB->get_fieldset_select('userstatement', 'id', 'course = ?', [$courseid]);
    if ($instanceids) {
        [$insql, $inparams] = $DB->get_in_or_equal($instanceids);
        $params = array_merge($inparams, [$userid]);
        $DB->delete_records_select('userstatement_submission', 'userstatement ' . $insql . ' AND userid = ?', $params);
    }
    userstatement_sync_completion_all_in_course($courseid, $userid, false);

    if ($includepartner && $cascade === 0) {
        $cascade++;
        if (function_exists('usercontract_delete_user_submissions_in_course')) {
            usercontract_delete_user_submissions_in_course($courseid, $userid, false);
        }
        $cascade--;
    }
}

/**
 * Сбросить завершение по всем элементам «Заявление» в курсе для пользователя.
 *
 * @param int $courseid
 * @param int $userid
 * @param bool $verified
 */
function userstatement_sync_completion_all_in_course(int $courseid, int $userid, bool $verified): void {
    global $CFG;

    require_once($CFG->libdir . '/modinfolib.php');
    $course = get_course($courseid);
    $modinfo = get_fast_modinfo($course, $userid);
    foreach ($modinfo->get_instances_of('userstatement') as $cm) {
        userstatement_sync_completion_for_user($cm, $course, $userid, $verified);
    }
}

/**
 * @param int $id instance id
 * @return bool
 */
function userstatement_delete_instance($id) {
    global $DB;

    userstatement_purge_instance_data($id);
    $DB->delete_records('userstatement', ['id' => $id]);

    return true;
}

/**
 * SQL-фрагмент поиска участника (имя, e-mail, JSON: СНИЛС, место работы, телефон).
 *
 * @param string $search
 * @param array<string, mixed> $params
 * @param string $prefix
 * @return string
 */
function userstatement_submissions_search_where(string $search, array &$params, string $prefix = 'us'): string {
    global $DB;

    $search = trim($search);
    if ($search === '') {
        return '';
    }
    $like = '%' . $DB->sql_like_escape($search) . '%';
    $params[$prefix . 'searchfn'] = $like;
    $params[$prefix . 'searchem'] = $like;
    $params[$prefix . 'searchdata'] = $like;
    $wheres = [
        $DB->sql_like('u.firstname', ':' . $prefix . 'searchfn', false),
        $DB->sql_like('u.email', ':' . $prefix . 'searchem', false),
        $DB->sql_like('s.data', ':' . $prefix . 'searchdata', false),
    ];
    $snils = userstatement_normalize_snils_digits($search);
    if ($snils !== '') {
        $params[$prefix . 'searchsnils'] = '%' . $DB->sql_like_escape($snils) . '%';
        $wheres[] = $DB->sql_like('s.data', ':' . $prefix . 'searchsnils', false);
    }
    $phone = userstatement_normalize_phone_digits($search);
    if ($phone !== '') {
        $params[$prefix . 'searchphone'] = '%' . $DB->sql_like_escape($phone) . '%';
        $wheres[] = $DB->sql_like('s.data', ':' . $prefix . 'searchphone', false);
    }
    return ' AND (' . implode(' OR ', $wheres) . ')';
}

/**
 * Только цифры СНИЛС, не более 11.
 *
 * @param mixed $raw
 * @return string
 */
function userstatement_normalize_snils_digits($raw) {
    return substr(preg_replace('/\D/', '', (string) $raw), 0, 11);
}

/**
 * Контрольная сумма СНИЛС (ПФР): 11 цифр, последние две — контрольное число.
 *
 * @param mixed $raw
 * @return bool
 */
function userstatement_snils_checksum_valid($raw) {
    $digits = userstatement_normalize_snils_digits($raw);
    if (strlen($digits) !== 11 || !ctype_digit($digits)) {
        return false;
    }
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += (int) $digits[$i] * (9 - $i);
    }
    if ($sum < 100) {
        $check = $sum;
    } else if ($sum === 100 || $sum === 101) {
        $check = 0;
    } else {
        $check = $sum % 101;
        if ($check === 100) {
            $check = 0;
        }
    }
    return substr($digits, 9, 2) === str_pad((string) $check, 2, '0', STR_PAD_LEFT);
}

/**
 * @param mixed $raw
 * @return bool
 */
function userstatement_snils_is_valid($raw) {
    return userstatement_snils_checksum_valid($raw);
}

/**
 * Отображение СНИЛС в маске «000-000-000 00» (пустая строка, если не 11 цифр).
 *
 * @param string $digits
 * @return string
 */
function userstatement_format_snils_masked($digits) {
    $digits = userstatement_normalize_snils_digits($digits);
    if (strlen($digits) !== 11) {
        return '';
    }
    return substr($digits, 0, 3) . '-' . substr($digits, 3, 3) . '-' . substr($digits, 6, 3) . ' ' . substr($digits, 9, 2);
}

/**
 * СНИЛС для отображения в PDF/Excel: при 11 цифрах — «000-000-000 00», иначе маска по уже введённым цифрам.
 *
 * @param mixed $raw
 * @return string
 */
function userstatement_format_snils_display($raw) {
    $digits = userstatement_normalize_snils_digits($raw);
    $len = strlen($digits);
    if ($len === 0) {
        return '';
    }
    if ($len === 11) {
        return userstatement_format_snils_masked($digits);
    }
    $out = '';
    for ($i = 0; $i < $len; $i++) {
        if ($i === 3 || $i === 6) {
            $out .= '-';
        }
        if ($i === 9) {
            $out .= ' ';
        }
        $out .= $digits[$i];
    }
    return $out;
}

/**
 * Только цифры телефона (РФ): до 11 цифр, ведущая 7 (8 заменяется на 7, 10 цифр дополняются 7).
 *
 * @param mixed $raw
 * @return string
 */
function userstatement_normalize_phone_digits($raw) {
    $digits = preg_replace('/\D/', '', (string) $raw);
    if ($digits === '') {
        return '';
    }
    if ($digits[0] === '8') {
        $digits = '7' . substr($digits, 1);
    }
    if (strlen($digits) === 10) {
        $digits = '7' . $digits;
    }
    return substr($digits, 0, 11);
}

/**
 * Телефон в маске «+7 (XXX) XXX-XX-XX» (пустая строка, если не 11 цифр с ведущей 7).
 *
 * @param string $digits
 * @return string
 */
function userstatement_format_phone_masked($digits) {
    $digits = userstatement_normalize_phone_digits($digits);
    if (strlen($digits) !== 11 || $digits[0] !== '7') {
        return '';
    }
    $n = substr($digits, 1);
    return '+7 (' . substr($n, 0, 3) . ') ' . substr($n, 3, 3) . '-' . substr($n, 6, 2) . '-' . substr($n, 8, 2);
}

/**
 * Телефон для отображения: при 11 цифрах — полная маска, иначе по введённым цифрам.
 *
 * @param mixed $raw
 * @return string
 */
function userstatement_format_phone_display($raw) {
    $digits = userstatement_normalize_phone_digits($raw);
    $len = strlen($digits);
    if ($len === 0) {
        return '';
    }
    if ($len === 11 && $digits[0] === '7') {
        return userstatement_format_phone_masked($digits);
    }
    $national = ($digits[0] === '7') ? substr($digits, 1) : $digits;
    $nlen = strlen($national);
    if ($nlen === 0) {
        return '';
    }
    $out = '+7 (';
    for ($i = 0; $i < $nlen && $i < 10; $i++) {
        if ($i === 3) {
            $out .= ') ';
        }
        if ($i === 6) {
            $out .= '-';
        }
        if ($i === 8) {
            $out .= '-';
        }
        $out .= $national[$i];
    }
    return $out;
}

/**
 * Корректный российский номер: 11 цифр, начинается с 7.
 *
 * @param mixed $raw
 * @return bool
 */
function userstatement_phone_digits_valid($raw) {
    $digits = userstatement_normalize_phone_digits($raw);
    return strlen($digits) === 11 && $digits[0] === '7';
}

/**
 * Подключение JS-маски СНИЛС (инлайн: без сборки amd/build, иначе RequireJS не находит модуль).
 */
function userstatement_snils_mask_init() {
    global $PAGE;
    if (!$PAGE) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;
    $js = <<<'EOT'
(function() {
    var MASK_TEMPLATE = '___-___-___ __';
    var SLOT_POS = [0, 1, 2, 4, 5, 6, 8, 9, 10, 12, 13];
    var MASK_TITLE = 'XXX-XXX-XXX XX';
    function digitsOnly(s) {
        return String(s || '').replace(/\D/g, '');
    }
    function fmt(d) {
        var dig = digitsOnly(d).slice(0, 11);
        var arr = MASK_TEMPLATE.split('');
        var j;
        for (j = 0; j < dig.length; j++) {
            arr[SLOT_POS[j]] = dig.charAt(j);
        }
        return arr.join('');
    }
    function nextCaret(str) {
        var i = str.indexOf('_');
        return i === -1 ? str.length : i;
    }
    function bind(inp) {
        if (!inp || inp.getAttribute('data-snils-mask') === '1') { return; }
        inp.setAttribute('data-snils-mask', '1');
        inp.setAttribute('inputmode', 'numeric');
        inp.setAttribute('autocomplete', 'off');
        inp.setAttribute('spellcheck', 'false');
        inp.removeAttribute('maxlength');
        if (!inp.getAttribute('title')) {
            inp.setAttribute('title', MASK_TITLE);
        }
        function currentDigits() {
            return digitsOnly(inp.value);
        }
        function applyDigits(dig) {
            var neu = fmt(dig);
            inp.value = neu;
            try { inp.setSelectionRange(nextCaret(neu), nextCaret(neu)); } catch (e) {}
        }
        function ensureMask() {
            if (currentDigits().length === 0 && inp.value === '') {
                inp.value = MASK_TEMPLATE;
            } else if (inp.value === '' || inp.value.indexOf('_') === -1) {
                applyDigits(currentDigits());
            } else if (inp.value.length < MASK_TEMPLATE.length) {
                applyDigits(currentDigits());
            }
        }
        inp.addEventListener('focus', function() {
            if (currentDigits().length === 0) {
                inp.value = MASK_TEMPLATE;
            }
            try { inp.setSelectionRange(nextCaret(inp.value), nextCaret(inp.value)); } catch (e) {}
        });
        inp.addEventListener('blur', function() {
            if (currentDigits().length === 0) {
                inp.value = '';
            } else {
                applyDigits(currentDigits());
            }
        });
        inp.addEventListener('keydown', function(e) {
            var k = e.key;
            if (k === 'Tab' || k === 'Escape' || k === 'Enter' ||
                k === 'ArrowLeft' || k === 'ArrowRight' || k === 'ArrowUp' || k === 'ArrowDown' ||
                k === 'Home' || k === 'End') { return; }
            if (e.ctrlKey || e.metaKey || e.altKey) { return; }
            if (k === 'Backspace') {
                e.preventDefault();
                var dig = currentDigits();
                if (dig.length === 0) {
                    inp.value = MASK_TEMPLATE;
                    try { inp.setSelectionRange(0, 0); } catch (e2) {}
                    return;
                }
                applyDigits(dig.slice(0, -1));
                return;
            }
            if (k === 'Delete') {
                e.preventDefault();
                applyDigits('');
                return;
            }
            if (k && k.length === 1 && /[0-9]/.test(k)) {
                e.preventDefault();
                var d = currentDigits();
                if (d.length >= 11) { return; }
                applyDigits(d + k);
                return;
            }
            if (k && k.length === 1) {
                e.preventDefault();
            }
        });
        inp.addEventListener('input', function() {
            var dig = currentDigits();
            var neu = fmt(dig);
            if (inp.value !== neu) {
                inp.value = neu;
            }
            try { inp.setSelectionRange(nextCaret(neu), nextCaret(neu)); } catch (e3) {}
        });
        inp.addEventListener('paste', function(e) {
            e.preventDefault();
            var t = (e.clipboardData || window.clipboardData).getData('text') || '';
            applyDigits(currentDigits() + digitsOnly(t));
        });
        inp.addEventListener('dragover', function(e) { e.preventDefault(); });
        inp.addEventListener('drop', function(e) {
            e.preventDefault();
            var t = e.dataTransfer ? e.dataTransfer.getData('text/plain') : '';
            applyDigits(currentDigits() + digitsOnly(t));
        });
        if (currentDigits().length > 0) {
            applyDigits(currentDigits());
        } else {
            inp.value = '';
        }
    }
    function run() {
        var seen = {};
        document.querySelectorAll('input[name="snils"], input.userstatement-snils').forEach(function(inp) {
            if (seen[inp.name + inp.id]) { return; }
            seen[inp.name + inp.id] = 1;
            bind(inp);
        });
    }
    run();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    }
    window.addEventListener('load', run);
})();
EOT;
    $PAGE->requires->js_init_code($js);
}

/**
 * Подключение JS-маски телефона «+7 (XXX) XXX-XX-XX».
 */
function userstatement_phone_mask_init() {
    global $PAGE;
    if (!$PAGE) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;
    $masktitle = json_encode(get_string('phone_mask_title', 'userstatement'), JSON_UNESCAPED_UNICODE);
    $js = <<<EOT
(function() {
    var MASK_TEMPLATE = '+7 (___) ___-__-__';
    var SLOT_POS = [4, 5, 6, 9, 10, 11, 13, 14, 16, 17];
    var MAX_NATIONAL = 10;
    var MASK_TITLE = {$masktitle};
    function digitsOnly(s) {
        return String(s || '').replace(/\D/g, '');
    }
    function toNationalDigits(s) {
        var dig = digitsOnly(s).slice(0, 11);
        if (dig.length > 0 && dig.charAt(0) === '8') {
            dig = '7' + dig.slice(1);
        }
        if (dig.length === 11 && dig.charAt(0) === '7') {
            return dig.slice(1);
        }
        if (dig.charAt(0) === '7') {
            return dig.slice(1);
        }
        return dig.slice(0, MAX_NATIONAL);
    }
    function fmt(d) {
        var national = toNationalDigits(d).slice(0, MAX_NATIONAL);
        var arr = MASK_TEMPLATE.split('');
        var j;
        for (j = 0; j < national.length; j++) {
            arr[SLOT_POS[j]] = national.charAt(j);
        }
        return arr.join('');
    }
    function nextCaret(str) {
        var i = str.indexOf('_');
        return i === -1 ? str.length : i;
    }
    function bind(inp) {
        if (!inp || inp.getAttribute('data-phone-mask') === '1') { return; }
        inp.setAttribute('data-phone-mask', '1');
        inp.setAttribute('inputmode', 'tel');
        inp.setAttribute('autocomplete', 'tel');
        inp.setAttribute('spellcheck', 'false');
        inp.removeAttribute('maxlength');
        if (!inp.getAttribute('title')) {
            inp.setAttribute('title', MASK_TITLE);
        }
        function currentDigits() {
            return digitsOnly(inp.value);
        }
        function applyDigits(dig) {
            var neu = fmt(dig);
            inp.value = neu;
            try { inp.setSelectionRange(nextCaret(neu), nextCaret(neu)); } catch (e) {}
        }
        inp.addEventListener('focus', function() {
            if (toNationalDigits(inp.value).length === 0) {
                inp.value = MASK_TEMPLATE;
            }
            try { inp.setSelectionRange(nextCaret(inp.value), nextCaret(inp.value)); } catch (e) {}
        });
        inp.addEventListener('blur', function() {
            if (toNationalDigits(inp.value).length === 0) {
                inp.value = '';
            } else {
                applyDigits(currentDigits());
            }
        });
        inp.addEventListener('keydown', function(e) {
            var k = e.key;
            if (k === 'Tab' || k === 'Escape' || k === 'Enter' ||
                k === 'ArrowLeft' || k === 'ArrowRight' || k === 'ArrowUp' || k === 'ArrowDown' ||
                k === 'Home' || k === 'End') { return; }
            if (e.ctrlKey || e.metaKey || e.altKey) { return; }
            if (k === 'Backspace') {
                e.preventDefault();
                var dig = currentDigits();
                if (toNationalDigits(dig).length === 0) {
                    inp.value = MASK_TEMPLATE;
                    try { inp.setSelectionRange(nextCaret(MASK_TEMPLATE), nextCaret(MASK_TEMPLATE)); } catch (e2) {}
                    return;
                }
                var nat = toNationalDigits(dig);
                applyDigits(nat.slice(0, -1));
                return;
            }
            if (k === 'Delete') {
                e.preventDefault();
                applyDigits('');
                return;
            }
            if (k && k.length === 1 && /[0-9]/.test(k)) {
                e.preventDefault();
                var nat2 = toNationalDigits(currentDigits());
                if (nat2.length >= MAX_NATIONAL) { return; }
                applyDigits(nat2 + k);
                return;
            }
            if (k && k.length === 1) {
                e.preventDefault();
            }
        });
        inp.addEventListener('input', function() {
            var neu = fmt(currentDigits());
            if (inp.value !== neu) {
                inp.value = neu;
            }
            try { inp.setSelectionRange(nextCaret(neu), nextCaret(neu)); } catch (e3) {}
        });
        inp.addEventListener('paste', function(e) {
            e.preventDefault();
            var t = (e.clipboardData || window.clipboardData).getData('text') || '';
            applyDigits(toNationalDigits(currentDigits()) + digitsOnly(t));
        });
        inp.addEventListener('dragover', function(e) { e.preventDefault(); });
        inp.addEventListener('drop', function(e) {
            e.preventDefault();
            var t = e.dataTransfer ? e.dataTransfer.getData('text/plain') : '';
            applyDigits(toNationalDigits(currentDigits()) + digitsOnly(t));
        });
        if (toNationalDigits(inp.value).length > 0) {
            applyDigits(currentDigits());
        } else {
            inp.value = '';
        }
    }
    function run() {
        var seen = {};
        document.querySelectorAll('input[name="phone"], input.userstatement-phone').forEach(function(inp) {
            if (seen[inp.name + inp.id]) { return; }
            seen[inp.name + inp.id] = 1;
            bind(inp);
        });
    }
    run();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    }
    window.addEventListener('load', run);
})();
EOT;
    $PAGE->requires->js_init_code($js);
}

/**
 * Обязательные текстовые поля формы.
 *
 * @return string[]
 */
function userstatement_required_text_fields() {
    return [
        'snils', 'citizenship', 'edu_level', 'edu_institution', 'diploma_lastname',
        'diploma_series', 'diploma_number', 'qualification', 'workplace', 'position',
        'experience_position', 'pedagogical_experience', 'subjects', 'degree_title', 'phone',
    ];
}

/**
 * Обязательные поля даты.
 *
 * @return string[]
 */
function userstatement_required_date_fields() {
    return ['birthdate', 'diploma_date'];
}

/**
 * Разбор значения date_selector / timestamp / JSON в компоненты даты.
 *
 * @param mixed $value
 * @return array{day:int,month:int,year:int}|null
 */
function userstatement_date_parts($value): ?array {
    if ($value === null || $value === '' || $value === 0 || $value === '0') {
        return null;
    }
    if (is_object($value)) {
        $value = (array) $value;
    }
    if (is_array($value)) {
        if (array_key_exists('enabled', $value) && empty($value['enabled'])) {
            return null;
        }
        $year = (int) ($value['year'] ?? 0);
        $month = (int) ($value['month'] ?? 0);
        $day = (int) ($value['day'] ?? 0);
        if ($year > 0 && $month > 0 && $day > 0) {
            return ['day' => $day, 'month' => $month, 'year' => $year];
        }
        return null;
    }
    if (is_numeric($value)) {
        $int = (int) $value;
        // Голый год (1900–2100) — не Unix timestamp.
        if ($int >= 1900 && $int <= 2100) {
            return null;
        }
        if ($int === 0) {
            return null;
        }
        $day = (int) userdate($int, '%d', 99, false);
        $month = (int) userdate($int, '%m', 99, false);
        $year = (int) userdate($int, '%Y', 99, false);
        if ($year > 0 && $month > 0 && $day > 0) {
            return ['day' => $day, 'month' => $month, 'year' => $year];
        }
    }
    return null;
}

/**
 * Имена полей формы для одной даты (группа QuickForm).
 *
 * @param string $field birthdate|diploma_date
 * @return array{day:string,month:string,year:string}
 */
function userstatement_date_form_element_names(string $field): array {
    return [
        'day' => $field . '_day',
        'month' => $field . '_month',
        'year' => $field . '_year',
    ];
}

/**
 * Извлечь компоненты даты из данных формы (группа или JSON).
 *
 * @param array|\stdClass $data
 * @param string $field
 * @return array{day:mixed,month:mixed,year:mixed}|null
 */
function userstatement_form_extract_date_field($data, string $field): ?array {
    if (is_object($data)) {
        $data = json_decode(json_encode($data), true);
    }
    if (!is_array($data)) {
        return null;
    }
    $names = userstatement_date_form_element_names($field);

    if (array_key_exists($field, $data) && $data[$field] !== null && $data[$field] !== '') {
        $parts = userstatement_date_parts($data[$field]);
        if ($parts !== null) {
            return $parts;
        }
        $nested = is_array($data[$field]) ? $data[$field] : (array) $data[$field];
        if (array_key_exists($names['day'], $nested)) {
            return [
                'day' => $nested[$names['day']] ?? '',
                'month' => $nested[$names['month']] ?? '',
                'year' => $nested[$names['year']] ?? '',
            ];
        }
        if (array_key_exists('day', $nested)) {
            return [
                'day' => $nested['day'] ?? '',
                'month' => $nested['month'] ?? '',
                'year' => $nested['year'] ?? '',
            ];
        }
    }

    if (array_key_exists($names['day'], $data) || array_key_exists($names['month'], $data) ||
            array_key_exists($names['year'], $data)) {
        return [
            'day' => $data[$names['day']] ?? '',
            'month' => $data[$names['month']] ?? '',
            'year' => $data[$names['year']] ?? '',
        ];
    }
    return null;
}

/**
 * Значение для set_data() — вложенная группа с уникальными именами элементов.
 *
 * @param mixed $value
 * @param string $field
 * @return array<string, string>
 */
function userstatement_date_to_form_group_value($value, string $field): array {
    $parts = userstatement_date_to_form_value($value);
    $names = userstatement_date_form_element_names($field);
    return [
        $names['day'] => $parts['day'],
        $names['month'] => $parts['month'],
        $names['year'] => $parts['year'],
    ];
}

/**
 * Нормализация даты из get_data() в {day, month, year} для JSON.
 *
 * @param mixed $value
 * @param string $field
 * @return \stdClass|null
 */
function userstatement_form_date_to_storage($value, string $field): ?\stdClass {
    if (is_object($value)) {
        $value = (array) $value;
    }
    if (!is_array($value)) {
        return null;
    }
    $names = userstatement_date_form_element_names($field);
    if (array_key_exists($names['day'], $value)) {
        $value = [
            'day' => $value[$names['day']] ?? '',
            'month' => $value[$names['month']] ?? '',
            'year' => $value[$names['year']] ?? '',
        ];
    }
    $parts = userstatement_date_parts($value);
    if ($parts === null) {
        return null;
    }
    return (object) $parts;
}

/**
 * Приведение сохранённого JSON заявки к каноническому виду (PDF, проверка, экспорт).
 *
 * @param mixed $data
 * @return \stdClass|null
 */
function userstatement_normalize_stored_submission($data): ?\stdClass {
    if (is_array($data)) {
        $data = (object) $data;
    }
    if (!is_object($data)) {
        return null;
    }
    foreach (userstatement_required_date_fields() as $field) {
        $parts = userstatement_form_extract_date_field($data, $field);
        if ($parts !== null) {
            $normalized = userstatement_date_parts($parts);
            if ($normalized !== null) {
                $data->$field = (object) $normalized;
            }
        }
    }
    if (property_exists($data, 'snils')) {
        $data->snils = userstatement_normalize_snils_digits($data->snils);
    }
    if (property_exists($data, 'phone')) {
        $data->phone = userstatement_normalize_phone_digits($data->phone);
    }
    return $data;
}

/**
 * Значение day/month/year для set_data() (плоский массив).
 *
 * @param mixed $value
 * @return array{day:string,month:string,year:string}
 */
function userstatement_date_to_form_value($value): array {
    $parts = userstatement_date_parts($value);
    if ($parts === null) {
        return ['day' => '', 'month' => '', 'year' => ''];
    }
    return [
        'day' => (string) $parts['day'],
        'month' => (string) $parts['month'],
        'year' => (string) $parts['year'],
    ];
}

/**
 * Нормализация даты для JSON (день/месяц/год, без timestamp).
 *
 * @param mixed $value
 * @return array{day:int,month:int,year:int}|null
 */
function userstatement_date_normalize_for_json($value): ?array {
    return userstatement_date_parts($value);
}

/**
 * Дата в формате ДД.ММ.ГГГГ для PDF и Excel.
 *
 * @param mixed $value
 * @return string
 */
function userstatement_date_format_display($value): string {
    $parts = userstatement_date_parts($value);
    if ($parts === null) {
        return '';
    }
    return sprintf('%02d.%02d.%04d', $parts['day'], $parts['month'], $parts['year']);
}

/**
 * Списки значений для полей даты (первый пункт — пустой).
 *
 * @param int $startyear
 * @param int $stopyear
 * @return array{array<string,string>,array<string,string>,array<string,string>}
 */
function userstatement_date_select_options(int $startyear, int $stopyear): array {
    $days = ['' => get_string('dateselectday', 'userstatement')];
    for ($d = 1; $d <= 31; $d++) {
        $days[(string) $d] = (string) $d;
    }

    $months = ['' => get_string('dateselectmonth', 'userstatement')];
    for ($m = 1; $m <= 12; $m++) {
        $months[(string) $m] = userdate(gmmktime(0, 0, 0, $m, 1, 2000), '%B', 99, false);
    }

    $years = ['' => get_string('dateselectyear', 'userstatement')];
    for ($y = $stopyear; $y >= $startyear; $y--) {
        $years[(string) $y] = (string) $y;
    }

    return [$days, $months, $years];
}

/**
 * Текущий календарный год (несколько источников на случай сбоя часов).
 *
 * @return int
 */
function userstatement_current_calendar_year(): int {
    return max(
        (int) gmdate('Y'),
        (int) date('Y'),
        (int) userdate(time(), '%Y', 99, false)
    );
}

/**
 * @return array{0:int,1:int}
 */
function userstatement_birthdate_year_range(): array {
    $startyear = 1900;
    $current = userstatement_current_calendar_year();
    // Текущий год + 1; нижний порог 2026 — чтобы годы вроде 2001 были доступны при отставании часов сервера.
    $stopyear = max($current + 1, 2026);
    return [$startyear, $stopyear];
}

/**
 * @return array{0:int,1:int}
 */
function userstatement_diploma_date_year_range(): array {
    $current = userstatement_current_calendar_year();
    return [1950, max($current + 1, 2026)];
}

/**
 * Группа select «день / месяц / год» без автоподстановки Moodle date_selector.
 *
 * @param \MoodleQuickForm $mform
 * @param string $name
 * @param string $label
 * @param int $startyear
 * @param int $stopyear
 */
function userstatement_form_add_date_group($mform, string $name, string $label, int $startyear, int $stopyear) {
    [$days, $months, $years] = userstatement_date_select_options($startyear, $stopyear);
    $selectattrs = ['class' => 'userstatement-date-part'];
    $names = userstatement_date_form_element_names($name);
    $group = [
        $mform->createElement(
            'select',
            $names['day'],
            '',
            $days,
            $selectattrs + ['aria-label' => get_string('dateselectday', 'userstatement')]
        ),
        $mform->createElement(
            'select',
            $names['month'],
            '',
            $months,
            $selectattrs + ['aria-label' => get_string('dateselectmonth', 'userstatement')]
        ),
        $mform->createElement(
            'select',
            $names['year'],
            '',
            $years,
            $selectattrs + ['aria-label' => get_string('dateselectyear', 'userstatement')]
        ),
    ];
    $mform->addGroup($group, $name, $label, [' ', ' '], false);
    $mform->setType($name . '[' . $names['day'] . ']', PARAM_RAW);
    $mform->setType($name . '[' . $names['month'] . ']', PARAM_RAW);
    $mform->setType($name . '[' . $names['year'] . ']', PARAM_RAW);
}

/**
 * Текстовые поля с проверкой при потере фокуса.
 *
 * @return string[]
 */
function userstatement_blur_validated_text_fields() {
    return userstatement_required_text_fields();
}

/**
 * Поля, в которых допускаются только буквы (кириллица/латиница), пробел и дефис.
 *
 * @return string[]
 */
function userstatement_letters_only_fields() {
    return ['citizenship', 'edu_level', 'diploma_lastname'];
}

/**
 * Поля: буквы, пробел, дефис и запятая.
 *
 * @return string[]
 */
function userstatement_letters_with_commas_fields() {
    return ['position', 'subjects'];
}

/**
 * @param mixed $value
 * @return bool
 */
function userstatement_value_is_letters_only($value) {
    $v = trim((string) $value);
    if ($v === '') {
        return true;
    }
    return (bool) preg_match('/^[\p{L}\s\-]+$/u', $v);
}

/**
 * @param mixed $value
 * @return bool
 */
function userstatement_value_is_letters_with_commas($value) {
    $v = trim((string) $value);
    if ($v === '') {
        return true;
    }
    return (bool) preg_match('/^[\p{L}\s\-,]+$/u', $v);
}

/**
 * Проверка данных формы: массив ошибок elementname => сообщение.
 *
 * @param array|\stdClass $data
 * @param array $options requireconfirm (bool, default true)
 * @return array<string, string>
 */
function userstatement_form_validation_errors($data, array $options = []) {
    if (is_object($data)) {
        $data = json_decode(json_encode($data), true);
    }
    if (!is_array($data)) {
        $data = [];
    }

    $errors = [];
    $fieldempty = get_string('fieldempty', 'userstatement');

    foreach (userstatement_required_text_fields() as $field) {
        if ($field === 'snils' || $field === 'phone') {
            continue;
        }
        if (trim((string) ($data[$field] ?? '')) === '') {
            $errors[$field] = $fieldempty;
        }
    }

    $snils = userstatement_normalize_snils_digits($data['snils'] ?? '');
    if (!userstatement_snils_is_valid($snils)) {
        $errors['snils'] = get_string('invalidsnils', 'userstatement');
    }

    $phoneraw = trim((string) ($data['phone'] ?? ''));
    if ($phoneraw === '') {
        $errors['phone'] = $fieldempty;
    } else if (!userstatement_phone_digits_valid($phoneraw)) {
        $errors['phone'] = get_string('invalidphone', 'userstatement');
    }

    $daterequired = get_string('daterequired', 'userstatement');
    foreach (userstatement_required_date_fields() as $field) {
        $raw = userstatement_form_extract_date_field($data, $field);
        if ($raw === null || !userstatement_date_value_nonempty($raw)) {
            $errors[$field] = $daterequired;
            continue;
        }
        $parts = userstatement_date_parts($raw);
        if ($parts === null) {
            $errors[$field] = $daterequired;
            continue;
        }
        if (!checkdate($parts['month'], $parts['day'], $parts['year'])) {
            $errors[$field] = get_string('dateinvalid', 'userstatement');
            continue;
        }
        if ($field === 'birthdate') {
            [, $birthmax] = userstatement_birthdate_year_range();
            if ($parts['year'] < 1900 || $parts['year'] > $birthmax) {
                $errors[$field] = get_string('birthdateyearinvalid', 'userstatement', (object) [
                    'min' => 1900,
                    'max' => $birthmax,
                ]);
            }
        }
    }

    $gender = $data['gender'] ?? '';
    if (!in_array($gender, ['female', 'male'], true)) {
        $errors['gender'] = $fieldempty;
    }

    if (($options['requireconfirm'] ?? true) && empty($data['confirmaccuracy'])) {
        $errors['confirmaccuracy'] = get_string('confirmrequired', 'userstatement');
    }

    $lettersmsg = get_string('invalidlettersonly', 'userstatement');
    foreach (userstatement_letters_only_fields() as $field) {
        $raw = trim((string) ($data[$field] ?? ''));
        if ($raw !== '' && !userstatement_value_is_letters_only($raw)) {
            $errors[$field] = $lettersmsg;
        }
    }

    $commasmsg = get_string('invalidletterscommas', 'userstatement');
    foreach (userstatement_letters_with_commas_fields() as $field) {
        $raw = trim((string) ($data[$field] ?? ''));
        if ($raw !== '' && !userstatement_value_is_letters_with_commas($raw)) {
            $errors[$field] = $commasmsg;
        }
    }

    return $errors;
}

/**
 * Ширина текстовых полей формы заявления (символы size/cols и max-width в CSS).
 *
 * @return int
 */
function userstatement_statement_field_size() {
    return 64;
}

/**
 * Атрибуты однострочного поля с единой шириной.
 *
 * @param string[] $classes
 * @param array $extra
 * @return array
 */
function userstatement_statement_text_attrs(array $classes, array $extra = []) {
    $class = trim(implode(' ', array_merge(['userstatement-field-full'], $classes)));
    return array_merge([
        'size' => userstatement_statement_field_size(),
        'maxlength' => 255,
        'class' => $class,
    ], $extra);
}

/**
 * Атрибуты многострочного поля с единой шириной.
 *
 * @param string[] $classes
 * @param array $extra
 * @return array
 */
function userstatement_statement_textarea_attrs(array $classes, array $extra = []) {
    $class = trim(implode(' ', array_merge(['userstatement-field-full'], $classes)));
    return array_merge([
        'rows' => 3,
        'cols' => userstatement_statement_field_size(),
        'class' => $class,
    ], $extra);
}

/**
 * CSS: одинаковая ширина полей ввода в форме заявления.
 */
function userstatement_statement_form_layout_init() {
    global $PAGE;
    if (!$PAGE) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    $em = userstatement_statement_field_size();
    $css = <<<EOT
.userstatement-statement-form .fitem .felement > input[type="text"].userstatement-field-full,
.userstatement-statement-form .fitem .felement > input[type="password"].userstatement-field-full,
.userstatement-statement-form .fitem .felement > textarea.userstatement-field-full,
.userstatement-statement-form .fitem .felement > select.userstatement-field-full,
.userstatement-statement-form .fitem .felement .form-control {
    width: min(100%, {$em}em);
    max-width: 100%;
    box-sizing: border-box;
}
.userstatement-statement-form .fitem .fitemtitle,
.userstatement-statement-form .fitem .col-form-label {
    min-width: 11em;
    white-space: nowrap;
    vertical-align: top;
    padding-top: 0.45rem;
}
.userstatement-statement-form .fitem .felement {
    vertical-align: top;
}
.userstatement-submissions-heading {
    margin-bottom: 1.25rem !important;
}
.userstatement-search-form .userstatement-search-label {
    margin-bottom: 0;
    white-space: nowrap;
}
.userstatement-search-form .userstatement-search-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 0.5rem;
}
.userstatement-toolbar-block {
    padding: 0.75rem 1rem;
    margin-bottom: 0.75rem;
    border: 1px solid #dee2e6;
    border-radius: 0.25rem;
    background: #f8f9fa;
}
.userstatement-toolbar-block > h4 {
    margin: 0 0 0.65rem 0;
    font-size: 1rem;
    font-weight: 600;
}
.userstatement-statement-form .userstatement-date-part {
    min-width: 5.5em;
    max-width: 100%;
    box-sizing: border-box;
}
.userstatement-toolbar-downloads .userstatement-download-actions {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 0.5rem;
}
.userstatement-toolbar-downloads .userstatement-bulk-export-buttons {
    margin-top: 0.5rem;
    margin-bottom: 0;
}
EOT;
    $PAGE->requires->js_init_code(
        '(function(){if(document.getElementById("userstatement-layout-style")){return;}'
        . 'var st=document.createElement("style");st.id="userstatement-layout-style";'
        . 'st.textContent=' . json_encode($css, JSON_UNESCAPED_UNICODE) . ';'
        . 'document.head.appendChild(st);})();'
    );
}

/**
 * Подсветка обязательных текстовых полей при blur (инлайн JS, как у маски СНИЛС).
 */
function userstatement_text_fields_blur_validation_init() {
    global $PAGE;
    if (!$PAGE) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    $fieldsjson = json_encode(userstatement_blur_validated_text_fields(), JSON_UNESCAPED_UNICODE);
    $lettersjson = json_encode(userstatement_letters_only_fields(), JSON_UNESCAPED_UNICODE);
    $commasjson = json_encode(userstatement_letters_with_commas_fields(), JSON_UNESCAPED_UNICODE);
    $message = json_encode(get_string('fieldempty', 'userstatement'), JSON_UNESCAPED_UNICODE);
    $lettersmessage = json_encode(get_string('invalidlettersonly', 'userstatement'), JSON_UNESCAPED_UNICODE);
    $commasmessage = json_encode(get_string('invalidletterscommas', 'userstatement'), JSON_UNESCAPED_UNICODE);

    $js = <<<EOT
(function() {
    var FIELDS = {$fieldsjson};
    var LETTER_FIELDS = {$lettersjson};
    var COMMA_FIELDS = {$commasjson};
    var MESSAGE = {$message};
    var LETTERS_MSG = {$lettersmessage};
    var COMMAS_MSG = {$commasmessage};
    var letterSet = {};
    LETTER_FIELDS.forEach(function(n) { letterSet[n] = 1; });
    var commaSet = {};
    COMMA_FIELDS.forEach(function(n) { commaSet[n] = 1; });
    if (!document.getElementById('userstatement-validation-style')) {
        var st = document.createElement('style');
        st.id = 'userstatement-validation-style';
        st.textContent = '.mform input.userstatement-invalid,.mform textarea.userstatement-invalid,.mform select.userstatement-invalid,.mform select.userstatement-date-part.userstatement-invalid{border-color:#ca3120!important;background-color:#fff8f7!important;box-shadow:inset 0 0 0 1px #ca3120!important}.mform .fitem.userstatement-fitem-invalid>.felement .userstatement-field-hint{display:block;margin-top:.35rem;color:#ca3120;font-size:.875rem}.mform .fitem.userstatement-fitem-invalid>.fitemtitle label,.mform .fitem.userstatement-fitem-invalid .col-form-label{color:#ca3120!important}.mform .fitem.userstatement-fitem-invalid>.felement.fgroup{display:inline-block;padding:.35rem .5rem;border-radius:.25rem;box-shadow:inset 0 0 0 1px #ca3120;background:#fff8f7}.userstatement-date-hint{display:block;margin:-0.35rem 0 0.75rem 0;color:#856404;font-size:.875rem}.userstatement-statement-form .userstatement-date-part{min-width:5.5em;max-width:100%;box-sizing:border-box}';
        document.head.appendChild(st);
    }
    function trimVal(inp) {
        return String(inp.value || '').trim();
    }
    function lettersOnly(val) {
        if (!val) {
            return true;
        }
        return /^[\p{L}\s\-]+$/u.test(val);
    }
    function lettersWithCommas(val) {
        if (!val) {
            return true;
        }
        return /^[\p{L}\s\-,]+$/u.test(val);
    }
    function fieldError(inp) {
        var val = trimVal(inp);
        if (val === '') {
            return { invalid: true, msg: MESSAGE };
        }
        if (letterSet[inp.name] && !lettersOnly(val)) {
            return { invalid: true, msg: LETTERS_MSG };
        }
        if (commaSet[inp.name] && !lettersWithCommas(val)) {
            return { invalid: true, msg: COMMAS_MSG };
        }
        return { invalid: false, msg: '' };
    }
    function hintId(name) {
        return 'userstatement-hint-' + name;
    }
    function mark(inp, err) {
        var felement = inp.closest('.felement');
        var fitem = inp.closest('.fitem');
        var hint = document.getElementById(hintId(inp.name));
        if (err.invalid) {
            inp.classList.add('userstatement-invalid');
            inp.setAttribute('aria-invalid', 'true');
            if (fitem) {
                fitem.classList.add('userstatement-fitem-invalid');
            }
            if (!hint && felement) {
                hint = document.createElement('div');
                hint.id = hintId(inp.name);
                hint.className = 'userstatement-field-hint';
                hint.setAttribute('role', 'alert');
                felement.appendChild(hint);
            }
            if (hint) {
                hint.textContent = err.msg;
            }
        } else {
            inp.classList.remove('userstatement-invalid');
            inp.removeAttribute('aria-invalid');
            if (fitem) {
                fitem.classList.remove('userstatement-fitem-invalid');
            }
            if (hint) {
                hint.remove();
            }
        }
    }
    function bind(inp) {
        if (!inp || inp.getAttribute('data-userstatement-blur') === '1') {
            return;
        }
        inp.setAttribute('data-userstatement-blur', '1');
        inp.addEventListener('blur', function() {
            mark(inp, fieldError(inp));
        });
        inp.addEventListener('input', function() {
            if (inp.classList.contains('userstatement-invalid')) {
                mark(inp, fieldError(inp));
            }
        });
    }
    function run() {
        FIELDS.forEach(function(name) {
            document.querySelectorAll('input[name="' + name + '"], textarea[name="' + name + '"]').forEach(bind);
        });
    }
    run();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    }
    window.addEventListener('load', run);
})();
EOT;
    $PAGE->requires->js_init_code($js);
}

/**
 * Проверка обязательных полей даты при отправке формы и при смене значения.
 */
function userstatement_date_fields_validation_init() {
    global $PAGE;
    if (!$PAGE) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    $fieldsjson = json_encode(userstatement_required_date_fields(), JSON_UNESCAPED_UNICODE);
    $message = json_encode(get_string('daterequired', 'userstatement'), JSON_UNESCAPED_UNICODE);

    $js = <<<EOT
(function() {
    var DATE_FIELDS = {$fieldsjson};
    var MESSAGE = {$message};
    if (!document.getElementById('userstatement-validation-style')) {
        var st = document.createElement('style');
        st.id = 'userstatement-validation-style';
        st.textContent = '.mform input.userstatement-invalid,.mform textarea.userstatement-invalid,.mform select.userstatement-invalid,.mform select.userstatement-date-part.userstatement-invalid{border-color:#ca3120!important;background-color:#fff8f7!important;box-shadow:inset 0 0 0 1px #ca3120!important}.mform .fitem.userstatement-fitem-invalid>.felement .userstatement-field-hint{display:block;margin-top:.35rem;color:#ca3120;font-size:.875rem}.mform .fitem.userstatement-fitem-invalid>.fitemtitle label,.mform .fitem.userstatement-fitem-invalid .col-form-label{color:#ca3120!important}.mform .fitem.userstatement-fitem-invalid>.felement.fgroup{display:inline-block;padding:.35rem .5rem;border-radius:.25rem;box-shadow:inset 0 0 0 1px #ca3120;background:#fff8f7}.userstatement-date-hint{display:block;margin:-0.35rem 0 0.75rem 0;color:#856404;font-size:.875rem}.userstatement-statement-form .userstatement-date-part{min-width:5.5em;max-width:100%;box-sizing:border-box}';
        document.head.appendChild(st);
    }
    function selects(name) {
        return {
            day: document.querySelector('select[name="' + name + '[' + name + '_day]"]'),
            month: document.querySelector('select[name="' + name + '[' + name + '_month]"]'),
            year: document.querySelector('select[name="' + name + '[' + name + '_year]"]')
        };
    }
    function fitemFor(name) {
        return document.getElementById('fitem_id_' + name);
    }
    function dateValid(name) {
        var s = selects(name);
        if (!s.day || !s.month || !s.year) {
            return true;
        }
        var d = parseInt(s.day.value, 10) || 0;
        var m = parseInt(s.month.value, 10) || 0;
        var y = parseInt(s.year.value, 10) || 0;
        return d > 0 && m > 0 && y > 0;
    }
    function hintId(name) {
        return 'userstatement-date-hint-' + name;
    }
    function markDate(name, invalid) {
        var s = selects(name);
        if (!s.day || !s.month || !s.year) {
            return;
        }
        var fitem = fitemFor(name) || s.day.closest('.fitem');
        var felement = s.day.closest('.felement') || s.day.closest('.fgroup');
        var hint = document.getElementById(hintId(name));
        [s.day, s.month, s.year].forEach(function(sel) {
            if (invalid) {
                sel.classList.add('userstatement-invalid');
                sel.setAttribute('aria-invalid', 'true');
            } else {
                sel.classList.remove('userstatement-invalid');
                sel.removeAttribute('aria-invalid');
            }
        });
        if (invalid) {
            if (fitem) {
                fitem.classList.add('userstatement-fitem-invalid');
            }
            if (!hint && felement) {
                hint = document.createElement('div');
                hint.id = hintId(name);
                hint.className = 'userstatement-field-hint';
                hint.setAttribute('role', 'alert');
                felement.appendChild(hint);
            }
            if (hint) {
                hint.textContent = MESSAGE;
            }
        } else {
            if (fitem) {
                fitem.classList.remove('userstatement-fitem-invalid');
            }
            if (hint) {
                hint.remove();
            }
        }
    }
    function checkDate(name) {
        markDate(name, !dateValid(name));
    }
    function bindDate(name) {
        var s = selects(name);
        if (!s.day || s.day.getAttribute('data-userstatement-date') === '1') {
            return;
        }
        s.day.setAttribute('data-userstatement-date', '1');
        [s.day, s.month, s.year].forEach(function(sel) {
            sel.addEventListener('change', function() {
                checkDate(name);
            });
            sel.addEventListener('blur', function() {
                checkDate(name);
            });
        });
    }
    function validateAll() {
        var firstInvalid = null;
        DATE_FIELDS.forEach(function(name) {
            var ok = dateValid(name);
            markDate(name, !ok);
            if (!ok && !firstInvalid) {
                firstInvalid = selects(name).day;
            }
        });
        return firstInvalid;
    }
    function markServerErrors() {
        DATE_FIELDS.forEach(function(name) {
            var fitem = fitemFor(name);
            if (!fitem) {
                return;
            }
            if (fitem.classList.contains('error') || fitem.classList.contains('has-danger') ||
                fitem.querySelector('.form-control-feedback, .invalid-feedback, .error')) {
                markDate(name, true);
            }
        });
    }
    function run() {
        DATE_FIELDS.forEach(bindDate);
        markServerErrors();
        var form = document.querySelector('form.userstatement-statement-form') || document.querySelector('form.mform');
        if (form && form.getAttribute('data-userstatement-date-submit') !== '1') {
            form.setAttribute('data-userstatement-date-submit', '1');
            form.addEventListener('submit', function(e) {
                var firstInvalid = validateAll();
                if (firstInvalid) {
                    e.preventDefault();
                    e.stopPropagation();
                    firstInvalid.focus();
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }, true);
            var submitBtn = form.querySelector('#id_submitbutton');
            if (submitBtn && submitBtn.getAttribute('data-userstatement-date-click') !== '1') {
                submitBtn.setAttribute('data-userstatement-date-click', '1');
                submitBtn.addEventListener('click', function() {
                    validateAll();
                });
            }
        }
    }
    run();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    }
    window.addEventListener('load', run);
})();
EOT;
    $PAGE->requires->js_init_code($js);
}

/**
 * Поля формы для сохранения в JSON.
 *
 * @param \stdClass $data
 * @return string
 */
function userstatement_serialize_submission(\stdClass $data) {
    $fields = [
        'birthdate', 'snils', 'gender', 'citizenship', 'edu_level', 'edu_institution',
        'diploma_lastname', 'diploma_series', 'diploma_number', 'qualification', 'diploma_date',
        'workplace', 'position', 'experience_position', 'pedagogical_experience', 'subjects',
        'degree_title', 'phone', 'confirmaccuracy',
    ];
    $out = [];
    foreach ($fields as $f) {
        if (!property_exists($data, $f)) {
            continue;
        }
        if (in_array($f, userstatement_required_date_fields(), true)) {
            $normalized = userstatement_form_date_to_storage($data->$f, $f);
            if ($normalized !== null) {
                $out[$f] = (array) $normalized;
            }
            continue;
        }
        $out[$f] = $data->$f;
    }
    if (isset($out['snils'])) {
        $out['snils'] = userstatement_normalize_snils_digits($out['snils']);
    }
    if (isset($out['phone'])) {
        $out['phone'] = userstatement_normalize_phone_digits($out['phone']);
    }
    return json_encode($out, JSON_UNESCAPED_UNICODE);
}

/**
 * Дата начала курса из date_selector (или timestamp) в Unix time, 0 если не задана.
 *
 * @param mixed $value
 * @return int
 */
function userstatement_coursestart_to_unix($value) {
    if ($value === null || $value === '' || $value === 0 || $value === '0') {
        return 0;
    }
    if (is_numeric($value)) {
        $ts = (int) $value;
        return $ts !== 0 ? $ts : 0;
    }
    if (is_object($value)) {
        $value = (array) $value;
    }
    if (!is_array($value)) {
        return 0;
    }
    if (array_key_exists('enabled', $value) && empty($value['enabled'])) {
        return 0;
    }
    $year = isset($value['year']) ? (int) $value['year'] : 0;
    $month = isset($value['month']) ? (int) $value['month'] : 0;
    $day = isset($value['day']) ? (int) $value['day'] : 0;
    if ($year < 1 || $month < 1 || $day < 1) {
        return 0;
    }
    return make_timestamp($year, $month, $day, 12, 0, 0);
}

/**
 * Unix-время даты начала курса для PDF: из настроек элемента или из даты начала курса.
 *
 * @param \stdClass $instance Запись userstatement.
 * @param \stdClass|null $course Курс (id, startdate); при null подгружается по instance->course.
 * @return int
 */
function userstatement_resolve_coursestart_ts($instance, $course = null) {
    global $DB;

    $ts = isset($instance->coursestart) ? (int) $instance->coursestart : 0;
    if ($ts !== 0) {
        return $ts;
    }
    if ($course === null && !empty($instance->course)) {
        $course = $DB->get_record('course', ['id' => $instance->course], 'id,startdate', IGNORE_MISSING);
    }
    if ($course && !empty($course->startdate)) {
        return (int) $course->startdate;
    }
    return 0;
}

/**
 * Параметры URL страницы элемента (с учётом выбранной группы).
 *
 * @param int $cmid
 * @param int $groupid
 * @param array $extra
 * @return array
 */
function userstatement_view_page_params($cmid, $groupid = 0, array $extra = []) {
    $p = array_merge(['id' => $cmid], $extra);
    if ($groupid > 0) {
        $p['group'] = $groupid;
    }
    return $p;
}

/**
 * Фильтр списка: -1 все, 0 непроверенные, 1 проверенные.
 *
 * @param mixed $raw
 * @return int
 */
function userstatement_normalize_verified_filter($raw) {
    $v = (int) $raw;
    if ($v === 0 || $v === 1) {
        return $v;
    }
    return -1;
}

/**
 * Имя пользователя для отображения (только firstname).
 *
 * @param \stdClass $user
 * @return string
 */
function userstatement_user_firstname(\stdClass $user): string {
    return trim((string) ($user->firstname ?? ''));
}

/**
 * Допустимые поля сортировки списка заявлений.
 *
 * @return string[]
 */
function userstatement_submissions_sort_fields(): array {
    return ['timemodified', 'verified'];
}

/**
 * @param mixed $sort
 * @return string
 */
function userstatement_normalize_submissions_sort($sort): string {
    $sort = strtolower(trim((string) $sort));
    return in_array($sort, userstatement_submissions_sort_fields(), true) ? $sort : 'timemodified';
}

/**
 * @param mixed $dir
 * @return string asc|desc
 */
function userstatement_normalize_submissions_sortdir($dir): string {
    $dir = strtolower(trim((string) $dir));
    return $dir === 'asc' ? 'asc' : 'desc';
}

/**
 * @param string $sort
 * @param string $sortdir
 * @return string
 */
function userstatement_submissions_order_sql(string $sort, string $sortdir): string {
    $sort = userstatement_normalize_submissions_sort($sort);
    $sortdir = userstatement_normalize_submissions_sortdir($sortdir);
    $dir = $sortdir === 'asc' ? 'ASC' : 'DESC';
    if ($sort === 'verified') {
        return " ORDER BY s.verified $dir, s.timemodified DESC";
    }
    return " ORDER BY s.timemodified $dir";
}

/**
 * Заголовок сортируемой колонки таблицы заявлений.
 *
 * @param \mod_userstatement\local\view_page $page
 * @param string $column
 * @param string $label
 * @param string $search
 * @param int $verifiedfilter
 * @param string $currentsort
 * @param string $currentdir
 * @return string
 */
function userstatement_submissions_sort_header(
    \mod_userstatement\local\view_page $page,
    string $column,
    string $label,
    string $search,
    int $verifiedfilter,
    string $currentsort,
    string $currentdir
): string {
    $currentsort = userstatement_normalize_submissions_sort($currentsort);
    $currentdir = userstatement_normalize_submissions_sortdir($currentdir);
    $newdir = ($currentsort === $column && $currentdir === 'desc') ? 'asc' : 'desc';
    $url = $page->url_view(userstatement_submissions_list_url_extra($search, $verifiedfilter, 0, $column, $newdir));
    $arrow = '';
    if ($currentsort === $column) {
        $arrow = $currentdir === 'asc' ? ' ▲' : ' ▼';
    }
    return html_writer::link($url, $label . $arrow);
}

/**
 * Query-параметры списка заявлений (поиск, фильтр проверки, страница, сортировка).
 *
 * @param string $search
 * @param int $verifiedfilter
 * @param int $pageindex
 * @param string $sort
 * @param string $sortdir
 * @return array
 */
function userstatement_submissions_list_url_extra($search, $verifiedfilter, $pageindex = 0, $sort = 'timemodified', $sortdir = 'desc') {
    $extra = ['tab' => 'submissions'];
    $search = trim($search);
    if ($search !== '') {
        $extra['search'] = $search;
    }
    if ($verifiedfilter >= 0) {
        $extra['verifiedfilter'] = $verifiedfilter;
    }
    if ($pageindex > 0) {
        $extra['page'] = $pageindex;
    }
    $extra['sort'] = userstatement_normalize_submissions_sort($sort);
    $extra['sortdir'] = userstatement_normalize_submissions_sortdir($sortdir);
    return $extra;
}

/**
 * Группы, доступные пользователю в элементе курса (ядро с Moodle 4.3; для 3.8 — запасной вариант).
 *
 * @param \stdClass|\cm_info $cm
 * @param int $userid
 * @return array<int, \stdClass>
 */
function userstatement_get_activity_allowed_groups($cm, $userid = 0) {
    global $USER;

    if (function_exists('groups_get_activity_allowed_groups')) {
        return groups_get_activity_allowed_groups($cm, $userid);
    }

    if (empty($userid)) {
        $userid = (int) $USER->id;
    }

    $course = get_course($cm->course);
    if (!groups_get_activity_groupmode($cm, $course)) {
        return [];
    }

    $context = context_course::instance($course->id);
    if (has_capability('moodle/site:accessallgroups', $context, $userid)) {
        return groups_get_all_groups($course->id, 0, $cm->groupingid);
    }

    return groups_get_all_groups($course->id, $userid, $cm->groupingid);
}

/**
 * Число заявлений на странице списка.
 *
 * @return int
 */
function userstatement_submissions_per_page() {
    return 20;
}

/**
 * Синхронизация отметки завершения элемента курса с галочкой «Проверено».
 *
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $userid
 * @param bool $verified
 */
function userstatement_sync_completion_for_user(\stdClass $cm, \stdClass $course, int $userid, bool $verified) {
    global $DB;

    $instance = $DB->get_record('userstatement', ['id' => $cm->instance], 'completionverified', IGNORE_MISSING);
    if (!$instance || empty($instance->completionverified)) {
        return;
    }

    $completion = new completion_info($course);
    if (!$completion->is_enabled($cm)) {
        return;
    }
    if ($verified) {
        $completion->update_state($cm, COMPLETION_COMPLETE, $userid);
    } else {
        $completion->update_state($cm, COMPLETION_INCOMPLETE, $userid);
    }
}

/**
 * Автоматическое завершение (Moodle 3.8: этот callback; Moodle 4+ — также custom_completion).
 *
 * @param stdClass $course
 * @param stdClass $cm
 * @param int $userid
 * @param bool $type
 * @return bool
 */
function userstatement_get_completion_state($course, $cm, $userid, $type) {
    global $DB;

    $instance = $DB->get_record('userstatement', ['id' => $cm->instance], 'completionverified', IGNORE_MISSING);
    if (!$instance || empty($instance->completionverified)) {
        return $type;
    }

    $sub = $DB->get_record('userstatement_submission', [
        'userstatement' => $cm->instance,
        'userid' => $userid,
    ], 'verified', IGNORE_MISSING);

    if ($sub && userstatement_submission_is_verified($sub)) {
        return true;
    }
    return false;
}

/**
 * @param \stdClass $coursemodule
 * @return \cached_cm_info|false
 */
function userstatement_instance_has_visible_intro($instance): bool {
    if (!is_object($instance) || !property_exists($instance, 'intro')) {
        return false;
    }
    return trim(strip_tags((string) $instance->intro)) !== '';
}

/**
 * @param \stdClass $coursemodule
 * @return \cached_cm_info|false
 */
function userstatement_get_coursemodule_info($coursemodule) {
    global $DB;

    if (!$record = $DB->get_record('userstatement', ['id' => $coursemodule->instance],
        'id, name, intro, introformat, completionverified')) {
        return false;
    }

    $info = new cached_cm_info();
    $info->name = $record->name;
    // content — только для списка элементов на странице курса (showdescription), не на view.php.
    if (!empty($coursemodule->showdescription) && userstatement_instance_has_visible_intro($record)) {
        $info->content = format_module_intro('userstatement', $record, $coursemodule->id, false);
    }
    if ($coursemodule->completion == COMPLETION_TRACKING_AUTOMATIC) {
        $info->customdata['customcompletionrules']['completionverified'] = (int) $record->completionverified;
    }
    return $info;
}

/**
 * Описания активных правил завершения (для отчётов и ограничения доступа).
 *
 * @param \cm_info|\stdClass $cm
 * @return string[]
 */
function mod_userstatement_get_completion_active_rule_descriptions($cm) {
    if (empty($cm->customdata['customcompletionrules']) || $cm->completion != COMPLETION_TRACKING_AUTOMATIC) {
        return [];
    }
    $descriptions = [];
    if (!empty($cm->customdata['customcompletionrules']['completionverified'])) {
        $descriptions[] = get_string('completiondetail:verified', 'userstatement');
    }
    return $descriptions;
}

/**
 * Заявление отмечено проверенным (поле verified в БД).
 *
 * @param \stdClass $submission
 * @return bool
 */
function userstatement_submission_is_verified($submission) {
    return !empty($submission->verified);
}

/**
 * Проверка group из запроса экспорта/фильтра (только разрешённые для пользователя группы).
 *
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $foruserid
 * @return int id группы или 0
 */
function userstatement_normalize_export_groupid($cm, $course, $foruserid) {
    $gid = optional_param('group', 0, PARAM_INT);
    if ($gid <= 0 || !groups_get_activity_groupmode($cm, $course)) {
        return 0;
    }
    $allowed = userstatement_get_activity_allowed_groups($cm, $foruserid);
    if (!isset($allowed[$gid])) {
        return 0;
    }
    return (int) $gid;
}

/**
 * SQL-фрагмент JOIN для фильтра заявок по группе.
 *
 * @param int $groupid
 * @return array{join: string, params: array<string, int>}
 */
function userstatement_submissions_group_join_sql($groupid) {
    if ($groupid <= 0) {
        return ['join' => '', 'params' => []];
    }
    return [
        'join' => ' JOIN {groups_members} gmm ON gmm.userid = s.userid AND gmm.groupid = :gmmgid ',
        'params' => ['gmmgid' => $groupid],
    ];
}

/**
 * Лимит PDF в одном ZIP (защита от таймаута и нехватки памяти).
 *
 * @return int
 */
function userstatement_zip_pdf_limit() {
    return 80;
}

/**
 * Показывать логин слушателя в реестре Excel (только администраторы сайта).
 *
 * @param int $userid 0 — текущий пользователь
 * @return bool
 */
function userstatement_registry_export_includes_username($userid = 0) {
    global $USER;
    $userid = $userid > 0 ? $userid : (int) $USER->id;
    if (is_siteadmin($userid)) {
        return true;
    }
    return has_capability('moodle/site:config', \context_system::instance(), $userid);
}

/**
 * Увеличить лимиты PHP на время тяжёлого экспорта.
 */
function userstatement_raise_export_limits() {
    if (class_exists('\core_php_time_limit')) {
        \core_php_time_limit::raise(600);
    } else {
        @set_time_limit(600);
    }
    if (function_exists('raise_memory_limit')) {
        raise_memory_limit(MEMORY_EXTRA);
    }
}

/**
 * Непустое значение поля даты (date_selector в форме или из JSON).
 *
 * @param mixed $v
 * @return bool
 */
function userstatement_date_value_nonempty($v) {
    return userstatement_date_parts($v) !== null;
}

/**
 * Серверная проверка данных заявки перед сохранением (защита от подделки POST).
 *
 * @param \stdClass $data
 * @param array $options requireconfirm (bool, default true)
 * @return string пустая строка если ОК, иначе ключ строки языка плагина
 */
function userstatement_validate_submission_for_save(\stdClass $data, array $options = []) {
    $data = userstatement_normalize_stored_submission($data) ?? $data;
    $errors = userstatement_form_validation_errors($data, $options);
    if ($errors === []) {
        return '';
    }
    if (isset($errors['confirmaccuracy'])) {
        return 'confirmrequired';
    }
    if (isset($errors['snils'])) {
        return 'invalidsnils';
    }
    if (isset($errors['phone']) && $errors['phone'] !== get_string('fieldempty', 'userstatement')) {
        return 'invalidphone';
    }
    return 'validationserverfield';
}

/**
 * Можно ли считать сохранённый JSON «полной» заявкой (блокировка повторной подачи для слушателя).
 *
 * @param string|null $raw
 * @return bool
 */
function userstatement_submission_is_locked_payload($raw) {
    if ($raw === null || trim((string) $raw) === '' || trim((string) $raw) === '{}') {
        return false;
    }
    $data = json_decode($raw);
    if (!is_object($data)) {
        return false;
    }
    return userstatement_validate_submission_for_save($data) === '';
}

/**
 * Контактный телефон из сохранённой заявки (для списка проверяющего).
 *
 * @param string|null $raw JSON заявки
 * @return string
 */
function userstatement_submission_display_phone($raw) {
    if ($raw === null || trim((string) $raw) === '') {
        return '';
    }
    $data = json_decode($raw);
    if (!is_object($data) || !isset($data->phone) || trim((string) $data->phone) === '') {
        return '';
    }
    $display = userstatement_format_phone_display($data->phone);
    return $display !== '' ? $display : trim((string) $data->phone);
}

/**
 * Место работы из сохранённой заявки (для списка проверяющего).
 *
 * @param string|null $raw JSON заявки
 * @return string
 */
function userstatement_submission_display_workplace($raw) {
    if ($raw === null || trim((string) $raw) === '') {
        return '';
    }
    $data = json_decode($raw);
    if (!is_object($data) || !isset($data->workplace)) {
        return '';
    }
    return trim((string) $data->workplace);
}

/**
 * Проверка прав, выборка данных и отправка PDF в браузер (без вывода страницы Moodle).
 *
 * @param \context $context Контекст модуля (CONTEXT_MODULE).
 * @param \stdClass $instance Запись {userstatement}.
 * @param int $userid 0 — текущий пользователь; иначе чужая заявка (нужно viewall).
 */
function userstatement_send_pdf_download(\context $context, \stdClass $instance, $userid = 0) {
    global $DB, $USER;

    $userid = (int) $userid;
    if ($userid <= 0 || $userid === (int) $USER->id) {
        require_capability('mod/userstatement:submit', $context);
        $userid = (int) $USER->id;
    } else {
        require_capability('mod/userstatement:viewall', $context);
    }

    $sub = $DB->get_record('userstatement_submission', [
        'userstatement' => $instance->id,
        'userid' => $userid,
    ], '*', MUST_EXIST);

    $user = core_user::get_user($userid, '*', MUST_EXIST);
    $data = json_decode($sub->data);
    if (is_array($data)) {
        $data = (object) $data;
    }
    if (!is_object($data)) {
        throw new moodle_exception('submissionmissing', 'userstatement');
    }
    $data = userstatement_normalize_stored_submission($data);
    if ($data === null) {
        throw new moodle_exception('submissionmissing', 'userstatement');
    }
    $v = userstatement_validate_submission_for_save($data, ['requireconfirm' => false]);
    if ($v !== '') {
        throw new moodle_exception('submissioninvalid', 'userstatement');
    }

    \mod_userstatement\statement_pdf::send_download($instance, $user, $data);
}

/**
 * Группа для фоновой выгрузки: 0 = весь курс, иначе id группы.
 *
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $userid
 * @param bool $exportall
 * @param int $groupparam
 * @return int
 */
function userstatement_resolve_bulk_export_groupid($cm, $course, $userid, $exportall, $groupparam) {
    if ($exportall) {
        return 0;
    }
    if ($groupparam < 1) {
        throw new \moodle_exception('bulkexportgrouprequired', 'userstatement');
    }
    $allowed = userstatement_get_activity_allowed_groups($cm, $userid);
    if (!isset($allowed[$groupparam])) {
        throw new \moodle_exception('bulkexportinvalidgroup', 'userstatement');
    }
    return (int) $groupparam;
}

/**
 * Подпись области выгрузки (курс или группа).
 *
 * @param int $groupid
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $userid
 * @return string
 */
function userstatement_bulk_export_scope_label($groupid, $cm, $course, $userid) {
    if ((int) $groupid <= 0) {
        return get_string('bulkexportscope_course', 'userstatement');
    }
    $allowed = userstatement_get_activity_allowed_groups($cm, $userid);
    if (isset($allowed[$groupid])) {
        return get_string('bulkexportscope_group', 'userstatement', $allowed[$groupid]->name);
    }
    return get_string('bulkexportscope_groupid', 'userstatement', $groupid);
}

/**
 * Блок поиска и фильтров на странице списка заявлений.
 *
 * @param \mod_userstatement\local\view_page $page
 * @param string $search
 * @param int $verifiedfilter
 */
function userstatement_render_submissions_filter_block(
    \mod_userstatement\local\view_page $page,
    string $search,
    int $verifiedfilter,
    string $sort = 'timemodified',
    string $sortdir = 'desc'
) {
    echo html_writer::start_div('userstatement-toolbar-block userstatement-toolbar-filters');
    echo html_writer::tag('h4', get_string('toolbar_filters', 'userstatement'));
    echo html_writer::start_tag('form', [
        'method' => 'get',
        'action' => $page->url_view(['tab' => 'submissions'])->out(false),
        'class' => 'userstatement-search-form mb-0',
    ]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $page->cm->id]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'tab', 'value' => 'submissions']);
    if ($page->exportgroupid > 0) {
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'group', 'value' => $page->exportgroupid]);
    }
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sort', 'value' => userstatement_normalize_submissions_sort($sort)]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sortdir', 'value' => userstatement_normalize_submissions_sortdir($sortdir)]);
    echo html_writer::start_div('userstatement-search-row');
    echo html_writer::tag('label', get_string('searchparticipant', 'userstatement'), [
        'for' => 'userstatement-search',
        'class' => 'mb-0 userstatement-search-label',
    ]);
    echo html_writer::empty_tag('input', [
        'type' => 'text',
        'name' => 'search',
        'id' => 'userstatement-search',
        'value' => s($search),
        'size' => 40,
        'class' => 'form-control',
        'placeholder' => get_string('searchparticipantplaceholder', 'userstatement'),
    ]);
    echo html_writer::empty_tag('input', [
        'type' => 'submit',
        'value' => get_string('search'),
        'class' => 'btn btn-secondary',
    ]);
    echo html_writer::tag('label', get_string('filterverified', 'userstatement'), [
        'for' => 'userstatement-vfilter',
        'class' => 'mb-0 userstatement-search-label ms-2',
    ]);
    echo html_writer::select([
        -1 => get_string('filterverifiedall', 'userstatement'),
        1 => get_string('filterverifiedyes', 'userstatement'),
        0 => get_string('filterverifiedno', 'userstatement'),
    ], 'verifiedfilter', $verifiedfilter, false, [
        'id' => 'userstatement-vfilter',
        'class' => 'form-select ms-1',
    ]);
    if ($search !== '' || $verifiedfilter >= 0) {
        echo html_writer::link($page->url_view(['tab' => 'submissions']), get_string('clear'), ['class' => 'btn btn-link']);
    }
    echo html_writer::end_div();
    echo html_writer::end_tag('form');
    echo html_writer::end_div();
}

/**
 * Блок кнопок скачивания на странице списка заявлений.
 *
 * @param \mod_userstatement\local\view_page $page
 */
function userstatement_render_submissions_download_block(\mod_userstatement\local\view_page $page) {
    global $OUTPUT;

    $exportbase = ['id' => $page->cm->id, 'sesskey' => sesskey()];
    if ($page->exportgroupid > 0) {
        $exportbase['group'] = $page->exportgroupid;
    }

    echo html_writer::start_div('userstatement-toolbar-block userstatement-toolbar-downloads');
    echo html_writer::tag('h4', get_string('toolbar_downloads', 'userstatement'));
    echo html_writer::start_div('userstatement-download-actions');
    echo $OUTPUT->single_button(
        new \moodle_url('/mod/userstatement/export_fields.php', $exportbase),
        get_string('downloadreestrxlsx', 'userstatement'),
        'get'
    );
    echo $OUTPUT->single_button(
        new \moodle_url('/mod/userstatement/export_registry.php', $exportbase),
        get_string('downloadfisfrdoxlsx', 'userstatement'),
        'get'
    );
    echo $OUTPUT->single_button(
        new \moodle_url('/mod/userstatement/export_full_zip.php', $exportbase),
        get_string('downloadfullzip', 'userstatement', userstatement_zip_pdf_limit()),
        'get'
    );
    echo html_writer::end_div();
    userstatement_render_bulk_export_buttons($page);
    echo html_writer::end_div();
}

/**
 * Кнопки фоновой выгрузки: весь курс и (отдельно) выбранная группа.
 *
 * @param \mod_userstatement\local\view_page $page
 */
function userstatement_render_bulk_export_buttons(\mod_userstatement\local\view_page $page) {
    global $OUTPUT, $USER;

    $base = ['id' => $page->cm->id, 'sesskey' => sesskey()];
    $exportallurl = new \moodle_url('/mod/userstatement/export_bulk_start.php', $base + ['all' => 1]);

    echo html_writer::start_div('userstatement-bulk-export-buttons');
    echo $OUTPUT->single_button($exportallurl, get_string('downloadbulkexport_all', 'userstatement'), 'post');

    if (groups_get_activity_groupmode($page->cm, $page->course)) {
        if ($page->exportgroupid > 0) {
            $allowed = userstatement_get_activity_allowed_groups($page->cm, $USER->id);
            $gname = isset($allowed[$page->exportgroupid]) ? $allowed[$page->exportgroupid]->name : '';
            $exportgroupurl = new \moodle_url('/mod/userstatement/export_bulk_start.php', $base + [
                'group' => $page->exportgroupid,
            ]);
            echo ' ';
            echo $OUTPUT->single_button(
                $exportgroupurl,
                get_string('downloadbulkexport_group', 'userstatement', $gname),
                'post'
            );
        } else {
            echo html_writer::tag('p', get_string('downloadbulkexport_group_select', 'userstatement'), [
                'class' => 'small text-muted mb-0 mt-1',
            ]);
        }
    }

    echo html_writer::tag('p', get_string('downloadbulkexport_help', 'userstatement'), [
        'class' => 'small text-muted mb-0 mt-1',
    ]);
    echo html_writer::end_div();
}

/**
 * Отдача ZIP-частей фоновой выгрузки.
 *
 * @param mixed $course
 * @param mixed $cm
 * @param \context $context
 * @param string $filearea
 * @param array $args
 * @param bool $forcedownload
 * @param array $options
 * @return bool
 */
function mod_userstatement_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    global $DB;

    if ($context->contextlevel != CONTEXT_MODULE || $filearea !== \mod_userstatement\local\bulk_export_service::FILEAREA) {
        return false;
    }

    require_login($course, true, $cm);
    require_capability('mod/userstatement:viewall', $context);

    $exportid = (int) array_shift($args);
    $export = $DB->get_record('userstatement_export', ['id' => $exportid], '*', IGNORE_MISSING);
    if (!$export || (int) $export->userstatement !== (int) $cm->instance || $export->status !== \mod_userstatement\local\bulk_export_service::STATUS_COMPLETE) {
        return false;
    }

    $filename = array_pop($args);
    $filepath = $args ? '/' . implode('/', $args) . '/' : '/';

    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'mod_userstatement', $filearea, $exportid, $filepath, $filename);
    if (!$file || $file->is_directory()) {
        return false;
    }

    send_stored_file($file, null, 0, $forcedownload, $options);
}

/**
 * Блок статуса фоновых выгрузок на вкладке «Заявления».
 *
 * @param \mod_userstatement\local\view_page $page
 */
function userstatement_render_bulk_export_panel(\mod_userstatement\local\view_page $page) {
    global $OUTPUT, $DB;

    $exports = \mod_userstatement\local\bulk_export_service::list_recent((int) $page->instance->id, 6);
    if (!$exports) {
        return;
    }

    echo html_writer::tag('h4', get_string('bulkexportheading', 'userstatement'), ['class' => 'mt-3']);
    echo html_writer::tag('p', get_string('bulkexporthelp', 'userstatement'), ['class' => 'text-muted small']);

    $table = new html_table();
    $table->head = [
        get_string('bulkexportcolwhen', 'userstatement'),
        get_string('bulkexportcolwho', 'userstatement'),
        get_string('bulkexportcolscope', 'userstatement'),
        get_string('bulkexportcolstatus', 'userstatement'),
        get_string('bulkexportcoldownload', 'userstatement'),
    ];
    $table->attributes['class'] = 'generaltable table-sm';

    foreach ($exports as $export) {
        $user = $DB->get_record('user', ['id' => $export->requestedby], 'id,firstname,lastname', IGNORE_MISSING);
        $whotext = $user ? userstatement_user_firstname($user) : (string) $export->requestedby;
        $statuskey = 'bulkexportstatus_' . $export->status;
        $status = get_string($statuskey, 'userstatement');
        if ($export->status === \mod_userstatement\local\bulk_export_service::STATUS_FAILED && !empty($export->errormsg)) {
            $status .= html_writer::tag('div', s($export->errormsg), ['class' => 'text-danger small']);
        }
        if ($export->status === \mod_userstatement\local\bulk_export_service::STATUS_COMPLETE) {
            $status .= html_writer::tag('span', ' (' . get_string('bulkexportpdfcount', 'userstatement', (object) [
                'count' => $export->pdfcount,
                'parts' => $export->partcount,
            ]) . ')', ['class' => 'small text-muted']);
        }

        $links = '';
        if ($export->status === \mod_userstatement\local\bulk_export_service::STATUS_COMPLETE) {
            $parts = [];
            for ($p = 1; $p <= (int) $export->partcount; $p++) {
                $url = \mod_userstatement\local\bulk_export_service::part_download_url($export, $page->context, $p);
                if ($url) {
                    $parts[] = html_writer::link($url, get_string('bulkexportpart', 'userstatement', $p));
                }
            }
            $links = implode(' · ', $parts);
        }

        $scope = userstatement_bulk_export_scope_label(
            (int) $export->groupid,
            $page->cm,
            $page->course,
            (int) $export->requestedby
        );

        $table->data[] = [
            userdate($export->timecreated),
            s($whotext),
            s($scope),
            $status,
            $links,
        ];
    }

    echo html_writer::table($table);
}
