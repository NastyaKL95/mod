<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_usercontract;

defined('MOODLE_INTERNAL') || die();

use mod_usercontract\local\contract_body;

/**
 * Генерация PDF договора-оферты.
 */
class contract_pdf {

    /**
     * @param \stdClass $instance
     * @param \stdClass $user
     * @param \stdClass $learner
     * @param \context_module $context
     * @return string
     */
    public static function render_binary(
        \stdClass $instance,
        \stdClass $user,
        \stdClass $learner,
        \context_module $context
    ) {
        global $CFG, $DB;

        if (!file_exists($CFG->libdir . '/pdflib.php')) {
            throw new \moodle_exception('error_pdflib', 'usercontract');
        }

        require_once($CFG->libdir . '/pdflib.php');

        $course = $DB->get_record('course', ['id' => $instance->course], 'id,fullname', MUST_EXIST);
        $program = trim(format_string($course->fullname));
        $hours = (int) ($instance->programhours ?? 0);
        $representative = trim($instance->representative ?? '');
        if ($representative === '') {
            $representative = get_string('default_representative', 'usercontract');
        }

        $pdf = new \pdf();
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $marginmm = 15;
        $pdf->SetMargins($marginmm, $marginmm, $marginmm);
        $pdf->SetAutoPageBreak(true, $marginmm);
        if (method_exists($pdf, 'setCellHeightRatio')) {
            $pdf->setCellHeightRatio(0.92);
        }
        if (method_exists($pdf, 'setJPEGQuality')) {
            $pdf->setJPEGQuality(82);
        }
        $pdf->AddPage();
        $pdf->SetFont('freeserif', '', 8);

        usercontract_install_default_images_if_empty($context);

        $htmlstyle = '<style>body{margin:0;padding:0;}</style>';
        $htmlbody = contract_body::build_html($program, $hours, $learner, $representative, '', '', false);
        $htmlfooter = contract_body::build_footer_html($learner);
        $html = $htmlstyle . $htmlbody . $htmlfooter;

        $pdf->writeHTML($html, true, false, true, false, '');

        usercontract_pdf_overlay_seals($pdf, $context, [
            'page' => (int) $pdf->getPage(),
            'ybottom' => (float) $pdf->GetY(),
        ]);

        return $pdf->Output('', 'S');
    }

    /**
     * @param \stdClass $instance
     * @param \stdClass $user
     * @param \stdClass $learner
     * @param \context_module $context
     */
    public static function send_download(
        \stdClass $instance,
        \stdClass $user,
        \stdClass $learner,
        \context_module $context
    ) {
        while (ob_get_level()) {
            ob_end_clean();
        }

        $content = self::render_binary($instance, $user, $learner, $context);
        $filename = 'dogovor_' . clean_filename(usercontract_user_firstname($user)) . '_' . clean_filename($user->username) . '.pdf';

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($content));
        header('Cache-Control: private, must-revalidate, pre-check=0, post-check=0, max-age=0');
        echo $content;
        exit;
    }
}
