<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_usercontract\form;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/formslib.php');

/**
 * Принятие договора-оферты (телефон и место работы — в форме элемента).
 */
class accept_form extends \moodleform {

    /**
     * @param \stdClass $learner firstname, phone, workplace (значения по умолчанию)
     */
    public function definition() {
        $mform = $this->_form;
        $learner = $this->_customdata['learner'];
        $mform->updateAttributes(['class' => 'mform usercontract-accept-form']);

        $mform->addElement('static', 'learnerfirstname', get_string('field_firstname', 'usercontract'),
            s($learner->firstname));

        $mform->addElement('header', 'hdr_learner', get_string('section_learner', 'usercontract'));

        $mform->addElement('text', 'phone', get_string('field_phone', 'usercontract'),
            usercontract_accept_text_attrs(['usercontract-phone'], [
                'title' => get_string('phone_mask_title', 'usercontract'),
                'spellcheck' => 'false',
                'inputmode' => 'tel',
                'autocomplete' => 'tel',
            ]));
        $mform->setType('phone', PARAM_TEXT);
        $mform->addRule('phone', get_string('fieldempty', 'usercontract'), 'required', null, 'client');
        $mform->addRule('phone', get_string('fieldempty', 'usercontract'), 'required', null, 'server');

        $mform->addElement('textarea', 'workplace', get_string('field_workplace', 'usercontract'),
            usercontract_accept_textarea_attrs([], ['autocomplete' => 'off']));
        $mform->setType('workplace', PARAM_TEXT);
        $mform->addRule('workplace', get_string('fieldempty', 'usercontract'), 'required', null, 'client');
        $mform->addRule('workplace', get_string('fieldempty', 'usercontract'), 'required', null, 'server');

        $mform->addElement('header', 'hdr_accept', get_string('confirmaccept', 'usercontract'));
        $mform->addElement('checkbox', 'confirmaccept', '', get_string('confirmaccept', 'usercontract'));
        $mform->setType('confirmaccept', PARAM_INT);

        $this->add_action_buttons(false, get_string('acceptandsave', 'usercontract'));

        global $PAGE;
        if ($PAGE) {
            usercontract_accept_form_layout_init();
            usercontract_phone_mask_init();
        }
    }

    /**
     * @param mixed $default_values
     */
    public function set_data($default_values) {
        if (is_object($default_values) && property_exists($default_values, 'phone')) {
            $pdigits = usercontract_normalize_phone_digits($default_values->phone);
            if (usercontract_phone_digits_valid($pdigits)) {
                $default_values->phone = usercontract_format_phone_masked($pdigits);
            }
        } else if (is_array($default_values) && array_key_exists('phone', $default_values)) {
            $pdigits = usercontract_normalize_phone_digits($default_values['phone'] ?? '');
            if (usercontract_phone_digits_valid($pdigits)) {
                $default_values['phone'] = usercontract_format_phone_masked($pdigits);
            }
        }
        parent::set_data($default_values);
    }

    /**
     * @return \stdClass|false
     */
    public function get_data() {
        $data = parent::get_data();
        if ($data && property_exists($data, 'phone')) {
            $data->phone = usercontract_normalize_phone_digits($data->phone);
        }
        if ($data && property_exists($data, 'workplace')) {
            $data->workplace = trim((string) $data->workplace);
        }
        return $data;
    }

    /**
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        if (empty($data['confirmaccept'])) {
            $errors['confirmaccept'] = get_string('confirmrequired', 'usercontract');
        }
        return $errors + usercontract_accept_form_validation_errors($data);
    }
}
