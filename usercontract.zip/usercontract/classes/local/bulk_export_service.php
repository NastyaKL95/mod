<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_usercontract\local;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->dirroot . '/mod/usercontract/lib.php');

/**
 * Полная выгрузка PDF договоров по шагам в браузере (без cron).
 */
class bulk_export_service {

    public const STATUS_PENDING = 'pending';
    public const STATUS_PROCESSING = 'processing';
    public const STATUS_COMPLETE = 'complete';
    public const STATUS_FAILED = 'failed';

    public const FILEAREA = 'bulkexport';

    public static function sync_zip_limit(): int {
        return usercontract_zip_pdf_limit();
    }

    public static function chunk_size(): int {
        return 100;
    }

    public static function create_job(int $instanceid, int $userid, int $groupid): int {
        global $DB;

        if ($DB->record_exists_select(
            'usercontract_export',
            'usercontract = ? AND requestedby = ? AND status IN (?, ?)',
            [$instanceid, $userid, self::STATUS_PENDING, self::STATUS_PROCESSING]
        )) {
            throw new \moodle_exception('bulkexportalreadyrunning', 'usercontract');
        }

        self::cleanup_old_exports($instanceid);

        $now = time();
        return (int) $DB->insert_record('usercontract_export', (object) [
            'usercontract' => $instanceid,
            'requestedby' => $userid,
            'groupid' => $groupid,
            'status' => self::STATUS_PENDING,
            'partcount' => 0,
            'pdfcount' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
        ]);
    }

    public static function process_next_step(int $exportid): \stdClass {
        global $DB;

        @ignore_user_abort(true);
        usercontract_raise_export_limits();

        $result = (object) [
            'complete' => false,
            'failed' => false,
            'message' => '',
            'processed' => 0,
            'total' => 0,
            'parts' => 0,
            'percent' => 0,
        ];

        $export = $DB->get_record('usercontract_export', ['id' => $exportid], '*', MUST_EXIST);

        if ($export->status === self::STATUS_COMPLETE) {
            $result->complete = true;
            $result->processed = (int) $export->pdfcount;
            $result->total = (int) $export->pdfcount;
            $result->parts = (int) $export->partcount;
            $result->percent = 100;
            return $result;
        }
        if ($export->status === self::STATUS_FAILED) {
            $result->failed = true;
            $result->message = (string) ($export->errormsg ?? '');
            return $result;
        }

        if (!class_exists('ZipArchive')) {
            self::fail($exportid, get_string('noziparchive', 'usercontract'));
            return self::process_next_step($exportid);
        }

        $instance = $DB->get_record('usercontract', ['id' => $export->usercontract], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('usercontract', $instance->id, 0, false, MUST_EXIST);
        $course = get_course($cm->course);
        $context = \context_module::instance($cm->id);

        try {
            if ($export->status === self::STATUS_PENDING) {
                self::initialize_job($exportid, $export, $instance, $context);
                $export = $DB->get_record('usercontract_export', ['id' => $exportid], '*', MUST_EXIST);
            }

            $state = self::decode_state($export->statedata);
            $total = count($state->validids);
            $result->total = $total;
            $result->processed = min((int) $state->nextindex, $total);
            $result->parts = (int) $export->partcount;

            if ($total === 0) {
                self::fail($exportid, get_string('bulkexportnopdfs', 'usercontract'));
                return self::process_next_step($exportid);
            }

            if ($state->nextindex >= $total) {
                self::finalize_job($exportid, $export, $instance, $cm, $course, $context);
                return self::process_next_step($exportid);
            }

            $sliceids = array_slice($state->validids, $state->nextindex, self::chunk_size());
            $chunk = self::load_submissions_chunk($sliceids, $instance, $context);

            $partnum = (int) $export->partcount + 1;
            $tmppath = self::build_part_zip($instance, $course, $context, $chunk);
            $courseshort = clean_filename(format_string($course->shortname, true));
            $filename = 'dogovory_' . $courseshort . '_part' . sprintf('%02d', $partnum) . '.zip';
            $fs = get_file_storage();
            if ($partnum === 1) {
                $fs->delete_area_files($context->id, 'mod_usercontract', self::FILEAREA, $exportid);
            }
            $fs->create_file_from_pathname([
                'contextid' => $context->id,
                'component' => 'mod_usercontract',
                'filearea' => self::FILEAREA,
                'itemid' => $exportid,
                'filepath' => '/',
                'filename' => $filename,
            ], $tmppath);
            @unlink($tmppath);

            $state->nextindex += count($sliceids);
            $DB->update_record('usercontract_export', (object) [
                'id' => $exportid,
                'status' => self::STATUS_PROCESSING,
                'partcount' => $partnum,
                'pdfcount' => (int) $export->pdfcount + count($sliceids),
                'statedata' => self::encode_state($state),
                'timemodified' => time(),
            ]);

            $result->processed = $state->nextindex;
            $result->parts = $partnum;
            $result->percent = $total > 0 ? round(100 * $state->nextindex / $total) : 0;

            if ($state->nextindex >= $total) {
                $export = $DB->get_record('usercontract_export', ['id' => $exportid], '*', MUST_EXIST);
                self::finalize_job($exportid, $export, $instance, $cm, $course, $context);
                return self::process_next_step($exportid);
            }

            return $result;
        } catch (\Throwable $e) {
            self::fail($exportid, $e->getMessage());
            return self::process_next_step($exportid);
        }
    }

    public static function run(int $exportid): void {
        while (true) {
            $r = self::process_next_step($exportid);
            if ($r->complete || $r->failed) {
                break;
            }
        }
    }

    public static function create_and_queue(int $instanceid, int $userid, int $groupid): int {
        return self::create_job($instanceid, $userid, $groupid);
    }

    public static function list_recent(int $instanceid, int $limit = 8): array {
        global $DB;
        return $DB->get_records('usercontract_export', ['usercontract' => $instanceid], 'timecreated DESC', '*', 0, $limit);
    }

    public static function part_download_url(\stdClass $export, \context_module $context, int $part): ?\moodle_url {
        if ($export->status !== self::STATUS_COMPLETE || $part < 1 || $part > (int) $export->partcount) {
            return null;
        }
        $fs = get_file_storage();
        $files = $fs->get_area_files($context->id, 'mod_usercontract', self::FILEAREA, $export->id, 'filename', false);
        $index = 0;
        foreach ($files as $file) {
            $index++;
            if ($index === $part) {
                return \moodle_url::make_pluginfile_url(
                    $context->id,
                    'mod_usercontract',
                    self::FILEAREA,
                    $export->id,
                    $file->get_filepath(),
                    $file->get_filename(),
                    true
                );
            }
        }
        return null;
    }

    protected static function initialize_job(
        int $exportid,
        \stdClass $export,
        \stdClass $instance,
        \context_module $context
    ): void {
        global $DB;

        $subs = self::fetch_submissions($instance->id, (int) $export->groupid);
        $valid = self::filter_valid_submissions($subs, $instance, $context);
        $validids = [];
        foreach ($valid as $sub) {
            $validids[] = (int) $sub->id;
        }

        $DB->update_record('usercontract_export', (object) [
            'id' => $exportid,
            'status' => self::STATUS_PROCESSING,
            'statedata' => self::encode_state((object) [
                'validids' => $validids,
                'nextindex' => 0,
            ]),
            'timemodified' => time(),
        ]);
    }

    protected static function finalize_job(
        int $exportid,
        \stdClass $export,
        \stdClass $instance,
        \stdClass $cm,
        \stdClass $course,
        \context_module $context
    ): void {
        global $DB;
        $DB->update_record('usercontract_export', (object) [
            'id' => $exportid,
            'status' => self::STATUS_COMPLETE,
            'timemodified' => time(),
            'statedata' => null,
            'errormsg' => null,
        ]);
        $export = $DB->get_record('usercontract_export', ['id' => $exportid], '*', MUST_EXIST);
        self::notify_ready($export, $instance, $cm, $course, $context);
    }

    protected static function encode_state(\stdClass $state): string {
        return json_encode($state);
    }

    protected static function decode_state(?string $raw): \stdClass {
        $state = json_decode($raw ?? '');
        if (!is_object($state)) {
            $state = (object) [];
        }
        if (empty($state->validids) || !is_array($state->validids)) {
            $state->validids = [];
        }
        $state->nextindex = isset($state->nextindex) ? (int) $state->nextindex : 0;
        return $state;
    }

    protected static function load_submissions_chunk(array $ids, \stdClass $instance, \context_module $context): array {
        global $DB;
        if (!$ids) {
            return [];
        }
        list($insql, $params) = $DB->get_in_or_equal($ids, SQL_PARAMS_NAMED);
        $params['ucid'] = $instance->id;
        $records = $DB->get_records_sql(
            "SELECT s.* FROM {usercontract_submission} s WHERE s.usercontract = :ucid AND s.id $insql",
            $params
        );
        return self::filter_valid_submissions($records, $instance, $context);
    }

    protected static function fail(int $exportid, string $message): void {
        global $DB;
        $DB->update_record('usercontract_export', (object) [
            'id' => $exportid,
            'status' => self::STATUS_FAILED,
            'timemodified' => time(),
            'errormsg' => $message,
            'statedata' => null,
        ]);
    }

    protected static function cleanup_old_exports(int $instanceid): void {
        global $DB;
        $limit = time() - (7 * DAYSECS);
        $old = $DB->get_records_select('usercontract_export', 'usercontract = ? AND timecreated < ?', [$instanceid, $limit]);
        if (!$old) {
            return;
        }
        $modid = (int) $DB->get_field('modules', 'id', ['name' => 'usercontract']);
        if (!$modid) {
            return;
        }
        $fs = get_file_storage();
        foreach ($old as $export) {
            $cm = $DB->get_record('course_modules', ['module' => $modid, 'instance' => $instanceid], 'id', IGNORE_MISSING);
            if ($cm) {
                $context = \context_module::instance($cm->id);
                $fs->delete_area_files($context->id, 'mod_usercontract', self::FILEAREA, $export->id);
            }
            $DB->delete_records('usercontract_export', ['id' => $export->id]);
        }
    }

    protected static function fetch_submissions(int $instanceid, int $groupid): array {
        global $DB;
        $gjs = usercontract_submissions_group_join_sql($groupid);
        $sql = "SELECT s.*
                  FROM {usercontract_submission} s
                       {$gjs['join']}
                 WHERE s.usercontract = :ucid
              ORDER BY s.timemodified ASC";
        return $DB->get_records_sql($sql, array_merge(['ucid' => $instanceid], $gjs['params']));
    }

    protected static function filter_valid_submissions(array $subs, \stdClass $instance, \context_module $context): array {
        $valid = [];
        foreach ($subs as $sub) {
            $user = \core_user::get_user((int) $sub->userid, '*', IGNORE_MISSING);
            if (!$user) {
                continue;
            }
            $learner = usercontract_learner_for_pdf($user, $sub);
            if (!usercontract_profile_is_complete($learner)) {
                continue;
            }
            $sub->_exportuser = $user;
            $sub->_exportlearner = $learner;
            $valid[] = $sub;
        }
        return $valid;
    }

    protected static function build_part_zip(
        \stdClass $instance,
        \stdClass $course,
        \context_module $context,
        array $chunk
    ): string {
        $dir = make_temp_directory('usercontract');
        $tmppath = $dir . '/bulk_' . sha1(uniqid((string) mt_rand(), true)) . '.zip';
        $zip = new \ZipArchive();
        if ($zip->open($tmppath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \moodle_exception('exportwritefailed', 'usercontract');
        }
        foreach ($chunk as $sub) {
            $pdfbytes = \mod_usercontract\contract_pdf::render_binary(
                $instance,
                $sub->_exportuser,
                $sub->_exportlearner,
                $context
            );
            $pdfname = 'dogovor_' . (int) $sub->userid . '_' . clean_filename(usercontract_user_firstname($sub->_exportuser)) . '.pdf';
            $zip->addFromString($pdfname, $pdfbytes);
            unset($pdfbytes);
            if (function_exists('gc_collect_cycles')) {
                gc_collect_cycles();
            }
        }
        if (!$zip->close()) {
            @unlink($tmppath);
            throw new \moodle_exception('exportwritefailed', 'usercontract');
        }
        return $tmppath;
    }

    protected static function notify_ready(
        \stdClass $export,
        \stdClass $instance,
        \stdClass $cm,
        \stdClass $course,
        \context_module $context
    ): void {
        global $DB;
        $user = $DB->get_record('user', ['id' => $export->requestedby], '*', MUST_EXIST);
        $viewurl = new \moodle_url('/mod/usercontract/view.php', ['id' => $cm->id, 'tab' => 'submissions']);
        $message = new \core\message\message();
        $message->component = 'mod_usercontract';
        $message->name = 'bulkexportready';
        $message->userfrom = \core_user::get_noreply_user();
        $message->userto = $user;
        $message->subject = get_string('bulkexportreadysubject', 'usercontract', format_string($instance->name));
        $message->fullmessage = get_string('bulkexportreadybody', 'usercontract', (object) [
            'name' => format_string($instance->name),
            'parts' => $export->partcount,
            'pdfs' => $export->pdfcount,
            'url' => $viewurl->out(false),
        ]);
        $message->fullmessageformat = FORMAT_PLAIN;
        $message->fullmessagehtml = get_string('bulkexportreadybodyhtml', 'usercontract', (object) [
            'name' => format_string($instance->name),
            'parts' => $export->partcount,
            'pdfs' => $export->pdfcount,
            'url' => $viewurl->out(false),
        ]);
        $message->smallmessage = get_string('bulkexportreadysmall', 'usercontract');
        $message->notification = 1;
        $message->contexturl = $viewurl;
        $message->contexturlname = format_string($instance->name);
        @message_send($message);
    }
}
