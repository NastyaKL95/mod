<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_usercontract\local;

defined('MOODLE_INTERNAL') || die();

/**
 * HTML-текст договора-оферты для PDF.
 */
class contract_body {

    /**
     * @param string $program
     * @param int $hours
     * @param \stdClass $learner firstname, phone_display, workplace
     * @param string $stamphtml HTML изображения печати
     * @param string $signaturehtml HTML изображения подписи
     * @param bool $includefooter включить таблицу реквизитов (для отдельной вёрстки PDF)
     * @return string
     */
    public static function build_html(
        string $program,
        int $hours,
        \stdClass $learner,
        string $representative,
        string $stamphtml = '',
        string $signaturehtml = '',
        bool $includefooter = true
    ): string {
        global $CFG;
        if (file_exists($CFG->dirroot . '/local/edudocuments/lib.php')) {
            require_once($CFG->dirroot . '/local/edudocuments/lib.php');
            $html = local_edudocuments_get_contract_template();
        } else {
            $path = __DIR__ . '/contract_static.html';
            if (!is_readable($path)) {
                throw new \moodle_exception('error_contract_template', 'usercontract');
            }
            $html = file_get_contents($path);
        }
        if (trim($html) === '') {
            throw new \moodle_exception('error_contract_template', 'usercontract');
        }
        $html = self::break_clause_lines($html);
        $hourparts = usercontract_program_hours_parts($hours);
        $replacements = [
            '{{program}}' => self::h($program),
            '{{hours_number}}' => self::h($hourparts['number']),
            '{{hours_propis}}' => self::h($hourparts['propis']),
            '{{hours_label}}' => self::h($hourparts['label']),
            '{{representative}}' => self::h($representative),
            '{{footer_columns}}' => $includefooter
                ? self::build_footer_columns($learner, $stamphtml, $signaturehtml)
                : '',
        ];
        return str_replace(array_keys($replacements), array_values($replacements), $html);
    }

    /**
     * Таблица реквизитов (отдельным блоком HTML для PDF).
     *
     * @param \stdClass $learner
     * @return string
     */
    public static function build_footer_html(\stdClass $learner): string {
        return self::build_footer_columns($learner, '', '');
    }

    /**
     * Каждый пункт договора (2.1., 5.1.2., 12.3. …) — с новой строки в PDF.
     *
     * @param string $html
     * @return string
     */
    protected static function break_clause_lines(string $html): string {
        $original = $html;
        $clause = '(?:[1-9]|1[0-2])\.\d{1,2}(?:\.\d{1,2})?\. ';

        $html = preg_replace('/\.\s+(?=' . $clause . ')/u', '.<br/>', $html);
        if ($html === null) {
            return $original;
        }
        $html = preg_replace('/:\s+(?=' . $clause . ')/u', ':<br/>', $html);
        if ($html === null) {
            return $original;
        }
        $html = preg_replace('/;\s+(?=' . $clause . ')/u', ';<br/>', $html);
        if ($html === null) {
            return $original;
        }
        $html = preg_replace('/>\s+(?=' . $clause . ')/u', '><br/>', $html);
        if ($html === null) {
            return $original;
        }
        $html = preg_replace(
            '/(?<=[a-zA-Zа-яА-ЯёЁ»\/])\s+(?=' . $clause . ')/u',
            '<br/>',
            $html
        );
        return ($html === null) ? $original : $html;
    }

    /**
     * Две колонки: реквизиты исполнителя (с печатью и подписью) и обучающийся.
     *
     * @param \stdClass $learner
     * @param string $stamphtml
     * @param string $signaturehtml
     * @return string
     */
    protected static function build_footer_columns(\stdClass $learner, string $stamphtml, string $signaturehtml): string {
        $firstname = self::h($learner->firstname ?? '');
        $phone = self::h($learner->phone_display ?? $learner->phone ?? '');
        $workplace = self::h($learner->workplace ?? '');

        $orgtext = self::table_text_block([
            'Государственное учреждение дополнительного профессионального образования «Институт развития образования Забайкальского края»',
            '672038, Забайкальский край, г. Чита ул. Красной Звезды, д.51А',
            'тел/факс (3022) 41-54-29',
            'ИНН 7536010571',
            'КПП 753601001',
            'ОГРН 1027501160686',
            'ОКТМО 76701000',
            'ОКПО 02093595',
            'Адрес электронной почты: inst@iro75.ru',
        ]);

        $student = self::table_text_block([
            '«Обучающийся»',
            get_string('field_firstname', 'usercontract'),
            $firstname,
            get_string('field_phone', 'usercontract'),
            $phone,
            get_string('field_workplace', 'usercontract'),
            $workplace,
        ], true);

        $border = 'border:0.2mm solid #000000;';
        $spacer = self::table_trailing_blank_lines();
        return '<p style="font-size:7pt;text-align:center;margin:0 0 5px 0;line-height:1.32;font-weight:bold;">'
            . '<b>13. Реквизиты Исполнителя</b></p>'
            . '<table width="100%" cellpadding="0" cellspacing="0" style="margin-top:0;' . $border . '">'
            . '<tr>'
            . '<td width="50%" valign="top" style="' . $border . '">' . self::table_cell_inner_pad($orgtext . $spacer) . '</td>'
            . '<td width="50%" valign="top" style="' . $border . '">' . self::table_cell_inner_pad($student . $spacer) . '</td>'
            . '</tr></table>';
    }

    /**
     * Пустые строки внизу ячейки под печать и подпись.
     *
     * @return string
     */
    protected static function table_trailing_blank_lines(): string {
        return '<br/><br/>';
    }

    /**
     * Отступы слева и сверху от границы ячейки (для теста в PDF).
     *
     * @param string $html
     * @return string
     */
    protected static function table_cell_inner_pad(string $html): string {
        $pad = usercontract_footer_table_test_pad();
        $topmm = (float) $pad['top'];
        $leftmm = (float) $pad['left'];
        return '<table cellpadding="0" cellspacing="0" width="100%">'
            . '<tr><td colspan="2" height="' . $topmm . '" style="font-size:1pt;line-height:1pt;">&nbsp;</td></tr>'
            . '<tr>'
            . '<td width="' . $leftmm . 'mm" style="font-size:1pt;line-height:1pt;">&nbsp;</td>'
            . '<td valign="top">' . $html . '</td>'
            . '</tr></table>';
    }

    /**
     * Текст ячейки таблицы: без отдельных &lt;p&gt; (TCPDF даёт лишние промежутки), строки через &lt;br/&gt;.
     *
     * @param string[] $lines
     * @param bool $learnerblock первая строка жирная, пары подпись/значение
     * @return string
     */
    protected static function table_text_block(array $lines, bool $learnerblock = false): string {
        $rows = [];
        if ($learnerblock) {
            $title = array_shift($lines);
            if ($title !== null && $title !== '') {
                $rows[] = '<b>' . self::h($title) . '</b>';
            }
            while (!empty($lines)) {
                $label = array_shift($lines);
                $value = array_shift($lines);
                if ($label === null) {
                    break;
                }
                $rows[] = self::h((string) $label);
                if ($value !== null && $value !== '') {
                    $rows[] = '<b>' . $value . '</b>';
                }
            }
        } else {
            foreach ($lines as $line) {
                if ($line !== '') {
                    $rows[] = self::h($line);
                }
            }
        }
        return '<span style="font-size:7pt;line-height:1.32;">' . implode('<br/>', $rows) . '</span>';
    }

    /**
     * @param string $s
     * @return string
     */
    protected static function h(string $s): string {
        return htmlspecialchars($s, ENT_QUOTES | ENT_HTML401, 'UTF-8');
    }
}
