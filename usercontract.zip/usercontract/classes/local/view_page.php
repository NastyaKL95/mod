<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_usercontract\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Общая инициализация страницы элемента «Договор-оферта».
 */
class view_page {

    /** @var \stdClass */
    public $cm;
    /** @var \stdClass */
    public $course;
    /** @var \context_module */
    public $context;
    /** @var \stdClass */
    public $instance;
    /** @var int */
    public $exportgroupid = 0;
    /** @var bool */
    public $canviewall;
    /** @var bool */
    public $cansubmit;

    /** @var \stdClass|false|null */
    protected $ownsubmission = null;

    /**
     * @param int $cmid
     */
    protected function __construct(int $cmid) {
        global $DB, $CFG, $PAGE, $USER;

        $this->cm = get_coursemodule_from_id('usercontract', $cmid, 0, false, MUST_EXIST);
        $this->course = get_course($this->cm->course);
        $this->context = \context_module::instance($this->cm->id);
        $this->instance = $DB->get_record('usercontract', ['id' => $this->cm->instance], '*', MUST_EXIST);

        require_login($this->course, true, $this->cm);
        require_capability('mod/usercontract:view', $this->context);

        $PAGE->set_context($this->context);
        $PAGE->set_cm($this->cm, $this->course, $this->instance);

        require_once($CFG->dirroot . '/group/lib.php');
        if (groups_get_activity_groupmode($this->cm, $this->course)) {
            $this->exportgroupid = (int) groups_get_activity_group($this->cm, true);
            $allowed = usercontract_get_activity_allowed_groups($this->cm, $USER->id);
            if ($this->exportgroupid && !isset($allowed[$this->exportgroupid])) {
                $this->exportgroupid = 0;
            }
        }

        $this->canviewall = has_capability('mod/usercontract:viewall', $this->context);
        $this->cansubmit = has_capability('mod/usercontract:submit', $this->context);
    }

    /**
     * @param int $cmid
     * @return self
     */
    public static function from_cm_id(int $cmid): self {
        return new self($cmid);
    }

    public function set_page_url_view(): void {
        global $PAGE;
        $pageparams = ['id' => $this->cm->id];
        if ($this->exportgroupid > 0) {
            $pageparams['group'] = $this->exportgroupid;
        }
        $PAGE->set_url('/mod/usercontract/view.php', $pageparams);
    }

    /**
     * @return \stdClass|false
     */
    public function get_own_submission() {
        global $DB, $USER;

        if ($this->ownsubmission !== null) {
            return $this->ownsubmission;
        }
        $this->ownsubmission = $DB->get_record('usercontract_submission', [
            'usercontract' => $this->instance->id,
            'userid' => $USER->id,
        ], '*', IGNORE_MISSING);
        return $this->ownsubmission;
    }

    /**
     * @return bool
     */
    public function is_listener_locked(): bool {
        return !$this->canviewall && usercontract_submission_is_locked($this->get_own_submission());
    }

    /**
     * @param string $requested
     * @return string
     */
    public function resolve_tab(string $requested): string {
        $requested = strtolower(trim($requested));
        if ($this->cansubmit && $this->canviewall) {
            if ($requested === 'form') {
                return 'form';
            }
            return 'submissions';
        }
        if ($this->canviewall) {
            return 'submissions';
        }
        return 'form';
    }

    /**
     * @param string $search
     * @param int $verifiedfilter -1 все, 0 непроверенные, 1 проверенные
     * @return array{from: string, params: array<string, mixed>}
     */
    protected function submissions_sql_parts(string $search, int $verifiedfilter = -1): array {
        global $DB;

        $gjs = usercontract_submissions_group_join_sql($this->exportgroupid);
        $params = array_merge(['ucid' => $this->instance->id], $gjs['params']);
        $whereextra = '';
        $search = trim($search);
        if ($search !== '') {
            $whereextra .= usercontract_submissions_search_where($search, $params, 'uc');
        }
        if ($verifiedfilter === 0 || $verifiedfilter === 1) {
            $params['ucverified'] = $verifiedfilter;
            $whereextra .= ' AND s.verified = :ucverified';
        }
        $from = " FROM {usercontract_submission} s
                  JOIN {user} u ON u.id = s.userid
                       {$gjs['join']}
                 WHERE s.usercontract = :ucid{$whereextra}";
        return ['from' => $from, 'params' => $params];
    }

    /**
     * @param string $search
     * @param int $verifiedfilter
     * @return int
     */
    public function count_submissions(string $search = '', int $verifiedfilter = -1): int {
        global $DB;
        $parts = $this->submissions_sql_parts($search, $verifiedfilter);
        return (int) $DB->count_records_sql('SELECT COUNT(1)' . $parts['from'], $parts['params']);
    }

    /**
     * @param string $search
     * @param int $pageindex
     * @param int $perpage
     * @param int $verifiedfilter
     * @return array
     */
    public function get_submissions_page(
        string $search,
        int $pageindex,
        int $perpage,
        int $verifiedfilter = -1,
        string $sort = 'timemodified',
        string $sortdir = 'desc'
    ): array {
        global $DB;
        $parts = $this->submissions_sql_parts($search, $verifiedfilter);
        $sql = 'SELECT s.*, u.firstname, u.lastname, u.email' . $parts['from']
            . usercontract_submissions_order_sql($sort, $sortdir);
        return $DB->get_records_sql($sql, $parts['params'], max(0, $pageindex) * $perpage, $perpage);
    }

    /**
     * @return bool
     */
    public function has_multiple_tabs(): bool {
        return $this->cansubmit && $this->canviewall;
    }

    /**
     * @param array $extra
     * @return \moodle_url
     */
    public function url_view(array $extra = []): \moodle_url {
        return new \moodle_url('/mod/usercontract/view.php', usercontract_view_page_params($this->cm->id, $this->exportgroupid, $extra));
    }

    /**
     * @return \moodle_url
     */
    public function url_submit(): \moodle_url {
        return new \moodle_url('/mod/usercontract/submit.php', usercontract_view_page_params($this->cm->id, $this->exportgroupid));
    }

    /**
     * @param int $userid
     * @return \moodle_url
     */
    public function url_download(int $userid = 0): \moodle_url {
        $p = [
            'id' => $this->cm->id,
            'sesskey' => sesskey(),
        ];
        if ($userid > 0) {
            $p['userid'] = $userid;
        }
        return new \moodle_url('/mod/usercontract/download.php', $p);
    }

    /**
     * @param int $targetuserid
     * @return \moodle_url
     */
    public function url_delete(int $targetuserid): \moodle_url {
        return new \moodle_url('/mod/usercontract/delete.php', usercontract_view_page_params($this->cm->id, $this->exportgroupid, [
            'deleteuser' => $targetuserid,
        ]));
    }
}
