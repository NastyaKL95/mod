<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_usercontract\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\transform;
use core_privacy\local\request\writer;

defined('MOODLE_INTERNAL') || die();

/**
 * Провайдер приватности для принятых договоров.
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider {

    /**
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection) {
        $collection->add_database_table(
            'usercontract_submission',
            [
                'userid' => 'privacy:metadata:usercontract_submission:userid',
                'data' => 'privacy:metadata:usercontract_submission:data',
                'timecreated' => 'privacy:metadata:usercontract_submission:timecreated',
                'timemodified' => 'privacy:metadata:usercontract_submission:timemodified',
                'verified' => 'privacy:metadata:usercontract_submission:verified',
                'verifiedby' => 'privacy:metadata:usercontract_submission:verifiedby',
                'verifiedtime' => 'privacy:metadata:usercontract_submission:verifiedtime',
            ],
            'privacy:metadata:usercontract_submission'
        );
        return $collection;
    }

    /**
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        $sql = "SELECT ctx.id
                  FROM {context} ctx
                  JOIN {course_modules} cm ON cm.id = ctx.instanceid AND ctx.contextlevel = :contextlevel
                  JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                  JOIN {usercontract} uc ON uc.id = cm.instance
                  JOIN {usercontract_submission} sub ON sub.usercontract = uc.id AND sub.userid = :userid";
        $params = [
            'contextlevel' => CONTEXT_MODULE,
            'modname' => 'usercontract',
            'userid' => $userid,
        ];
        $contextlist->add_from_sql($sql, $params);

        return $contextlist;
    }

    /**
     * @param approved_contextlist $contextlist
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;

        if (empty($contextlist->get_contextids())) {
            return;
        }

        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel != CONTEXT_MODULE) {
                continue;
            }
            $cm = get_coursemodule_from_id('usercontract', $context->instanceid, 0, false);
            if (!$cm || $cm->modname !== 'usercontract') {
                continue;
            }
            $sub = $DB->get_record('usercontract_submission', [
                'usercontract' => $cm->instance,
                'userid' => $userid,
            ]);
            if (!$sub) {
                continue;
            }
            $payload = json_decode($sub->data);
            writer::with_context($context)->export_data(
                [],
                (object) [
                    'timemodified' => transform::datetime($sub->timemodified),
                    'formdata' => $payload,
                ]
            );
        }
    }

    /**
     * @param \context $context
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;

        if ($context->contextlevel != CONTEXT_MODULE) {
            return;
        }
        $cm = get_coursemodule_from_id('usercontract', $context->instanceid, 0, false);
        if (!$cm || $cm->modname !== 'usercontract') {
            return;
        }
        usercontract_purge_instance_data((int) $cm->instance);
    }

    /**
     * @param approved_contextlist $contextlist
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;

        if (empty($contextlist->get_contextids())) {
            return;
        }
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel != CONTEXT_MODULE) {
                continue;
            }
            $cm = get_coursemodule_from_id('usercontract', $context->instanceid, 0, false);
            if (!$cm || $cm->modname !== 'usercontract') {
                continue;
            }
            $DB->delete_records('usercontract_submission', [
                'usercontract' => $cm->instance,
                'userid' => $userid,
            ]);
        }
    }
}
