<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_usercontract\task;

defined('MOODLE_INTERNAL') || die();

class bulk_export extends \core\task\adhoc_task {

    public function get_component() {
        return 'mod_usercontract';
    }

    public function get_name() {
        return get_string('bulkexporttaskname', 'usercontract');
    }

    public function execute() {
        $data = $this->get_custom_data();
        if (empty($data->exportid)) {
            return;
        }
        \mod_usercontract\local\bulk_export_service::run((int) $data->exportid);
    }
}
