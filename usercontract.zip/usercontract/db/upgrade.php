<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_usercontract_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2024051503) {
        $table = new xmldb_table('usercontract');
        $field = new xmldb_field('representative', XMLDB_TYPE_TEXT, null, null, null, null, null, 'programhours');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        upgrade_mod_savepoint(true, 2024051503, 'usercontract');
    }

    if ($oldversion < 2024051531) {
        upgrade_mod_savepoint(true, 2024051531, 'usercontract');
    }

    if ($oldversion < 2024051532) {
        upgrade_mod_savepoint(true, 2024051532, 'usercontract');
    }

    if ($oldversion < 2024051533) {
        $table = new xmldb_table('usercontract_export');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('usercontract', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('requestedby', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('groupid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending');
            $table->add_field('partcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('pdfcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('errormsg', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('usercontract', XMLDB_KEY_FOREIGN, ['usercontract'], 'usercontract', ['id']);
            $table->add_key('requestedby', XMLDB_KEY_FOREIGN, ['requestedby'], 'user', ['id']);
            $table->add_index('contract_status', XMLDB_INDEX_NOTUNIQUE, ['usercontract', 'status']);
            $dbman->create_table($table);
        }
        upgrade_mod_savepoint(true, 2024051533, 'usercontract');
    }

    if ($oldversion < 2024051534) {
        upgrade_mod_savepoint(true, 2024051534, 'usercontract');
    }

    if ($oldversion < 2024051535) {
        $table = new xmldb_table('usercontract_export');
        $field = new xmldb_field('statedata', XMLDB_TYPE_TEXT, null, null, null, null, null, 'errormsg');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        upgrade_mod_savepoint(true, 2024051535, 'usercontract');
    }

    if ($oldversion < 2024051536) {
        upgrade_mod_savepoint(true, 2024051536, 'usercontract');
    }

    if ($oldversion < 2024051537) {
        upgrade_mod_savepoint(true, 2024051537, 'usercontract');
    }

    if ($oldversion < 2024051538) {
        upgrade_mod_savepoint(true, 2024051538, 'usercontract');
    }

    if ($oldversion < 2024051539) {
        require_once(__DIR__ . '/../lib.php');
        $modid = (int) $DB->get_field('modules', 'id', ['name' => 'usercontract']);
        if ($modid) {
            $cms = $DB->get_records('course_modules', ['module' => $modid]);
            foreach ($cms as $cm) {
                $context = \context_module::instance($cm->id);
                usercontract_install_default_images_if_empty($context);
            }
        }
        upgrade_mod_savepoint(true, 2024051539, 'usercontract');
    }

    if ($oldversion < 2024051540) {
        upgrade_mod_savepoint(true, 2024051540, 'usercontract');
    }

    if ($oldversion < 2024051544) {
        upgrade_mod_savepoint(true, 2024051544, 'usercontract');
    }

    if ($oldversion < 2024051545) {
        upgrade_mod_savepoint(true, 2024051545, 'usercontract');
    }

    return true;
}
