<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_usercontract\local\view_page;

$id = required_param('id', PARAM_INT);
$deleteuser = optional_param('deleteuser', 0, PARAM_INT);
$deleteconfirmed = optional_param('confirm', 0, PARAM_INT);

$page = view_page::from_cm_id($id);

global $PAGE, $DB, $OUTPUT;

require_capability('mod/usercontract:viewall', $page->context);

$baseparams = usercontract_view_page_params($page->cm->id, $page->exportgroupid, ['tab' => 'submissions']);
$urlparams = $baseparams;
if ($deleteuser > 0) {
    $urlparams['deleteuser'] = $deleteuser;
}
if ($deleteconfirmed) {
    $urlparams['confirm'] = 1;
}
$PAGE->set_url('/mod/usercontract/delete.php', $urlparams);

if ($deleteuser <= 0) {
    redirect(new moodle_url('/mod/usercontract/view.php', $baseparams));
}

if (!$DB->record_exists('usercontract_submission', [
    'usercontract' => $page->instance->id,
    'userid' => $deleteuser,
])) {
    redirect(
        new moodle_url('/mod/usercontract/view.php', $baseparams),
        get_string('nosubmissiontodelete', 'usercontract'),
        null,
        \core\output\notification::NOTIFY_WARNING
    );
}

if (!$deleteconfirmed) {
    $usertodel = core_user::get_user($deleteuser, '*', IGNORE_MISSING);
    if (!$usertodel || $usertodel->deleted) {
        throw new moodle_exception('invaliduser');
    }
    $PAGE->set_title(format_string($page->instance->name));
    $PAGE->set_heading($page->course->fullname);
    $PAGE->set_pagelayout('incourse');
    echo $OUTPUT->header();
    echo $OUTPUT->confirm(
        get_string('deleteconfirm', 'usercontract', usercontract_user_firstname($usertodel)),
        new moodle_url('/mod/usercontract/delete.php', usercontract_view_page_params($page->cm->id, $page->exportgroupid, [
            'deleteuser' => $deleteuser,
            'confirm' => 1,
            'sesskey' => sesskey(),
        ])),
        new moodle_url('/mod/usercontract/view.php', $baseparams)
    );
    echo $OUTPUT->footer();
    exit;
}

require_sesskey();
$DB->delete_records('usercontract_submission', [
    'usercontract' => $page->instance->id,
    'userid' => $deleteuser,
]);
usercontract_sync_completion_for_user($page->cm, $page->course, $deleteuser, false);
redirect(
    new moodle_url('/mod/usercontract/view.php', $baseparams),
    get_string('submissiondeleted', 'usercontract'),
    null,
    \core\output\notification::NOTIFY_SUCCESS
);
