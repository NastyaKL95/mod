<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_usercontract\local\bulk_export_service;

$exportid = required_param('exportid', PARAM_INT);

global $DB, $USER, $PAGE, $OUTPUT;

$export = $DB->get_record('usercontract_export', ['id' => $exportid], '*', MUST_EXIST);
$instance = $DB->get_record('usercontract', ['id' => $export->usercontract], '*', MUST_EXIST);
$cm = get_coursemodule_from_instance('usercontract', $instance->id, 0, false, MUST_EXIST);
$course = get_course($cm->course);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/usercontract:viewall', $context);

if ((int) $export->requestedby !== (int) $USER->id && !has_capability('moodle/site:config', context_system::instance())) {
    throw new moodle_exception('nopermissions', 'error');
}

$returnurl = new moodle_url('/mod/usercontract/view.php', usercontract_view_page_params(
    $cm->id,
    (int) $export->groupid,
    ['tab' => 'submissions']
));

$progress = bulk_export_service::process_next_step($exportid);

if ($progress->complete) {
    redirect(
        $returnurl,
        get_string('bulkexportdone', 'usercontract', (object) [
            'parts' => $progress->parts,
            'count' => $progress->processed,
        ]),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($progress->failed) {
    redirect(
        $returnurl,
        $progress->message ?: get_string('bulkexportstatus_failed', 'usercontract'),
        null,
        \core\output\notification::NOTIFY_ERROR
    );
}

$PAGE->set_url(new moodle_url('/mod/usercontract/export_bulk_run.php', ['exportid' => $exportid]));
$PAGE->set_context($context);
$PAGE->set_cm($cm, $course, $instance);
$PAGE->set_title(get_string('bulkexportrunningtitle', 'usercontract'));
$PAGE->set_heading($course->fullname);
$PAGE->set_pagelayout('incourse');

$continueurl = $PAGE->url->out(false);
$percent = (int) $progress->percent;

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('bulkexportrunningtitle', 'usercontract'), 3);
echo html_writer::tag('p', get_string('bulkexportrunning_help', 'usercontract'), ['class' => 'text-muted']);
echo html_writer::start_div('usercontract-bulk-progress mb-3', ['style' => 'max-width:32rem;']);
echo html_writer::start_div('progress', ['style' => 'height:1.5rem;']);
echo html_writer::div('', 'progress-bar progress-bar-striped progress-bar-animated', [
    'role' => 'progressbar',
    'style' => 'width:' . $percent . '%;',
    'aria-valuenow' => $percent,
    'aria-valuemin' => '0',
    'aria-valuemax' => '100',
]);
echo html_writer::end_div();
echo html_writer::tag('p',
    get_string('bulkexportprogress', 'usercontract', (object) [
        'processed' => $progress->processed,
        'total' => $progress->total,
        'parts' => $progress->parts,
        'percent' => $percent,
    ]),
    ['class' => 'mt-2 mb-0']
);
echo html_writer::end_div();
echo html_writer::tag('p', get_string('bulkexportkeepopen', 'usercontract'), ['class' => 'alert alert-info']);
echo html_writer::script(
    "(function(){setTimeout(function(){window.location.href=" . json_encode($continueurl) . ";},800);})();"
);
echo $OUTPUT->continue_button($returnurl);
echo $OUTPUT->footer();
