<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

require_sesskey();

$cm = get_coursemodule_from_id('usercontract', $id, 0, false, MUST_EXIST);
$course = get_course($cm->course);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);

require_capability('mod/usercontract:viewall', $context);

$instance = $DB->get_record('usercontract', ['id' => $cm->instance], '*', MUST_EXIST);

if (!class_exists('ZipArchive')) {
    throw new moodle_exception('noziparchive', 'usercontract');
}

require_once($CFG->dirroot . '/group/lib.php');
$exportgroupid = usercontract_normalize_export_groupid($cm, $course, $USER->id);

usercontract_raise_export_limits();

$gjs = usercontract_submissions_group_join_sql($exportgroupid);
$sql = "SELECT s.*
          FROM {usercontract_submission} s
               {$gjs['join']}
         WHERE s.usercontract = :ucid
      ORDER BY s.timemodified ASC";
$params = array_merge(['ucid' => $instance->id], $gjs['params']);

$subs = $DB->get_records_sql($sql, $params);

$subcount = count($subs);
$maxzip = usercontract_zip_pdf_limit();
if ($subcount > $maxzip) {
    throw new moodle_exception('exportziptoomany', 'usercontract', (object) [
        'max' => $maxzip,
        'count' => $subcount,
    ]);
}

$dir = make_temp_directory('usercontract');
$tmpzip = $dir . '/export_' . sha1(uniqid((string) mt_rand(), true)) . '.zip';

$zip = new ZipArchive();
$zipopened = false;
try {
    if ($zip->open($tmpzip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new moodle_exception('exportwritefailed', 'usercontract');
    }
    $zipopened = true;

    foreach ($subs as $sub) {
        $user = core_user::get_user((int) $sub->userid, '*', IGNORE_MISSING);
        if (!$user) {
            continue;
        }
        $learner = usercontract_learner_for_pdf($user, $sub);
        if (!usercontract_profile_is_complete($learner)) {
            continue;
        }
        $pdfbytes = \mod_usercontract\contract_pdf::render_binary($instance, $user, $learner, $context);
        $pdfname = 'dogovor_' . (int) $user->id . '_' . clean_filename(usercontract_user_firstname($user)) . '.pdf';
        $zip->addFromString($pdfname, $pdfbytes);
        unset($pdfbytes, $user, $learner);
        if (function_exists('gc_collect_cycles')) {
            gc_collect_cycles();
        }
    }

    if (!$zip->close()) {
        throw new moodle_exception('exportwritefailed', 'usercontract');
    }
    $zipopened = false;

    while (ob_get_level()) {
        ob_end_clean();
    }

    $zipfname = 'dogovory_' . clean_filename(format_string($course->shortname, true)) . '_'
        . userdate(time(), '%Y%m%d%H%M', 99, false) . '.zip';

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipfname . '"');
    header('Content-Length: ' . filesize($tmpzip));
    header('Cache-Control: private, must-revalidate, pre-check=0, post-check=0, max-age=0');
    readfile($tmpzip);
} finally {
    if ($zipopened) {
        @$zip->close();
    }
    if (file_exists($tmpzip)) {
        @unlink($tmpzip);
    }
}
exit;
