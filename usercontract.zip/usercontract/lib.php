<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @param string $feature
 * @return mixed
 */
function usercontract_supports($feature) {
    switch ($feature) {
        case FEATURE_MOD_INTRO:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return false;
        case FEATURE_COMPLETION_HAS_RULES:
            return true;
        case FEATURE_GRADE_HAS_GRADE:
            return false;
        case FEATURE_BACKUP_MOODLE2:
            return false;
        case FEATURE_GROUPS:
            return true;
        case FEATURE_GROUPINGS:
            return true;
        default:
            return null;
    }
}

/**
 * @param stdClass $data
 * @return int
 */
function usercontract_add_instance($data, $mform = null) {
    global $DB;

    $data->timemodified = time();
    $data->programhours = max(0, (int) ($data->programhours ?? 0));
    $data->representative = trim($data->representative ?? '');
    if (!isset($data->completionverified)) {
        $data->completionverified = 1;
    }
    $data->id = $DB->insert_record('usercontract', $data);
    usercontract_save_instance_files($data);

    return $data->id;
}

/**
 * @param stdClass $data
 * @return bool
 */
function usercontract_update_instance($data, $mform = null) {
    global $DB;

    $data->id = $data->instance;
    $data->timemodified = time();
    $data->programhours = max(0, (int) ($data->programhours ?? 0));
    $data->representative = trim($data->representative ?? '');
    $DB->update_record('usercontract', $data);
    usercontract_save_instance_files($data);

    return true;
}

/**
 * Удалить все данные одного элемента «Договор» (submissions, фоновые экспорты).
 *
 * @param int $instanceid
 */
function usercontract_purge_instance_data(int $instanceid): void {
    global $DB;

    $DB->delete_records('usercontract_submission', ['usercontract' => $instanceid]);
    $DB->delete_records('usercontract_export', ['usercontract' => $instanceid]);
}

/**
 * Удалить все сохранённые договоры в курсе.
 *
 * @param int $courseid
 */
function usercontract_delete_all_submissions_in_course(int $courseid): void {
    global $DB;

    $instanceids = $DB->get_fieldset_select('usercontract', 'id', 'course = ?', [$courseid]);
    if (!$instanceids) {
        return;
    }
    [$insql, $params] = $DB->get_in_or_equal($instanceids);
    $DB->delete_records_select('usercontract_submission', 'usercontract ' . $insql, $params);
}

/**
 * Удалить сохранённые договоры и заявления участника в курсе.
 *
 * @param int $courseid
 * @param int $userid
 * @param bool $includepartner false — только договоры (внутренний вызов).
 */
function usercontract_delete_user_submissions_in_course(int $courseid, int $userid, bool $includepartner = true): void {
    global $DB;

    static $cascade = 0;
    $instanceids = $DB->get_fieldset_select('usercontract', 'id', 'course = ?', [$courseid]);
    if ($instanceids) {
        [$insql, $inparams] = $DB->get_in_or_equal($instanceids);
        $params = array_merge($inparams, [$userid]);
        $DB->delete_records_select('usercontract_submission', 'usercontract ' . $insql . ' AND userid = ?', $params);
    }
    usercontract_sync_completion_all_in_course($courseid, $userid, false);

    if ($includepartner && $cascade === 0) {
        $cascade++;
        if (function_exists('userstatement_delete_user_submissions_in_course')) {
            userstatement_delete_user_submissions_in_course($courseid, $userid, false);
        }
        $cascade--;
    }
}

/**
 * Сбросить завершение по всем элементам «Договор» в курсе для пользователя.
 *
 * @param int $courseid
 * @param int $userid
 * @param bool $verified
 */
function usercontract_sync_completion_all_in_course(int $courseid, int $userid, bool $verified): void {
    global $CFG;

    require_once($CFG->libdir . '/modinfolib.php');
    $course = get_course($courseid);
    $modinfo = get_fast_modinfo($course, $userid);
    foreach ($modinfo->get_instances_of('usercontract') as $cm) {
        usercontract_sync_completion_for_user($cm, $course, $userid, $verified);
    }
}

/**
 * Удалить все сохранённые договоры и заявления в курсе (только для явного сброса курса).
 *
 * @param int $courseid
 * @deprecated Используйте usercontract_purge_instance_data() для одного элемента.
 */
function usercontract_purge_course_saved_data(int $courseid): void {
    static $running = false;
    if ($running) {
        return;
    }
    $running = true;
    usercontract_delete_all_submissions_in_course($courseid);
    if (function_exists('userstatement_delete_all_submissions_in_course')) {
        userstatement_delete_all_submissions_in_course($courseid);
    }
    $running = false;
}

/**
 * SQL-фрагмент поиска участника в списке договоров (имя, e-mail, JSON: телефон, место работы).
 *
 * @param string $search
 * @param array<string, mixed> $params дополняется параметрами LIKE
 * @param string $prefix префикс имён параметров
 * @return string
 */
function usercontract_submissions_search_where(string $search, array &$params, string $prefix = 'uc'): string {
    global $DB;

    $search = trim($search);
    if ($search === '') {
        return '';
    }
    $like = '%' . $DB->sql_like_escape($search) . '%';
    $params[$prefix . 'searchfn'] = $like;
    $params[$prefix . 'searchem'] = $like;
    $params[$prefix . 'searchdata'] = $like;
    $phone = usercontract_normalize_phone_digits($search);
    $wheres = [
        $DB->sql_like('u.firstname', ':' . $prefix . 'searchfn', false),
        $DB->sql_like('u.email', ':' . $prefix . 'searchem', false),
        $DB->sql_like('s.data', ':' . $prefix . 'searchdata', false),
    ];
    if ($phone !== '') {
        $params[$prefix . 'searchphone'] = '%' . $DB->sql_like_escape($phone) . '%';
        $wheres[] = $DB->sql_like('s.data', ':' . $prefix . 'searchphone', false);
    }
    return ' AND (' . implode(' OR ', $wheres) . ')';
}

/**
 * @param int $id
 * @return bool
 */
function usercontract_delete_instance($id) {
    global $DB;

    $instance = $DB->get_record('usercontract', ['id' => $id], 'id,course', MUST_EXIST);

    $cm = get_coursemodule_from_instance('usercontract', $id, 0, false, IGNORE_MISSING);
    if ($cm) {
        $context = context_module::instance($cm->id);
        $fs = get_file_storage();
        $fs->delete_area_files($context->id, 'mod_usercontract');
    }

    usercontract_purge_instance_data($id);
    $DB->delete_records('usercontract', ['id' => $id]);

    return true;
}

/**
 * Склонение «час» для числительного.
 *
 * @param int $n
 * @return string
 */
function usercontract_hours_label_ru(int $n): string {
    $mod100 = abs($n) % 100;
    $mod10 = abs($n) % 10;
    if ($mod100 >= 11 && $mod100 <= 14) {
        return 'часов';
    }
    if ($mod10 === 1) {
        return 'час';
    }
    if ($mod10 >= 2 && $mod10 <= 4) {
        return 'часа';
    }
    return 'часов';
}

/**
 * @param int $n 0–999
 * @param bool $feminine род для единиц (тысячи)
 * @return string
 */
function usercontract_triad_to_words_ru(int $n, bool $feminine = false): string {
    $n = $n % 1000;
    if ($n === 0) {
        return '';
    }
    $ones = $feminine
        ? ['', 'одна', 'две', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять']
        : ['', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять'];
    $teens = [
        'десять', 'одиннадцать', 'двенадцать', 'тринадцать', 'четырнадцать', 'пятнадцать',
        'шестнадцать', 'семнадцать', 'восемнадцать', 'девятнадцать',
    ];
    $tens = [
        '', '', 'двадцать', 'тридцать', 'сорок', 'пятьдесят',
        'шестьдесят', 'семьдесят', 'восемьдесят', 'девяносто',
    ];
    $hundreds = [
        '', 'сто', 'двести', 'триста', 'четыреста', 'пятьсот',
        'шестьсот', 'семьсот', 'восемьсот', 'девятьсот',
    ];
    $parts = [];
    $h = intdiv($n, 100);
    $rest = $n % 100;
    if ($h > 0) {
        $parts[] = $hundreds[$h];
    }
    if ($rest >= 10 && $rest <= 19) {
        $parts[] = $teens[$rest - 10];
    } else {
        $t = intdiv($rest, 10);
        $o = $rest % 10;
        if ($t > 0) {
            $parts[] = $tens[$t];
        }
        if ($o > 0) {
            $parts[] = $ones[$o];
        }
    }
    return implode(' ', $parts);
}

/**
 * Число прописью по-русски (0–999999), мужской род.
 *
 * @param int $number
 * @return string
 */
function usercontract_number_to_words_ru(int $number): string {
    $number = max(0, (int) $number);
    if ($number === 0) {
        return 'ноль';
    }
    $parts = [];
    $thousands = intdiv($number, 1000);
    $rest = $number % 1000;
    if ($thousands > 0) {
        $twords = usercontract_triad_to_words_ru($thousands, true);
        if ($twords !== '') {
            $parts[] = $twords;
        }
        $tmod100 = $thousands % 100;
        $tmod10 = $thousands % 10;
        if ($tmod100 >= 11 && $tmod100 <= 14) {
            $parts[] = 'тысяч';
        } else if ($tmod10 === 1) {
            $parts[] = 'тысяча';
        } else if ($tmod10 >= 2 && $tmod10 <= 4) {
            $parts[] = 'тысячи';
        } else {
            $parts[] = 'тысяч';
        }
    }
    $rwords = usercontract_triad_to_words_ru($rest, false);
    if ($rwords !== '') {
        $parts[] = $rwords;
    }
    return trim(implode(' ', $parts));
}

/**
 * Цифры, пропись и «час» для пункта 3.1 договора.
 *
 * @param int $hours
 * @return array{number: string, propis: string, label: string}
 */
function usercontract_program_hours_parts(int $hours): array {
    $n = max(0, (int) $hours);
    return [
        'number' => (string) $n,
        'propis' => usercontract_number_to_words_ru($n),
        'label' => usercontract_hours_label_ru($n),
    ];
}

/**
 * Параметры filemanager для изображений печати и подписи.
 *
 * @return array
 */
function usercontract_image_filemanager_options(): array {
    return [
        'subdirs' => 0,
        'maxfiles' => 1,
        'accepted_types' => ['image'],
    ];
}

/**
 * Путь к файлу печати/подписи по умолчанию в pix/ плагина.
 *
 * @param string $filearea stamp|signature
 * @return string|false
 */
function usercontract_default_pix_path(string $filearea) {
    global $CFG;
    $map = [
        'stamp' => 'default_stamp.png',
        'signature' => 'default_signature.png',
    ];
    if (!isset($map[$filearea])) {
        return false;
    }
    $path = $CFG->dirroot . '/mod/usercontract/pix/' . $map[$filearea];
    return is_readable($path) ? $path : false;
}

/**
 * Есть ли уже файл в области модуля.
 *
 * @param int $contextid
 * @param string $filearea stamp|signature
 * @return bool
 */
function usercontract_area_has_image(int $contextid, string $filearea): bool {
    $fs = get_file_storage();
    $files = $fs->get_area_files($contextid, 'mod_usercontract', $filearea, 0, 'itemid', false);
    return !empty($files);
}

/**
 * Скопировать печать/подпись по умолчанию в filearea модуля, если пусто.
 *
 * @param \context $context
 */
function usercontract_install_default_images_if_empty(\context $context): void {
    $fs = get_file_storage();
    foreach (['stamp' => 'stamp.png', 'signature' => 'signature.png'] as $area => $filename) {
        if (usercontract_area_has_image($context->id, $area)) {
            continue;
        }
        $path = usercontract_default_pix_path($area);
        if ($path === false) {
            continue;
        }
        $filerecord = [
            'contextid' => $context->id,
            'component' => 'mod_usercontract',
            'filearea' => $area,
            'itemid' => 0,
            'filepath' => '/',
            'filename' => $filename,
        ];
        $fs->create_file_from_pathname($filerecord, $path);
    }
}

/**
 * Подставить печать/подпись по умолчанию в черновик filemanager (новый элемент курса).
 *
 * @param string $filearea stamp|signature
 * @return int draft itemid
 */
function usercontract_prepare_default_draft(string $filearea): int {
    global $USER;

    $draftitemid = file_get_unused_draft_itemid();
    $path = usercontract_default_pix_path($filearea);
    if ($path === false) {
        return $draftitemid;
    }
    $filename = $filearea === 'stamp' ? 'stamp.png' : 'signature.png';
    $usercontext = \context_user::instance($USER->id);
    $filerecord = [
        'contextid' => $usercontext->id,
        'component' => 'user',
        'filearea' => 'draft',
        'itemid' => $draftitemid,
        'filepath' => '/',
        'filename' => $filename,
    ];
    get_file_storage()->create_file_from_pathname($filerecord, $path);
    return $draftitemid;
}

/**
 * Сохранение изображений из формы настроек элемента.
 *
 * @param \stdClass $data
 */
function usercontract_save_instance_files($data) {
    if (empty($data->coursemodule)) {
        return;
    }
    $context = context_module::instance($data->coursemodule);
    $options = usercontract_image_filemanager_options();
    $data = (object) $data;
    file_postupdate_standard_filemanager($data, 'stampimage', $options, $context, 'mod_usercontract', 'stamp', 0);
    file_postupdate_standard_filemanager($data, 'signatureimage', $options, $context, 'mod_usercontract', 'signature', 0);
    usercontract_install_default_images_if_empty($context);
}

/**
 * Подобрать ширину и высоту картинки в мм с сохранением пропорций.
 *
 * @param int $pixelw
 * @param int $pixelh
 * @param int $maxwidthmm
 * @param int $maxheightmm 0 — ограничение только по ширине
 * @return array{width: float, height: float}
 */
function usercontract_scale_image_mm(int $pixelw, int $pixelh, int $maxwidthmm, int $maxheightmm = 0): array {
    $maxwidthmm = max(1, $maxwidthmm);
    if ($pixelw < 1 || $pixelh < 1) {
        return ['width' => (float) $maxwidthmm, 'height' => (float) $maxwidthmm];
    }
    $wmm = (float) $maxwidthmm;
    $hmm = $wmm * $pixelh / $pixelw;
    if ($maxheightmm > 0 && $hmm > $maxheightmm) {
        $hmm = (float) max(1, $maxheightmm);
        $wmm = $hmm * $pixelw / $pixelh;
    }
    return ['width' => round($wmm, 1), 'height' => round($hmm, 1)];
}

/**
 * DPI вставки печати/подписи в PDF (меньше 300 — меньше размер файла).
 *
 * @return int
 */
function usercontract_pdf_image_dpi(): int {
    return 150;
}

/**
 * @param float $mm
 * @param int $dpi
 * @return int
 */
function usercontract_mm_to_pixels(float $mm, int $dpi): int {
    return max(1, (int) ceil(($mm / 25.4) * $dpi));
}

/**
 * Есть ли у GD-изображения прозрачность (для выбора PNG vs JPEG).
 *
 * @param \GdImage|resource $img
 * @return bool
 */
function usercontract_gd_image_has_alpha($img): bool {
    if (!imageistruecolor($img)) {
        return imagecolortransparent($img) >= 0;
    }
    $w = imagesx($img);
    $h = imagesy($img);
    if ($w < 1 || $h < 1) {
        return false;
    }
    $stepx = max(1, (int) floor($w / 24));
    $stepy = max(1, (int) floor($h / 24));
    for ($y = 0; $y < $h; $y += $stepy) {
        for ($x = 0; $x < $w; $x += $stepx) {
            $alpha = (imagecolorat($img, $x, $y) >> 24) & 0x7F;
            if ($alpha > 0) {
                return true;
            }
        }
    }
    return false;
}

/**
 * Уменьшить растровое изображение под размер на странице (~150 DPI).
 *
 * @param string $content Исходные байты файла.
 * @param float $widthmm Ширина на странице, мм.
 * @param float $heightmm Высота на странице, мм.
 * @param int $dpi 0 — usercontract_pdf_image_dpi().
 * @return string
 */
function usercontract_optimize_image_binary(
    string $content,
    float $widthmm,
    float $heightmm,
    int $dpi = 0
): string {
    if ($content === '' || !function_exists('imagecreatefromstring')) {
        return $content;
    }
    if ($dpi <= 0) {
        $dpi = usercontract_pdf_image_dpi();
    }
    $info = @getimagesizefromstring($content);
    if ($info === false) {
        return $content;
    }

    $src = @imagecreatefromstring($content);
    if ($src === false) {
        return $content;
    }

    $srcw = imagesx($src);
    $srch = imagesy($src);
    if ($srcw < 1 || $srch < 1) {
        imagedestroy($src);
        return $content;
    }

    $maxw = usercontract_mm_to_pixels($widthmm, $dpi);
    $maxh = usercontract_mm_to_pixels($heightmm, $dpi);
    $scale = min($maxw / $srcw, $maxh / $srch, 1.0);
    $dstw = max(1, (int) round($srcw * $scale));
    $dsth = max(1, (int) round($srch * $scale));

    $imagetype = (int) ($info[2] ?? 0);
    $usepng = ($imagetype === IMAGETYPE_PNG || $imagetype === IMAGETYPE_GIF)
        && usercontract_gd_image_has_alpha($src);

    if ($scale >= 0.999 && !$usepng) {
        imagedestroy($src);
        return $content;
    }

    $dst = imagecreatetruecolor($dstw, $dsth);
    if ($usepng) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefilledrectangle($dst, 0, 0, $dstw - 1, $dsth - 1, $transparent);
        imagealphablending($dst, true);
    } else {
        $white = imagecolorallocate($dst, 255, 255, 255);
        imagefilledrectangle($dst, 0, 0, $dstw - 1, $dsth - 1, $white);
    }

    imagecopyresampled($dst, $src, 0, 0, 0, 0, $dstw, $dsth, $srcw, $srch);
    imagedestroy($src);

    ob_start();
    if ($usepng) {
        imagepng($dst, null, 6);
    } else {
        imagejpeg($dst, null, 82);
    }
    $optimized = ob_get_clean();
    imagedestroy($dst);

    if ($optimized === false || $optimized === '') {
        return $content;
    }
    return $optimized;
}

/**
 * HTML img для вставки в PDF (base64).
 *
 * TCPDF не учитывает CSS max-width — нужны атрибуты width/height в мм.
 *
 * @param \context_module $context
 * @param string $filearea stamp|signature
 * @param int $maxwidthmm
 * @param int $maxheightmm 0 — только по ширине
 * @param bool $forcesize true — ровно maxwidth×maxheight мм (для печати 35×35)
 * @return string
 */
function usercontract_pdf_image_html(
    \context_module $context,
    string $filearea,
    int $maxwidthmm = 20,
    int $maxheightmm = 0,
    bool $forcesize = false
): string {
    if (!in_array($filearea, ['stamp', 'signature'], true)) {
        return '';
    }
    $fs = get_file_storage();
    $files = $fs->get_area_files($context->id, 'mod_usercontract', $filearea, 0, 'itemid, filepath, filename', false);
    if (empty($files)) {
        return '';
    }
    $file = reset($files);
    $mime = $file->get_mimetype();
    if (strpos($mime, 'image/') !== 0) {
        return '';
    }
    $content = $file->get_content();
    $info = @getimagesizefromstring($content);
    $pixelw = (int) ($info[0] ?? 0);
    $pixelh = (int) ($info[1] ?? 0);
    if ($forcesize && $maxheightmm > 0) {
        $size = ['width' => (float) max(1, $maxwidthmm), 'height' => (float) max(1, $maxheightmm)];
    } else {
        $size = usercontract_scale_image_mm($pixelw, $pixelh, $maxwidthmm, $maxheightmm);
    }
    $src = 'data:' . $mime . ';base64,' . base64_encode($content);
    return '<img src="' . $src . '" width="' . $size['width'] . 'mm" height="' . $size['height']
        . 'mm" style="width:' . $size['width'] . 'mm;height:' . $size['height'] . 'mm;" alt="" />';
}

/**
 * @param \context_module $context
 * @param string $filearea stamp|signature
 * @return \stored_file|null
 */
function usercontract_get_stored_image(\context_module $context, string $filearea): ?\stored_file {
    if (!in_array($filearea, ['stamp', 'signature'], true)) {
        return null;
    }
    $fs = get_file_storage();
    $files = $fs->get_area_files($context->id, 'mod_usercontract', $filearea, 0, 'itemid, filepath, filename', false);
    if (empty($files)) {
        return null;
    }
    $file = reset($files);
    if (strpos($file->get_mimetype(), 'image/') !== 0) {
        return null;
    }
    return $file;
}

/**
 * @param \context_module $context
 * @param string $filearea
 * @param int $maxwidthmm
 * @param int $maxheightmm
 * @param bool $forcesize
 * @return array{content: string, width: float, height: float}|null
 */
function usercontract_image_size_mm(
    \context_module $context,
    string $filearea,
    int $maxwidthmm,
    int $maxheightmm = 0,
    bool $forcesize = false
): ?array {
    $file = usercontract_get_stored_image($context, $filearea);
    if (!$file) {
        return null;
    }
    $content = $file->get_content();
    $info = @getimagesizefromstring($content);
    $pixelw = (int) ($info[0] ?? 0);
    $pixelh = (int) ($info[1] ?? 0);
    if ($forcesize && $maxheightmm > 0) {
        $size = ['width' => (float) max(1, $maxwidthmm), 'height' => (float) max(1, $maxheightmm)];
    } else {
        $size = usercontract_scale_image_mm($pixelw, $pixelh, $maxwidthmm, $maxheightmm);
    }
    $content = usercontract_optimize_image_binary($content, $size['width'], $size['height']);
    return [
        'content' => $content,
        'width' => $size['width'],
        'height' => $size['height'],
    ];
}

/**
 * Тестовые отступы текста внутри ячеек таблицы реквизитов (мм).
 *
 * @return array{left: float, top: float}
 */
function usercontract_footer_table_test_pad(): array {
    return [
        'left' => 4.0,
        'top' => 4.0,
    ];
}

/**
 * Наложение печати и подписи поверх таблицы реквизитов (TCPDF Image).
 *
 * @param \pdf $pdf
 * @param \context_module $context
 * @param array|null $anchor page, ybottom — страница и низ таблицы реквизитов после writeHTML
 */
function usercontract_pdf_overlay_seals(\pdf $pdf, \context_module $context, ?array $anchor = null): void {
    $stamp = usercontract_image_size_mm($context, 'stamp', 35, 35, true);
    $signature = usercontract_image_size_mm($context, 'signature', 48, 14, false);
    if (!$stamp && !$signature) {
        return;
    }

    $margin = 15.0;
    $pagew = (float) $pdf->getPageWidth();
    $pageh = (float) $pdf->getPageHeight();
    $contentw = $pagew - (2 * $margin);
    $midcol = $margin + ($contentw / 2);

    $restorepage = (int) $pdf->getPage();
    if (!empty($anchor['page'])) {
        $pdf->setPage((int) $anchor['page']);
    }
    $ybottom = isset($anchor['ybottom']) ? (float) $anchor['ybottom'] : (float) $pdf->GetY();
    $shiftleft = 12.0;
    $siggap = 0.5;
    $sigtowardstamp = 4.0;
    $stampup = 6.0;
    $tablepad = usercontract_footer_table_test_pad();
    $tablecellpadleft = $tablepad['left'];
    $pagebottomlimit = $pageh - 6.0;

    $stampw = $stamp['width'] ?? 35.0;
    $stamph = $stamp['height'] ?? 35.0;
    $sigw = $signature['width'] ?? 0.0;
    $sigh = $signature['height'] ?? 0.0;

    $zonebottom = $ybottom + 2.0;
    $ystamp = $zonebottom - $stamph - $stampup;
    if ($ystamp + $stamph > $pagebottomlimit) {
        $ystamp = $pagebottomlimit - $stamph;
    }
    if ($ystamp < $margin) {
        $ystamp = $margin;
    }

    $xstamp = $midcol - $stampw - 2.0 - $shiftleft;
    $xmin = $margin + $tablecellpadleft;
    if ($xstamp < $xmin) {
        $xstamp = $xmin;
    }

    $imgdpi = usercontract_pdf_image_dpi();
    if ($stamp) {
        $pdf->Image('@' . $stamp['content'], $xstamp, $ystamp, $stampw, $stamph, '', '', '', false, $imgdpi);
    }
    if ($signature) {
        $xsig = $stamp
            ? ($xstamp + $stampw + $siggap - $sigtowardstamp)
            : ($midcol - $sigw - 2.0 - $shiftleft);
        if ($xsig < $xmin) {
            $xsig = $xmin;
        }
        $ysig = $stamp ? ($ystamp + $stamph - $sigh) : ($zonebottom - $sigh);
        if ($ysig + $sigh > $pagebottomlimit) {
            $ysig = $pagebottomlimit - $sigh;
        }
        if ($ysig < $margin) {
            $ysig = $margin;
        }
        $pdf->Image('@' . $signature['content'], $xsig, $ysig, $sigw, $sigh, '', '', '', false, $imgdpi);
    }

    if ($restorepage > 0 && (int) $pdf->getPage() !== $restorepage) {
        $pdf->setPage($restorepage);
    }
}

/**
 * @param object $course
 * @param object $cm
 * @param context $context
 * @param string $filearea
 * @param array $args
 * @param bool $forcedownload
 * @param array $options
 * @return bool
 */
function mod_usercontract_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    global $DB;

    if ($context->contextlevel != CONTEXT_MODULE) {
        return false;
    }
    require_course_login($course, true, $cm);

    if ($filearea === \mod_usercontract\local\bulk_export_service::FILEAREA) {
        require_capability('mod/usercontract:viewall', $context);
        $exportid = (int) array_shift($args);
        $export = $DB->get_record('usercontract_export', ['id' => $exportid], '*', IGNORE_MISSING);
        if (!$export || (int) $export->usercontract !== (int) $cm->instance
            || $export->status !== \mod_usercontract\local\bulk_export_service::STATUS_COMPLETE) {
            return false;
        }
        $filename = array_pop($args);
        $filepath = $args ? '/' . implode('/', $args) . '/' : '/';
        $fs = get_file_storage();
        $file = $fs->get_file($context->id, 'mod_usercontract', $filearea, $exportid, $filepath, $filename);
        if (!$file || $file->is_directory()) {
            return false;
        }
        send_stored_file($file, null, 0, $forcedownload, $options);
        return false;
    }

    if (!in_array($filearea, ['stamp', 'signature'], true)) {
        return false;
    }
    $itemid = array_shift($args);
    if ((int) $itemid !== 0) {
        return false;
    }
    $filename = array_pop($args);
    if (empty($args)) {
        $filepath = '/';
    } else {
        $filepath = '/' . implode('/', $args) . '/';
    }
    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'mod_usercontract', $filearea, 0, $filepath, $filename);
    if (!$file || $file->is_directory()) {
        return false;
    }
    send_stored_file($file, 0, 0, $forcedownload, $options);
}

/**
 * Данные обучающегося из профиля аккаунта.
 *
 * @param \stdClass $user
 * @return \stdClass firstname, phone, phone_display, workplace
 */
function usercontract_get_learner_profile(\stdClass $user): \stdClass {
    $phone = trim((string) ($user->phone1 ?? ''));
    $phonedisplay = usercontract_format_phone_display($phone);
    if ($phonedisplay === '' && $phone !== '') {
        $phonedisplay = $phone;
    }

    return (object) [
        'firstname' => trim((string) ($user->firstname ?? '')),
        'phone' => $phone,
        'phone_display' => $phonedisplay,
        'workplace' => '',
    ];
}

/**
 * @param \stdClass $profile
 * @return bool
 */
function usercontract_profile_is_complete(\stdClass $profile): bool {
    if (trim($profile->firstname ?? '') === '') {
        return false;
    }
    if (!usercontract_phone_digits_valid($profile->phone ?? '')) {
        return false;
    }
    if (trim($profile->workplace ?? '') === '') {
        return false;
    }
    return true;
}

/**
 * @param mixed $raw
 * @return string
 */
function usercontract_normalize_phone_digits($raw) {
    $digits = preg_replace('/\D/', '', (string) $raw);
    if ($digits === '') {
        return '';
    }
    if ($digits[0] === '8') {
        $digits = '7' . substr($digits, 1);
    }
    if (strlen($digits) === 10) {
        $digits = '7' . $digits;
    }
    return substr($digits, 0, 11);
}

/**
 * @param mixed $raw
 * @return string
 */
function usercontract_format_phone_masked($digits) {
    $digits = usercontract_normalize_phone_digits($digits);
    if (strlen($digits) !== 11 || $digits[0] !== '7') {
        return '';
    }
    $n = substr($digits, 1);
    return '+7 (' . substr($n, 0, 3) . ') ' . substr($n, 3, 3) . '-' . substr($n, 6, 2) . '-' . substr($n, 8, 2);
}

/**
 * @param mixed $raw
 * @return string
 */
function usercontract_format_phone_display($raw) {
    $digits = usercontract_normalize_phone_digits($raw);
    if (strlen($digits) === 11 && $digits[0] === '7') {
        return usercontract_format_phone_masked($digits);
    }
    return trim((string) $raw);
}

/**
 * @param mixed $raw
 * @return bool
 */
function usercontract_phone_digits_valid($raw) {
    $digits = usercontract_normalize_phone_digits($raw);
    return strlen($digits) === 11 && $digits[0] === '7';
}

/**
 * @param \stdClass $profile
 * @return bool
 */
function usercontract_profile_has_firstname(\stdClass $profile): bool {
    return trim($profile->firstname ?? '') !== '';
}

/**
 * @param \stdClass|null $submission
 * @return \stdClass|null
 */
function usercontract_submission_profile_snapshot($submission): ?\stdClass {
    if (!$submission || empty($submission->data)) {
        return null;
    }
    $decoded = json_decode($submission->data, true);
    if (!is_array($decoded)) {
        return null;
    }
    $profile = $decoded['profile'] ?? null;
    if (!is_array($profile)) {
        return null;
    }
    return (object) $profile;
}

/**
 * Контактный телефон из принятого договора (для списка проверяющего).
 *
 * @param \stdClass|null $submission
 * @return string
 */
function usercontract_submission_display_phone($submission) {
    $snap = usercontract_submission_profile_snapshot($submission);
    if (!$snap || empty($snap->phone)) {
        return '';
    }
    $display = usercontract_format_phone_display($snap->phone);
    return $display !== '' ? $display : trim((string) $snap->phone);
}

/**
 * Место работы из принятого договора (для списка проверяющего).
 *
 * @param \stdClass|null $submission
 * @return string
 */
function usercontract_submission_display_workplace($submission) {
    $snap = usercontract_submission_profile_snapshot($submission);
    if (!$snap || !isset($snap->workplace)) {
        return '';
    }
    return trim((string) $snap->workplace);
}

/**
 * Данные обучающего для PDF: имя из профиля, телефон и место работы из принятого договора.
 *
 * @param \stdClass $user
 * @param \stdClass $submission
 * @return \stdClass
 */
function usercontract_learner_for_pdf(\stdClass $user, \stdClass $submission): \stdClass {
    $learner = usercontract_get_learner_profile($user);
    $snap = usercontract_submission_profile_snapshot($submission);
    if ($snap) {
        if (!empty($snap->firstname)) {
            $learner->firstname = trim((string) $snap->firstname);
        } else if (!empty($snap->fullname)) {
            $learner->firstname = trim((string) $snap->fullname);
        }
        if (!empty($snap->phone)) {
            $learner->phone = usercontract_normalize_phone_digits($snap->phone);
            $learner->phone_display = usercontract_format_phone_display($learner->phone);
        }
        if (isset($snap->workplace)) {
            $learner->workplace = trim((string) $snap->workplace);
        }
    }
    return $learner;
}

/**
 * @param array $data
 * @return array
 */
function usercontract_accept_form_validation_errors(array $data): array {
    $errors = [];
    if (!usercontract_phone_digits_valid($data['phone'] ?? '')) {
        $errors['phone'] = get_string('phoneinvalid', 'usercontract');
    }
    if (trim((string) ($data['workplace'] ?? '')) === '') {
        $errors['workplace'] = get_string('fieldempty', 'usercontract');
    }
    return $errors;
}

/**
 * Ширина полей формы договора (size/cols и max-width в CSS).
 *
 * @return int
 */
function usercontract_accept_field_size(): int {
    return 64;
}

/**
 * @param string[] $classes
 * @param array $extra
 * @return array
 */
function usercontract_accept_text_attrs(array $classes, array $extra = []): array {
    $class = trim(implode(' ', array_merge(['usercontract-field-full'], $classes)));
    return array_merge([
        'size' => usercontract_accept_field_size(),
        'maxlength' => 255,
        'class' => $class,
    ], $extra);
}

/**
 * @param string[] $classes
 * @param array $extra
 * @return array
 */
function usercontract_accept_textarea_attrs(array $classes = [], array $extra = []): array {
    $class = trim(implode(' ', array_merge(['usercontract-field-full'], $classes)));
    return array_merge([
        'rows' => 3,
        'cols' => usercontract_accept_field_size(),
        'class' => $class,
    ], $extra);
}

/**
 * CSS полей формы принятия договора.
 */
function usercontract_accept_form_layout_init(): void {
    global $PAGE;
    if (!$PAGE) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;
    $em = usercontract_accept_field_size();
    $css = <<<EOT
.mform.usercontract-accept-form .fitem .felement > input[type="text"].usercontract-field-full,
.mform.usercontract-accept-form .fitem .felement > input[type="text"].usercontract-phone,
.mform.usercontract-accept-form .fitem .felement > textarea.usercontract-field-full {
    width: min(100%, {$em}em);
    max-width: 100%;
    box-sizing: border-box;
}
.mform.usercontract-accept-form .fitem .fitemtitle,
.mform.usercontract-accept-form .fitem .col-form-label {
    min-width: 11em;
    white-space: nowrap;
    vertical-align: top;
    padding-top: 0.45rem;
}
.mform.usercontract-accept-form .fitem .felement {
    vertical-align: top;
}
.mform.usercontract-accept-form .fitem .felement .form-control {
    width: min(100%, {$em}em);
    max-width: 100%;
    box-sizing: border-box;
}
.usercontract-submissions-heading {
    margin-bottom: 1.25rem !important;
}
.usercontract-search-form .usercontract-search-label {
    margin-bottom: 0;
    white-space: nowrap;
}
.usercontract-search-form .usercontract-search-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 0.5rem;
}
.usercontract-toolbar-block {
    padding: 0.75rem 1rem;
    margin-bottom: 0.75rem;
    border: 1px solid #dee2e6;
    border-radius: 0.25rem;
    background: #f8f9fa;
}
.usercontract-toolbar-block > h4 {
    margin: 0 0 0.65rem 0;
    font-size: 1rem;
    font-weight: 600;
}
.usercontract-toolbar-downloads .usercontract-download-actions {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 0.5rem;
}
.usercontract-toolbar-downloads .usercontract-bulk-export-buttons {
    margin-top: 0.5rem;
    margin-bottom: 0;
}
EOT;
    $PAGE->requires->js_init_code(
        '(function(){if(document.getElementById("usercontract-layout-style")){return;}'
        . 'var st=document.createElement("style");st.id="usercontract-layout-style";'
        . 'st.textContent=' . json_encode($css, JSON_UNESCAPED_UNICODE) . ';'
        . 'document.head.appendChild(st);})();'
    );
}

/**
 * Маска телефона «+7 (XXX) XXX-XX-XX».
 */
function usercontract_phone_mask_init(): void {
    global $PAGE;
    if (!$PAGE) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;
    $masktitle = json_encode(get_string('phone_mask_title', 'usercontract'), JSON_UNESCAPED_UNICODE);
    $js = <<<EOT
(function() {
    var MASK_TEMPLATE = '+7 (___) ___-__-__';
    var SLOT_POS = [4, 5, 6, 9, 10, 11, 13, 14, 16, 17];
    var MAX_NATIONAL = 10;
    var MASK_TITLE = {$masktitle};
    function digitsOnly(s) { return String(s || '').replace(/\D/g, ''); }
    function toNationalDigits(s) {
        var dig = digitsOnly(s).slice(0, 11);
        if (dig.length > 0 && dig.charAt(0) === '8') { dig = '7' + dig.slice(1); }
        if (dig.length === 11 && dig.charAt(0) === '7') { return dig.slice(1); }
        if (dig.charAt(0) === '7') { return dig.slice(1); }
        return dig.slice(0, MAX_NATIONAL);
    }
    function fmt(d) {
        var national = toNationalDigits(d).slice(0, MAX_NATIONAL);
        var arr = MASK_TEMPLATE.split('');
        for (var j = 0; j < national.length; j++) { arr[SLOT_POS[j]] = national.charAt(j); }
        return arr.join('');
    }
    function nextCaret(str) { var i = str.indexOf('_'); return i === -1 ? str.length : i; }
    function bind(inp) {
        if (!inp || inp.getAttribute('data-phone-mask') === '1') { return; }
        inp.setAttribute('data-phone-mask', '1');
        inp.setAttribute('inputmode', 'tel');
        if (!inp.getAttribute('title')) { inp.setAttribute('title', MASK_TITLE); }
        function currentDigits() { return digitsOnly(inp.value); }
        function applyDigits(dig) {
            var neu = fmt(dig);
            inp.value = neu;
            try { inp.setSelectionRange(nextCaret(neu), nextCaret(neu)); } catch (e) {}
        }
        inp.addEventListener('focus', function() {
            if (toNationalDigits(inp.value).length === 0) { inp.value = MASK_TEMPLATE; }
            try { inp.setSelectionRange(nextCaret(inp.value), nextCaret(inp.value)); } catch (e) {}
        });
        inp.addEventListener('blur', function() {
            if (toNationalDigits(inp.value).length === 0) { inp.value = ''; }
            else { applyDigits(currentDigits()); }
        });
        inp.addEventListener('keydown', function(e) {
            var k = e.key;
            if (k === 'Tab' || k === 'Escape' || k === 'Enter' || k.indexOf('Arrow') === 0 || k === 'Home' || k === 'End') { return; }
            if (e.ctrlKey || e.metaKey || e.altKey) { return; }
            if (k === 'Backspace') {
                e.preventDefault();
                var nat = toNationalDigits(currentDigits());
                applyDigits(nat.slice(0, -1));
                return;
            }
            if (k && k.length === 1 && /[0-9]/.test(k)) {
                e.preventDefault();
                var nat2 = toNationalDigits(currentDigits());
                if (nat2.length >= MAX_NATIONAL) { return; }
                applyDigits(nat2 + k);
                return;
            }
            if (k && k.length === 1) { e.preventDefault(); }
        });
        inp.addEventListener('input', function() {
            var neu = fmt(currentDigits());
            if (inp.value !== neu) { inp.value = neu; }
            try { inp.setSelectionRange(nextCaret(neu), nextCaret(neu)); } catch (e) {}
        });
        inp.addEventListener('paste', function(e) {
            e.preventDefault();
            var t = (e.clipboardData || window.clipboardData).getData('text') || '';
            applyDigits(toNationalDigits(currentDigits()) + digitsOnly(t));
        });
        if (toNationalDigits(inp.value).length > 0) { applyDigits(currentDigits()); }
    }
    function run() {
        document.querySelectorAll('input[name="phone"], input.usercontract-phone').forEach(bind);
    }
    run();
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', run); }
    window.addEventListener('load', run);
})();
EOT;
    $PAGE->requires->js_init_code($js);
}

/**
 * @param int $cmid
 * @param int $groupid
 * @param array $extra
 * @return array
 */
function usercontract_view_page_params($cmid, $groupid = 0, array $extra = []) {
    $p = array_merge(['id' => $cmid], $extra);
    if ($groupid > 0) {
        $p['group'] = $groupid;
    }
    return $p;
}

/**
 * Фильтр списка: -1 все, 0 непроверенные, 1 проверенные.
 *
 * @param mixed $raw
 * @return int
 */
function usercontract_normalize_verified_filter($raw) {
    $v = (int) $raw;
    if ($v === 0 || $v === 1) {
        return $v;
    }
    return -1;
}

/**
 * Имя пользователя для отображения (только firstname).
 *
 * @param \stdClass $user
 * @return string
 */
function usercontract_user_firstname(\stdClass $user): string {
    return trim((string) ($user->firstname ?? ''));
}

/**
 * @return string[]
 */
function usercontract_submissions_sort_fields(): array {
    return ['timemodified', 'verified'];
}

/**
 * @param mixed $sort
 * @return string
 */
function usercontract_normalize_submissions_sort($sort): string {
    $sort = strtolower(trim((string) $sort));
    return in_array($sort, usercontract_submissions_sort_fields(), true) ? $sort : 'timemodified';
}

/**
 * @param mixed $dir
 * @return string
 */
function usercontract_normalize_submissions_sortdir($dir): string {
    $dir = strtolower(trim((string) $dir));
    return $dir === 'asc' ? 'asc' : 'desc';
}

/**
 * @param string $sort
 * @param string $sortdir
 * @return string
 */
function usercontract_submissions_order_sql(string $sort, string $sortdir): string {
    $sort = usercontract_normalize_submissions_sort($sort);
    $sortdir = usercontract_normalize_submissions_sortdir($sortdir);
    $dir = $sortdir === 'asc' ? 'ASC' : 'DESC';
    if ($sort === 'verified') {
        return " ORDER BY s.verified $dir, s.timemodified DESC";
    }
    return " ORDER BY s.timemodified $dir";
}

/**
 * @param \mod_usercontract\local\view_page $page
 * @param string $column
 * @param string $label
 * @param string $search
 * @param int $verifiedfilter
 * @param string $currentsort
 * @param string $currentdir
 * @return string
 */
function usercontract_submissions_sort_header(
    \mod_usercontract\local\view_page $page,
    string $column,
    string $label,
    string $search,
    int $verifiedfilter,
    string $currentsort,
    string $currentdir
): string {
    $currentsort = usercontract_normalize_submissions_sort($currentsort);
    $currentdir = usercontract_normalize_submissions_sortdir($currentdir);
    $newdir = ($currentsort === $column && $currentdir === 'desc') ? 'asc' : 'desc';
    $url = $page->url_view(usercontract_submissions_list_url_extra($search, $verifiedfilter, 0, $column, $newdir));
    $arrow = '';
    if ($currentsort === $column) {
        $arrow = $currentdir === 'asc' ? ' ▲' : ' ▼';
    }
    return html_writer::link($url, $label . $arrow);
}

/**
 * Query-параметры списка договоров (поиск, фильтр проверки, страница, сортировка).
 *
 * @param string $search
 * @param int $verifiedfilter
 * @param int $pageindex
 * @param string $sort
 * @param string $sortdir
 * @return array
 */
function usercontract_submissions_list_url_extra($search, $verifiedfilter, $pageindex = 0, $sort = 'timemodified', $sortdir = 'desc') {
    $extra = ['tab' => 'submissions'];
    $search = trim($search);
    if ($search !== '') {
        $extra['search'] = $search;
    }
    if ($verifiedfilter >= 0) {
        $extra['verifiedfilter'] = $verifiedfilter;
    }
    if ($pageindex > 0) {
        $extra['page'] = $pageindex;
    }
    $extra['sort'] = usercontract_normalize_submissions_sort($sort);
    $extra['sortdir'] = usercontract_normalize_submissions_sortdir($sortdir);
    return $extra;
}

/**
 * Группы, доступные пользователю в элементе курса (ядро с Moodle 4.3; для 3.8 — запасной вариант).
 *
 * @param \stdClass|\cm_info $cm
 * @param int $userid
 * @return array<int, \stdClass>
 */
function usercontract_get_activity_allowed_groups($cm, $userid = 0) {
    global $USER;

    if (function_exists('groups_get_activity_allowed_groups')) {
        return groups_get_activity_allowed_groups($cm, $userid);
    }

    if (empty($userid)) {
        $userid = (int) $USER->id;
    }

    $course = get_course($cm->course);
    if (!groups_get_activity_groupmode($cm, $course)) {
        return [];
    }

    $context = context_course::instance($course->id);
    if (has_capability('moodle/site:accessallgroups', $context, $userid)) {
        return groups_get_all_groups($course->id, 0, $cm->groupingid);
    }

    return groups_get_all_groups($course->id, $userid, $cm->groupingid);
}

/**
 * @return int
 */
function usercontract_submissions_per_page() {
    return 20;
}

/**
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $userid
 * @param bool $verified
 */
function usercontract_sync_completion_for_user(\stdClass $cm, \stdClass $course, int $userid, bool $verified) {
    global $DB;

    $instance = $DB->get_record('usercontract', ['id' => $cm->instance], 'completionverified', IGNORE_MISSING);
    if (!$instance || empty($instance->completionverified)) {
        return;
    }

    $completion = new completion_info($course);
    if (!$completion->is_enabled($cm)) {
        return;
    }
    if ($verified) {
        $completion->update_state($cm, COMPLETION_COMPLETE, $userid);
    } else {
        $completion->update_state($cm, COMPLETION_INCOMPLETE, $userid);
    }
}

/**
 * Автоматическое завершение (Moodle 3.8: этот callback; Moodle 4+ — также custom_completion).
 *
 * @param stdClass $course
 * @param stdClass $cm
 * @param int $userid
 * @param bool $type
 * @return bool
 */
function usercontract_get_completion_state($course, $cm, $userid, $type) {
    global $DB;

    $instance = $DB->get_record('usercontract', ['id' => $cm->instance], 'completionverified', IGNORE_MISSING);
    if (!$instance || empty($instance->completionverified)) {
        return $type;
    }

    $sub = $DB->get_record('usercontract_submission', [
        'usercontract' => $cm->instance,
        'userid' => $userid,
    ], 'verified', IGNORE_MISSING);

    if ($sub && usercontract_submission_is_verified($sub)) {
        return true;
    }
    return false;
}

/**
 * @param \stdClass $instance
 * @return bool
 */
function usercontract_instance_has_visible_intro($instance): bool {
    if (!is_object($instance) || !property_exists($instance, 'intro')) {
        return false;
    }
    return trim(strip_tags((string) $instance->intro)) !== '';
}

/**
 * @param \stdClass $coursemodule
 * @return \cached_cm_info|false
 */
function usercontract_get_coursemodule_info($coursemodule) {
    global $DB;

    if (!$record = $DB->get_record('usercontract', ['id' => $coursemodule->instance],
        'id, name, intro, introformat, completionverified')) {
        return false;
    }

    $info = new cached_cm_info();
    $info->name = $record->name;
    if (!empty($coursemodule->showdescription) && usercontract_instance_has_visible_intro($record)) {
        $info->content = format_module_intro('usercontract', $record, $coursemodule->id, false);
    }
    if ($coursemodule->completion == COMPLETION_TRACKING_AUTOMATIC) {
        $info->customdata['customcompletionrules']['completionverified'] = (int) $record->completionverified;
    }
    return $info;
}

/**
 * @param \cm_info|\stdClass $cm
 * @return string[]
 */
function mod_usercontract_get_completion_active_rule_descriptions($cm) {
    if (empty($cm->customdata['customcompletionrules']) || $cm->completion != COMPLETION_TRACKING_AUTOMATIC) {
        return [];
    }
    $descriptions = [];
    if (!empty($cm->customdata['customcompletionrules']['completionverified'])) {
        $descriptions[] = get_string('completiondetail:verified', 'usercontract');
    }
    return $descriptions;
}

/**
 * @param \stdClass $submission
 * @return bool
 */
function usercontract_submission_is_verified($submission) {
    return !empty($submission->verified);
}

/**
 * Полностью принятый договор (блокировка повторной подачи для слушателя).
 *
 * @param string|null $raw JSON принятия
 * @return bool
 */
function usercontract_submission_payload_is_complete($raw) {
    if ($raw === null || trim((string) $raw) === '' || trim((string) $raw) === '{}') {
        return false;
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded) || empty($decoded['accepted'])) {
        return false;
    }
    $profile = $decoded['profile'] ?? null;
    if (!is_array($profile)) {
        return false;
    }
    return usercontract_accept_form_validation_errors([
        'phone' => $profile['phone'] ?? '',
        'workplace' => $profile['workplace'] ?? '',
    ]) === [];
}

/**
 * @param \stdClass|null $submission
 * @return bool
 */
function usercontract_submission_is_locked($submission) {
    return $submission !== null && !empty($submission->id)
        && usercontract_submission_payload_is_complete($submission->data);
}

/**
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $foruserid
 * @return int
 */
function usercontract_normalize_export_groupid($cm, $course, $foruserid) {
    $gid = optional_param('group', 0, PARAM_INT);
    if ($gid <= 0 || !groups_get_activity_groupmode($cm, $course)) {
        return 0;
    }
    $allowed = usercontract_get_activity_allowed_groups($cm, $foruserid);
    if (!isset($allowed[$gid])) {
        return 0;
    }
    return (int) $gid;
}

/**
 * @param int $groupid
 * @return array{join: string, params: array<string, int>}
 */
function usercontract_submissions_group_join_sql($groupid) {
    if ($groupid <= 0) {
        return ['join' => '', 'params' => []];
    }
    return [
        'join' => ' JOIN {groups_members} gmm ON gmm.userid = s.userid AND gmm.groupid = :gmmgid ',
        'params' => ['gmmgid' => $groupid],
    ];
}

/**
 * Лимит PDF в одном ZIP (защита от таймаута и нехватки памяти).
 *
 * @return int
 */
function usercontract_zip_pdf_limit() {
    return 80;
}

/**
 * Увеличить лимиты PHP на время тяжёлого экспорта.
 */
function usercontract_raise_export_limits() {
    if (class_exists('\core_php_time_limit')) {
        \core_php_time_limit::raise(600);
    } else {
        @set_time_limit(600);
    }
    if (function_exists('raise_memory_limit')) {
        raise_memory_limit(MEMORY_EXTRA);
    }
}

/**
 * @param \context $context
 * @param \stdClass $instance
 * @param int $userid
 */
function usercontract_send_pdf_download(\context $context, \stdClass $instance, $userid = 0) {
    global $DB, $USER;

    $userid = (int) $userid;
    if ($userid <= 0 || $userid === (int) $USER->id) {
        require_capability('mod/usercontract:submit', $context);
        $userid = (int) $USER->id;
    } else {
        require_capability('mod/usercontract:viewall', $context);
    }

    $sub = $DB->get_record('usercontract_submission', [
        'usercontract' => $instance->id,
        'userid' => $userid,
    ], '*', IGNORE_MISSING);

    if (!$sub) {
        throw new moodle_exception('submissionmissing', 'usercontract');
    }

    $user = core_user::get_user($userid, '*', MUST_EXIST);
    $profile = usercontract_learner_for_pdf($user, $sub);
    if (!usercontract_profile_is_complete($profile)) {
        throw new moodle_exception('submissioninvalid', 'usercontract');
    }

    if ($context->contextlevel !== CONTEXT_MODULE) {
        throw new moodle_exception('invalidcontext');
    }
    \mod_usercontract\contract_pdf::send_download($instance, $user, $profile, $context);
}

/**
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $userid
 * @param bool $exportall
 * @param int $groupparam
 * @return int
 */
function usercontract_resolve_bulk_export_groupid($cm, $course, $userid, $exportall, $groupparam) {
    if ($exportall) {
        return 0;
    }
    if ($groupparam < 1) {
        throw new \moodle_exception('bulkexportgrouprequired', 'usercontract');
    }
    $allowed = usercontract_get_activity_allowed_groups($cm, $userid);
    if (!isset($allowed[$groupparam])) {
        throw new \moodle_exception('bulkexportinvalidgroup', 'usercontract');
    }
    return (int) $groupparam;
}

/**
 * @param int $groupid
 * @param \stdClass $cm
 * @param \stdClass $course
 * @param int $userid
 * @return string
 */
function usercontract_bulk_export_scope_label($groupid, $cm, $course, $userid) {
    if ((int) $groupid <= 0) {
        return get_string('bulkexportscope_course', 'usercontract');
    }
    $allowed = usercontract_get_activity_allowed_groups($cm, $userid);
    if (isset($allowed[$groupid])) {
        return get_string('bulkexportscope_group', 'usercontract', $allowed[$groupid]->name);
    }
    return get_string('bulkexportscope_groupid', 'usercontract', $groupid);
}

/**
 * @param \mod_usercontract\local\view_page $page
 */
function usercontract_render_submissions_filter_block(
    \mod_usercontract\local\view_page $page,
    string $search,
    int $verifiedfilter,
    string $sort = 'timemodified',
    string $sortdir = 'desc'
) {
    echo html_writer::start_div('usercontract-toolbar-block usercontract-toolbar-filters');
    echo html_writer::tag('h4', get_string('toolbar_filters', 'usercontract'));
    echo html_writer::start_tag('form', [
        'method' => 'get',
        'action' => $page->url_view(['tab' => 'submissions'])->out(false),
        'class' => 'usercontract-search-form mb-0',
    ]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $page->cm->id]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'tab', 'value' => 'submissions']);
    if ($page->exportgroupid > 0) {
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'group', 'value' => $page->exportgroupid]);
    }
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sort', 'value' => usercontract_normalize_submissions_sort($sort)]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sortdir', 'value' => usercontract_normalize_submissions_sortdir($sortdir)]);
    echo html_writer::start_div('usercontract-search-row');
    echo html_writer::tag('label', get_string('searchparticipant', 'usercontract'), [
        'for' => 'usercontract-search',
        'class' => 'usercontract-search-label',
    ]);
    echo html_writer::empty_tag('input', [
        'type' => 'text',
        'name' => 'search',
        'id' => 'usercontract-search',
        'value' => s($search),
        'size' => 40,
        'class' => 'form-control',
        'placeholder' => get_string('searchparticipantplaceholder', 'usercontract'),
    ]);
    echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => get_string('search'), 'class' => 'btn btn-secondary']);
    echo html_writer::tag('label', get_string('filterverified', 'usercontract'), [
        'for' => 'usercontract-vfilter',
        'class' => 'usercontract-search-label ms-2',
    ]);
    echo html_writer::select([
        -1 => get_string('filterverifiedall', 'usercontract'),
        1 => get_string('filterverifiedyes', 'usercontract'),
        0 => get_string('filterverifiedno', 'usercontract'),
    ], 'verifiedfilter', $verifiedfilter, false, [
        'id' => 'usercontract-vfilter',
        'class' => 'form-select ms-1',
    ]);
    if ($search !== '' || $verifiedfilter >= 0) {
        echo html_writer::link($page->url_view(['tab' => 'submissions']), get_string('clear'), ['class' => 'btn btn-link']);
    }
    echo html_writer::end_div();
    echo html_writer::end_tag('form');
    echo html_writer::end_div();
}

function usercontract_render_submissions_download_block(\mod_usercontract\local\view_page $page) {
    global $OUTPUT;

    $exportbase = ['id' => $page->cm->id, 'sesskey' => sesskey()];
    if ($page->exportgroupid > 0) {
        $exportbase['group'] = $page->exportgroupid;
    }

    echo html_writer::start_div('usercontract-toolbar-block usercontract-toolbar-downloads');
    echo html_writer::tag('h4', get_string('toolbar_downloads', 'usercontract'));
    echo html_writer::start_div('usercontract-download-actions');
    echo $OUTPUT->single_button(
        new \moodle_url('/mod/usercontract/export_zip.php', $exportbase),
        get_string('downloadzip', 'usercontract', usercontract_zip_pdf_limit()),
        'get'
    );
    echo html_writer::end_div();
    usercontract_render_bulk_export_buttons($page);
    echo html_writer::end_div();
}

function usercontract_render_bulk_export_buttons(\mod_usercontract\local\view_page $page) {
    global $OUTPUT, $USER;

    $base = ['id' => $page->cm->id, 'sesskey' => sesskey()];
    $exportallurl = new \moodle_url('/mod/usercontract/export_bulk_start.php', $base + ['all' => 1]);

    echo html_writer::start_div('usercontract-bulk-export-buttons');
    echo $OUTPUT->single_button($exportallurl, get_string('downloadbulkexport_all', 'usercontract'), 'post');

    if (groups_get_activity_groupmode($page->cm, $page->course)) {
        if ($page->exportgroupid > 0) {
            $allowed = usercontract_get_activity_allowed_groups($page->cm, $USER->id);
            $gname = isset($allowed[$page->exportgroupid]) ? $allowed[$page->exportgroupid]->name : '';
            $exportgroupurl = new \moodle_url('/mod/usercontract/export_bulk_start.php', $base + [
                'group' => $page->exportgroupid,
            ]);
            echo ' ';
            echo $OUTPUT->single_button(
                $exportgroupurl,
                get_string('downloadbulkexport_group', 'usercontract', $gname),
                'post'
            );
        } else {
            echo html_writer::tag('p', get_string('downloadbulkexport_group_select', 'usercontract'), [
                'class' => 'small text-muted mb-0 mt-1',
            ]);
        }
    }

    echo html_writer::tag('p', get_string('downloadbulkexport_help', 'usercontract'), [
        'class' => 'small text-muted mb-0 mt-1',
    ]);
    echo html_writer::end_div();
}

/**
 * @param \mod_usercontract\local\view_page $page
 */
function usercontract_render_bulk_export_panel(\mod_usercontract\local\view_page $page) {
    global $OUTPUT, $DB;

    $exports = \mod_usercontract\local\bulk_export_service::list_recent((int) $page->instance->id, 6);
    if (!$exports) {
        return;
    }

    echo html_writer::tag('h4', get_string('bulkexportheading', 'usercontract'), ['class' => 'mt-3']);
    echo html_writer::tag('p', get_string('bulkexporthelp', 'usercontract'), ['class' => 'text-muted small']);

    $table = new html_table();
    $table->head = [
        get_string('bulkexportcolwhen', 'usercontract'),
        get_string('bulkexportcolwho', 'usercontract'),
        get_string('bulkexportcolscope', 'usercontract'),
        get_string('bulkexportcolstatus', 'usercontract'),
        get_string('bulkexportcoldownload', 'usercontract'),
    ];
    $table->attributes['class'] = 'generaltable table-sm';

    foreach ($exports as $export) {
        $user = $DB->get_record('user', ['id' => $export->requestedby], 'id,firstname,lastname', IGNORE_MISSING);
        $whotext = $user ? usercontract_user_firstname($user) : (string) $export->requestedby;
        $status = get_string('bulkexportstatus_' . $export->status, 'usercontract');
        if ($export->status === \mod_usercontract\local\bulk_export_service::STATUS_FAILED && !empty($export->errormsg)) {
            $status .= html_writer::tag('div', s($export->errormsg), ['class' => 'text-danger small']);
        }
        if ($export->status === \mod_usercontract\local\bulk_export_service::STATUS_COMPLETE) {
            $status .= html_writer::tag('span', ' (' . get_string('bulkexportpdfcount', 'usercontract', (object) [
                'count' => $export->pdfcount,
                'parts' => $export->partcount,
            ]) . ')', ['class' => 'small text-muted']);
        }
        $links = '';
        if ($export->status === \mod_usercontract\local\bulk_export_service::STATUS_COMPLETE) {
            $parts = [];
            for ($p = 1; $p <= (int) $export->partcount; $p++) {
                $url = \mod_usercontract\local\bulk_export_service::part_download_url($export, $page->context, $p);
                if ($url) {
                    $parts[] = html_writer::link($url, get_string('bulkexportpart', 'usercontract', $p));
                }
            }
            $links = implode(' · ', $parts);
        }
        $scope = usercontract_bulk_export_scope_label(
            (int) $export->groupid,
            $page->cm,
            $page->course,
            (int) $export->requestedby
        );

        $table->data[] = [
            userdate($export->timecreated),
            s($whotext),
            s($scope),
            $status,
            $links,
        ];
    }
    echo html_writer::table($table);
}
