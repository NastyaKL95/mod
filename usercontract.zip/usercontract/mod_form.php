<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/course/moodleform_mod.php');
require_once($CFG->dirroot . '/lib/filelib.php');

/**
 * Настройки элемента курса «Договор-оферта».
 */
class mod_usercontract_mod_form extends moodleform_mod {

    /**
     * Форма создания/редактирования модуля.
     */
    public function definition() {
        global $CFG;
        $mform = $this->_form;

        $mform->addElement('header', 'generalhdr', get_string('general', 'form'));
        $mform->addElement('text', 'name', get_string('modulename', 'usercontract'), ['size' => 64]);
        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('name', PARAM_TEXT);
        } else {
            $mform->setType('name', PARAM_CLEANHTML);
        }
        $mform->addRule('name', null, 'required', null, 'client');

        $this->standard_intro_elements();

        $course = $this->get_course();
        $coursename = format_string($course->fullname);

        $mform->addElement('header', 'hdr_contract', get_string('settings_contract', 'usercontract'));
        $mform->addElement('static', 'programfromcourse', get_string('field_programname', 'usercontract'),
            get_string('programfromcourse_static', 'usercontract', (object) ['coursename' => $coursename]));
        $mform->addHelpButton('programfromcourse', 'field_programname', 'usercontract');

        $mform->addElement('text', 'programhours', get_string('field_programhours', 'usercontract'), ['size' => 8]);
        $mform->setType('programhours', PARAM_INT);
        $mform->addRule('programhours', null, 'required', null, 'client');
        $mform->addRule('programhours', null, 'numeric', null, 'client');
        $mform->addHelpButton('programhours', 'field_programhours', 'usercontract');

        $mform->addElement('textarea', 'representative', get_string('field_representative', 'usercontract'),
            ['rows' => 3, 'cols' => 80]);
        $mform->setType('representative', PARAM_RAW);
        $mform->addHelpButton('representative', 'field_representative', 'usercontract');

        $mform->addElement('header', 'hdr_images', get_string('settings_images', 'usercontract'));
        $fileopts = usercontract_image_filemanager_options();

        $mform->addElement('filemanager', 'stampimage_filemanager', get_string('field_stampimage', 'usercontract'), null, $fileopts);
        $mform->addHelpButton('stampimage_filemanager', 'field_stampimage', 'usercontract');

        $mform->addElement('filemanager', 'signatureimage_filemanager', get_string('field_signatureimage', 'usercontract'), null, $fileopts);
        $mform->addHelpButton('signatureimage_filemanager', 'field_signatureimage', 'usercontract');

        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }

    /**
     * @param array $defaultvalues
     */
    public function data_preprocessing(&$defaultvalues) {
        parent::data_preprocessing($defaultvalues);
        if (!isset($defaultvalues['programhours']) || $defaultvalues['programhours'] === '') {
            $defaultvalues['programhours'] = 0;
        }
        if (empty($defaultvalues['representative'])) {
            $defaultvalues['representative'] = get_string('default_representative', 'usercontract');
        }

        if ($this->current->instance && !empty($this->context)) {
            $opts = usercontract_image_filemanager_options();
            $data = (object) (array) $defaultvalues;
            $data = file_prepare_standard_filemanager(
                $data,
                'stampimage',
                $opts,
                $this->context,
                'mod_usercontract',
                'stamp',
                0
            );
            $data = file_prepare_standard_filemanager(
                $data,
                'signatureimage',
                $opts,
                $this->context,
                'mod_usercontract',
                'signature',
                0
            );
            foreach ((array) $data as $key => $value) {
                $defaultvalues[$key] = $value;
            }
        } else {
            $defaultvalues['stampimage_filemanager'] = usercontract_prepare_default_draft('stamp');
            $defaultvalues['signatureimage_filemanager'] = usercontract_prepare_default_draft('signature');
        }
    }

    /**
     * Суффикс полей завершения в Moodle 4+; в 3.8 поля без суффикса.
     *
     * @return string
     */
    protected function completion_field_suffix() {
        if (method_exists($this, 'get_suffix')) {
            return (string) $this->get_suffix();
        }
        return '';
    }

    /**
     * @return string
     */
    protected function completion_verified_element_name() {
        return 'completionverified' . $this->completion_field_suffix();
    }

    /**
     * @return array
     */
    public function add_completion_rules() {
        $mform = $this->_form;
        $element = $this->completion_verified_element_name();
        $mform->addElement('checkbox', $element, '', get_string('completionverified', 'usercontract'));
        $mform->setDefault($element, 1);
        return [$element];
    }

    /**
     * @param array $data
     * @return bool
     */
    public function completion_rule_enabled($data) {
        $element = $this->completion_verified_element_name();
        return !empty($data[$element]);
    }

    /**
     * @param \stdClass $data
     */
    public function data_postprocessing($data) {
        parent::data_postprocessing($data);
        if (empty($data->completionunlocked)) {
            return;
        }
        $suffix = $this->completion_field_suffix();
        $completionfield = 'completion' . $suffix;
        $verifiedfield = $this->completion_verified_element_name();
        $completion = isset($data->{$completionfield}) ? $data->{$completionfield} : ($data->completion ?? null);
        $autocompletion = !empty($completion) && (int) $completion === COMPLETION_TRACKING_AUTOMATIC;
        if (!$autocompletion || empty($data->{$verifiedfield})) {
            $data->{$verifiedfield} = 0;
        }
    }
}
