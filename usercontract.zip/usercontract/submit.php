<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_usercontract\local\view_page;

$id = required_param('id', PARAM_INT);

$page = view_page::from_cm_id($id);

global $PAGE, $USER, $DB, $OUTPUT;

$PAGE->set_url($page->url_submit());

if (!$page->cansubmit || ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    redirect($page->url_view(['tab' => 'form']));
}

if (!$page->canviewall) {
    $earlyown = $page->get_own_submission();
    if ($earlyown && usercontract_submission_is_locked($earlyown)) {
        redirect(
            $page->url_view(['tab' => 'form']),
            get_string('alreadysubmitted', 'usercontract'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }
}

$user = $USER;
$learner = usercontract_get_learner_profile($user);
if (!usercontract_profile_has_firstname($learner)) {
    redirect(
        $page->url_view(['tab' => 'form']),
        get_string('profilenamerequired', 'usercontract'),
        null,
        \core\output\notification::NOTIFY_ERROR
    );
}

$acceptform = new \mod_usercontract\form\accept_form($page->url_submit(), ['learner' => $learner]);

if ($acceptform->is_cancelled()) {
    redirect(course_get_url($page->course->id));
}

if ($data = $acceptform->get_data()) {
    require_sesskey();
    if (empty($data->confirmaccept)) {
        redirect(
            $page->url_view(['tab' => 'form']),
            get_string('confirmrequired', 'usercontract'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }

    $phone = usercontract_normalize_phone_digits($data->phone);
    $workplace = trim((string) $data->workplace);
    $payload = json_encode([
        'accepted' => 1,
        'confirmaccept' => 1,
        'profile' => [
            'firstname' => $learner->firstname,
            'phone' => $phone,
            'workplace' => $workplace,
        ],
    ], JSON_UNESCAPED_UNICODE);

    $now = time();
    $existing = $page->get_own_submission();

    if (!$page->canviewall && $existing && usercontract_submission_is_locked($existing)) {
        redirect(
            $page->url_view(['tab' => 'form']),
            get_string('alreadysubmitted', 'usercontract'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }

    $rec = (object) [
        'usercontract' => $page->instance->id,
        'userid' => $USER->id,
        'data' => $payload,
        'timemodified' => $now,
        'verified' => 0,
        'verifiedby' => 0,
        'verifiedtime' => 0,
    ];
    if ($existing) {
        $rec->id = $existing->id;
        $rec->timecreated = $existing->timecreated;
        $DB->update_record('usercontract_submission', $rec);
    } else {
        $rec->timecreated = $now;
        $DB->insert_record('usercontract_submission', $rec);
    }

    usercontract_sync_completion_for_user($page->cm, $page->course, (int) $USER->id, false);

    redirect(
        $page->url_view(['saved' => 1, 'tab' => 'form']),
        get_string('contractsaved', 'usercontract'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($acceptform->is_submitted()) {
    $PAGE->set_title(format_string($page->instance->name));
    $PAGE->set_heading($page->course->fullname);
    $PAGE->set_pagelayout('incourse');
    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('formheading', 'usercontract'), 3);
    echo $OUTPUT->notification(get_string('formhaserrors', 'usercontract'), 'notifyproblem');
    $acceptform->display();
    echo $OUTPUT->footer();
    exit;
}

redirect($page->url_view(['tab' => 'form']));
