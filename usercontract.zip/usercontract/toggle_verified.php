<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_usercontract\local\view_page;

require_sesskey();

$id = required_param('id', PARAM_INT);
$targetuserid = required_param('userid', PARAM_INT);
$verified = optional_param('verified', 0, PARAM_INT);

$page = view_page::from_cm_id($id);

global $DB, $USER;

require_capability('mod/usercontract:viewall', $page->context);

$returnparams = usercontract_submissions_list_url_extra(
    optional_param('search', '', PARAM_TEXT),
    usercontract_normalize_verified_filter(optional_param('verifiedfilter', -1, PARAM_INT)),
    optional_param('page', 0, PARAM_INT),
    optional_param('sort', 'timemodified', PARAM_ALPHA),
    optional_param('sortdir', 'desc', PARAM_ALPHA)
);
$returnurl = new moodle_url('/mod/usercontract/view.php', usercontract_view_page_params($page->cm->id, $page->exportgroupid, $returnparams));

$sub = $DB->get_record('usercontract_submission', [
    'usercontract' => $page->instance->id,
    'userid' => $targetuserid,
], '*', IGNORE_MISSING);

if (!$sub) {
    redirect($returnurl, get_string('nosubmissiontodelete', 'usercontract'), null, \core\output\notification::NOTIFY_WARNING);
}

$wantverified = !empty($verified);
$complete = usercontract_submission_payload_is_complete($sub->data);

if ($wantverified && !$complete) {
    redirect($returnurl, get_string('verifiedrequirescomplete', 'usercontract'), null, \core\output\notification::NOTIFY_ERROR);
}

$now = time();
$sub->verified = $wantverified ? 1 : 0;
$sub->verifiedby = $wantverified ? (int) $USER->id : 0;
$sub->verifiedtime = $wantverified ? $now : 0;
$DB->update_record('usercontract_submission', $sub);

usercontract_sync_completion_for_user($page->cm, $page->course, $targetuserid, $wantverified);

$msg = $wantverified ? 'verifiedon' : 'verifiedoff';
redirect($returnurl, get_string($msg, 'usercontract'), null, \core\output\notification::NOTIFY_SUCCESS);
