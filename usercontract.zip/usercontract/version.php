<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_usercontract';
$plugin->version   = 2026102701;
$plugin->requires  = 2026100500; // Moodle 5.3.0+.
$plugin->supported = [503, 503];
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '5.3.0';
