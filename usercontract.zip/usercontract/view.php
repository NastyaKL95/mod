<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_usercontract\local\view_page;

$id = required_param('id', PARAM_INT);

$page = view_page::from_cm_id($id);

global $OUTPUT, $USER, $CFG, $PAGE;

$currenttab = $page->resolve_tab(optional_param('tab', '', PARAM_ALPHA));
$search = trim(optional_param('search', '', PARAM_TEXT));
$verifiedfilter = usercontract_normalize_verified_filter(optional_param('verifiedfilter', -1, PARAM_INT));
$sort = usercontract_normalize_submissions_sort(optional_param('sort', 'timemodified', PARAM_ALPHA));
$sortdir = usercontract_normalize_submissions_sortdir(optional_param('sortdir', 'desc', PARAM_ALPHA));
$pageindex = optional_param('page', 0, PARAM_INT);
$perpage = usercontract_submissions_per_page();
$justsaved = optional_param('saved', 0, PARAM_INT);

$urlopts = usercontract_submissions_list_url_extra($search, $verifiedfilter, $pageindex, $sort, $sortdir);
$urlopts['tab'] = $currenttab;
$page->set_page_url_view();
$PAGE->set_url($page->url_view($urlopts));

$ownsubmission = $page->get_own_submission();
$listenerlocked = $page->is_listener_locked();

$PAGE->set_title(format_string($page->instance->name));
$PAGE->set_heading($page->course->fullname);

if (method_exists($PAGE, 'set_secondary_active_tab')) {
    if ($page->canviewall && $page->cansubmit) {
        $PAGE->set_secondary_active_tab($currenttab === 'form' ? 'usercontractsubmissions' : 'modulepage');
    } else {
        $PAGE->set_secondary_active_tab('modulepage');
    }
}

echo $OUTPUT->header();

if ($page->has_multiple_tabs() && !method_exists($PAGE, 'set_secondary_active_tab')) {
    $tabs = [
        new tabobject('submissions', $page->url_view(['tab' => 'submissions']), get_string('tab_submissions', 'usercontract')),
        new tabobject('form', $page->url_view(['tab' => 'form']), get_string('tab_form', 'usercontract')),
    ];
    echo $OUTPUT->tabtree($tabs, $currenttab);
}

if ($currenttab === 'submissions' && $page->canviewall) {
    usercontract_accept_form_layout_init();
    echo $OUTPUT->heading(get_string('submissionsheading', 'usercontract'), 3, 'usercontract-submissions-heading');

    if (groups_get_activity_groupmode($page->cm, $page->course)) {
        echo html_writer::start_div('mb-2');
        groups_print_activity_menu($page->cm, $PAGE->url);
        echo html_writer::end_div();
    }

    usercontract_render_submissions_filter_block($page, $search, $verifiedfilter, $sort, $sortdir);
    usercontract_render_submissions_download_block($page);
    usercontract_render_bulk_export_panel($page);

    $total = $page->count_submissions($search, $verifiedfilter);
    if ($total === 0) {
        $msg = ($search !== '' || $verifiedfilter >= 0) ? 'nosubmissionsfilter' : 'nosubmissions';
        echo $OUTPUT->notification(get_string($msg, 'usercontract'), 'notifymessage');
    } else {
        $subs = $page->get_submissions_page($search, $pageindex, $perpage, $verifiedfilter, $sort, $sortdir);
        $table = new html_table();
        $table->head = [
            get_string('field_firstname', 'usercontract'),
            get_string('email'),
            get_string('field_phone', 'usercontract'),
            get_string('field_workplace', 'usercontract'),
            usercontract_submissions_sort_header($page, 'timemodified', get_string('lastmodified'), $search, $verifiedfilter, $sort, $sortdir),
            usercontract_submissions_sort_header($page, 'verified', get_string('verified', 'usercontract'), $search, $verifiedfilter, $sort, $sortdir),
            get_string('download'),
            get_string('deletesubmission', 'usercontract'),
        ];
        $table->attributes['class'] = 'generaltable';
        foreach ($subs as $s) {
            $name = usercontract_user_firstname($s);
            $dlurl = $page->url_download((int) $s->userid);
            $delurl = $page->url_delete((int) $s->userid);
            $isverified = usercontract_submission_is_verified($s);
            $iscomplete = usercontract_submission_payload_is_complete($s->data);
            $verifiedcell = html_writer::start_tag('form', [
                'method' => 'post',
                'action' => (new moodle_url('/mod/usercontract/toggle_verified.php'))->out(false),
                'class' => 'usercontract-verified-form',
                'style' => 'margin:0;',
            ]);
            $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
            $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $page->cm->id]);
            $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'userid', 'value' => (int) $s->userid]);
            $verifiedcell .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'verified',
                'value' => $isverified ? 1 : 0,
                'class' => 'usercontract-verified-value',
            ]);
            if ($search !== '') {
                $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'search', 'value' => s($search)]);
            }
            if ($verifiedfilter >= 0) {
                $verifiedcell .= html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'verifiedfilter',
                    'value' => $verifiedfilter,
                ]);
            }
            if ($pageindex > 0) {
                $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'page', 'value' => $pageindex]);
            }
            $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sort', 'value' => $sort]);
            $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sortdir', 'value' => $sortdir]);
            if ($page->exportgroupid > 0) {
                $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'group', 'value' => $page->exportgroupid]);
            }
            $cbattrs = [
                'type' => 'checkbox',
                'name' => 'verifiedtoggle',
                'value' => '1',
                'id' => 'verified-' . (int) $s->userid,
                'onchange' => 'var h=this.form.querySelector(".usercontract-verified-value");h.value=this.checked?1:0;this.form.submit();',
                'aria-label' => get_string('verified', 'usercontract') . ': ' . $name,
            ];
            if ($isverified) {
                $cbattrs['checked'] = 'checked';
            }
            if (!$iscomplete) {
                $cbattrs['disabled'] = 'disabled';
                $cbattrs['title'] = get_string('verifiedrequirescomplete', 'usercontract');
            }
            $verifiedcell .= html_writer::empty_tag('input', $cbattrs);
            $verifiedcell .= html_writer::tag('label', get_string('verified', 'usercontract'), [
                'for' => 'verified-' . (int) $s->userid,
                'class' => 'ms-1',
            ]);
            $verifiedcell .= html_writer::end_tag('form');
            $phone = usercontract_submission_display_phone($s);
            $workplace = usercontract_submission_display_workplace($s);
            $table->data[] = [
                $name,
                s($s->email),
                $phone !== '' ? s($phone) : '—',
                $workplace !== '' ? s($workplace) : '—',
                userdate($s->timemodified),
                $verifiedcell,
                html_writer::link($dlurl, get_string('downloadpdf', 'usercontract')),
                html_writer::link($delurl, get_string('deletesubmission', 'usercontract')),
            ];
        }
        echo html_writer::table($table);
        echo $OUTPUT->paging_bar(
            $total,
            $pageindex,
            $perpage,
            $page->url_view(usercontract_submissions_list_url_extra($search, $verifiedfilter, 0, $sort, $sortdir))
        );
    }

} else if ($currenttab === 'form' && $page->cansubmit) {
    echo $OUTPUT->heading(get_string('formheading', 'usercontract'), 3);

    $user = $USER;
    $learner = usercontract_get_learner_profile($user);
    $hasfirstname = usercontract_profile_has_firstname($learner);
    $profileurl = new moodle_url('/user/profile.php', ['id' => $user->id]);

    if (!$hasfirstname) {
        echo $OUTPUT->notification(get_string('profilenamerequired', 'usercontract'), 'notifyproblem');
        echo html_writer::div(
            html_writer::link($profileurl, get_string('editprofile', 'usercontract'), ['class' => 'btn btn-secondary']),
            'mb-3'
        );
    }

    if ($listenerlocked) {
        if ($justsaved) {
            echo $OUTPUT->box(get_string('contractsaved_detail', 'usercontract'), 'generalbox');
        } else {
            echo $OUTPUT->notification(get_string('contractsubmittedlocked', 'usercontract'), 'notifysuccess');
        }
        if ($ownsubmission && usercontract_submission_is_verified($ownsubmission)) {
            echo $OUTPUT->notification(get_string('contractverified', 'usercontract'), 'notifysuccess');
        } else if ($ownsubmission) {
            echo $OUTPUT->notification(get_string('completionrequiresverified', 'usercontract'), 'notifymessage');
        }
        $dlown = $page->url_download(0);
        $courseurl = course_get_url($page->course);
        echo html_writer::start_div('', ['style' => 'margin-top:0.75em;']);
        echo $OUTPUT->single_button($dlown, get_string('downloadpdf', 'usercontract'), 'get');
        echo ' ';
        echo $OUTPUT->single_button($courseurl, get_string('returntocourse', 'usercontract'), 'get');
        echo html_writer::end_div();
    } else if ($hasfirstname) {
        if (!usercontract_instance_has_visible_intro($page->instance)) {
            echo $OUTPUT->box(get_string('intro', 'usercontract'), 'generalbox mod_introbox', 'usercontractintro');
        }
        $acceptform = new \mod_usercontract\form\accept_form($page->url_submit(), ['learner' => $learner]);
        $formdefaults = (object) [
            'phone' => $learner->phone,
        ];
        $snap = $ownsubmission ? usercontract_submission_profile_snapshot($ownsubmission) : null;
        if ($snap) {
            if (!empty($snap->phone)) {
                $formdefaults->phone = $snap->phone;
            }
            if (isset($snap->workplace)) {
                $formdefaults->workplace = $snap->workplace;
            }
        }
        $acceptform->set_data($formdefaults);
        $acceptform->display();
    }

} else if (!$page->canviewall && !$page->cansubmit) {
    echo $OUTPUT->notification(get_string('noaccess', 'usercontract'), 'notifyproblem');
}

echo $OUTPUT->footer();
