<?php
// This file is part of Moodle - http://moodle.org/
// Используется только в Moodle 4.0+; в 3.8 — userstatement_get_completion_state() в lib.php.

declare(strict_types=1);

namespace mod_userstatement\completion;

use core_completion\activity_custom_completion;

defined('MOODLE_INTERNAL') || die();

/**
 * Правило завершения: заявление проверено руководителем.
 */
class custom_completion extends activity_custom_completion {

    /**
     * @param string $rule
     * @return int
     */
    public function get_state(string $rule): int {
        global $DB;

        $this->validate_rule($rule);

        $sub = $DB->get_record('userstatement_submission', [
            'userstatement' => $this->cm->instance,
            'userid' => $this->userid,
        ], 'verified', IGNORE_MISSING);

        if ($sub && userstatement_submission_is_verified($sub)) {
            return COMPLETION_COMPLETE;
        }
        return COMPLETION_INCOMPLETE;
    }

    /**
     * @return array
     */
    public static function get_defined_custom_rules(): array {
        return ['completionverified'];
    }

    /**
     * @return array
     */
    public function get_custom_rule_descriptions(): array {
        return [
            'completionverified' => get_string('completiondetail:verified', 'userstatement'),
        ];
    }

    /**
     * @return array
     */
    public function get_sort_order(): array {
        return [
            'completionverified',
        ];
    }
}
