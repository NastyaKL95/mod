<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\export;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->dirroot . '/mod/userstatement/lib.php');

/**
 * Реестр заявлений: все поля формы в одной таблице Excel.
 */
class fields_xlsx extends registry_xlsx {

    /** @var string */
    const SHEET_NAME = 'Реестр';

    /**
     * @param bool $includeusername
     * @return array<int, string>
     */
    public static function header_labels(bool $includeusername = false): array {
        $headers = [
            get_string('field_firstname', 'userstatement'),
            get_string('email'),
        ];
        if ($includeusername) {
            $headers[] = get_string('username');
        }
        return array_merge($headers, [
            get_string('field_birthdate', 'userstatement'),
            get_string('field_snils', 'userstatement'),
            get_string('field_gender', 'userstatement'),
            get_string('field_citizenship', 'userstatement'),
            get_string('field_edu_level', 'userstatement'),
            get_string('field_edu_institution', 'userstatement'),
            get_string('field_diploma_lastname', 'userstatement'),
            get_string('field_diploma_series', 'userstatement'),
            get_string('field_diploma_number', 'userstatement'),
            get_string('field_qualification', 'userstatement'),
            get_string('field_diploma_date', 'userstatement'),
            get_string('field_workplace', 'userstatement'),
            get_string('field_position', 'userstatement'),
            get_string('field_experience_position', 'userstatement'),
            get_string('field_pedagogical_experience', 'userstatement'),
            get_string('field_subjects', 'userstatement'),
            get_string('field_degree_title', 'userstatement'),
            get_string('field_phone', 'userstatement'),
            get_string('verified', 'userstatement'),
            get_string('lastmodified'),
        ]);
    }

    /**
     * @param \stdClass $course
     * @param array<int, \stdClass> $submissions
     * @param bool $includeusername
     * @return string
     */
    public static function generate_bytes(\stdClass $course, array $submissions, bool $includeusername = false) {
        $rows = [self::header_labels($includeusername)];
        foreach ($submissions as $sub) {
            $data = json_decode($sub->data);
            if (is_array($data)) {
                $data = (object) $data;
            }
            if (!is_object($data)) {
                $data = new \stdClass();
            }
            $user = \core_user::get_user((int) $sub->userid, '*', IGNORE_MISSING);
            if (!$user) {
                continue;
            }
            $rows[] = self::data_row($user, $data, $sub, $includeusername);
        }

        return self::pack_workbook($rows, self::SHEET_NAME, get_string('exportdoctitle_reestr', 'userstatement'));
    }

    /**
     * @param \stdClass $course
     * @param array<int, \stdClass> $submissions
     * @param bool $includeusername
     */
    public static function send_download(\stdClass $course, array $submissions, bool $includeusername = false) {
        if (!class_exists('ZipArchive')) {
            throw new \moodle_exception('noziparchive', 'userstatement');
        }

        while (ob_get_level()) {
            ob_end_clean();
        }

        $zipdata = self::generate_bytes($course, $submissions, $includeusername);

        $fname = 'reestr_' . clean_filename(format_string($course->shortname, true)) . '_'
            . userdate(time(), '%Y%m%d%H%M', 99, false) . '.xlsx';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fname . '"');
        header('Content-Length: ' . strlen($zipdata));
        header('Cache-Control: private, must-revalidate, pre-check=0, post-check=0, max-age=0');
        echo $zipdata;
        exit;
    }

    /**
     * @param \stdClass $user
     * @param \stdClass $data
     * @param \stdClass $submission
     * @param bool $includeusername
     * @return array<int, string>
     */
    public static function data_row(\stdClass $user, \stdClass $data, \stdClass $submission, bool $includeusername = false): array {
        $gender = '';
        if (($data->gender ?? '') === 'female') {
            $gender = get_string('gender_female', 'userstatement');
        } else if (($data->gender ?? '') === 'male') {
            $gender = get_string('gender_male', 'userstatement');
        }

        $verified = userstatement_submission_is_verified($submission)
            ? get_string('yes')
            : get_string('no');

        $row = [
            userstatement_user_firstname($user),
            trim((string) $user->email),
        ];
        if ($includeusername) {
            $row[] = trim((string) $user->username);
        }
        return array_merge($row, [
            self::format_date_cell($data->birthdate ?? null),
            userstatement_format_snils_display($data->snils ?? ''),
            $gender,
            trim((string) ($data->citizenship ?? '')),
            trim((string) ($data->edu_level ?? '')),
            trim((string) ($data->edu_institution ?? '')),
            trim((string) ($data->diploma_lastname ?? '')),
            trim((string) ($data->diploma_series ?? '')),
            trim((string) ($data->diploma_number ?? '')),
            trim((string) ($data->qualification ?? '')),
            self::format_date_cell($data->diploma_date ?? null),
            trim((string) ($data->workplace ?? '')),
            trim((string) ($data->position ?? '')),
            trim((string) ($data->experience_position ?? '')),
            trim((string) ($data->pedagogical_experience ?? '')),
            trim((string) ($data->subjects ?? '')),
            trim((string) ($data->degree_title ?? '')),
            userstatement_submission_display_phone($submission->data),
            $verified,
            userdate($submission->timemodified),
        ]);
    }
}
