<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\export;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->dirroot . '/mod/userstatement/lib.php');

/**
 * Выгрузка для ФИС ФРДО в формате XLSX (структура как в шаблоне report_*.xlsx).
 */
class registry_xlsx {

    /** @var string Имя листа и заголовок документа для ФИС ФРДО. */
    const FIS_SHEET_NAME = 'ФИС ФРДО';

    /** @var array<int, string> Заголовки колонок A–AN (ровно как в шаблоне). */
    const HEADERS = [
        'Вид документа',
        'Статус документа',
        'Подтверждение утраты',
        'Подтверждение обмена',
        'Подтверждение уничтожения',
        'Серия документа',
        'Номер документа',
        'Дата выдачи документа',
        'Регистрационный номер',
        'Дополнительная профессиональная программа (повышение квалификации/ профессиональная переподготовка)',
        'Наименование дополнительной профессиональной программы',
        'Наименование области профессиональной деятельности',
        'Укрупненные группы специальностей',
        'Наименование квалификации, профессии, специальности',
        'Уровень образования ВО/СПО',
        'Фамилия указанная в дипломе о ВО или СПО',
        'Серия документа о ВО/СПО',
        'Номер документа о ВО/СПО',
        'Год начала обучения (для документа о квалификации)',
        'Год окончания обучения (для документа о квалификации)',
        'Срок обучения, часов (для документа о квалификации)',
        'Фамилия получателя',
        'Имя получателя',
        'Отчество получателя',
        'Дата рождения получателя',
        'Пол получателя',
        'СНИЛС',
        'Форма обучения',
        'Источник финансирования обучения',
        'Форма получения образования на момент прекращения образовательных отношений',
        'Гражданство получателя (код страны по ОКСМ)',
        'Наименование документа об образовании (оригинала)',
        'Серия (оригинала)',
        'Номер (оригинала)',
        'Регистрационный N (оригинала)',
        'Дата выдачи (оригинала)',
        'Фамилия получателя (оригинала)',
        'Имя получателя (оригинала)',
        'Отчество получателя (оригинала)',
        'Номер документа для изменения',
    ];

    /**
     * Сформировать XLSX в память (байты).
     *
     * @param \stdClass $course
     * @param array<int, \stdClass> $submissions
     * @return string
     */
    public static function generate_bytes(\stdClass $course, array $submissions) {
        $rows = [self::HEADERS];
        foreach ($submissions as $sub) {
            $data = json_decode($sub->data);
            if (is_array($data)) {
                $data = (object) $data;
            }
            if (!is_object($data)) {
                continue;
            }
            $user = \core_user::get_user((int) $sub->userid, '*', IGNORE_MISSING);
            if (!$user) {
                continue;
            }
            $rows[] = self::data_row($course, $user, $data);
        }

        return self::pack_workbook($rows, self::FIS_SHEET_NAME, self::FIS_SHEET_NAME);
    }

    /**
     * Собрать XLSX из строк (заголовок + данные).
     *
     * @param array<int, array<int, string>> $rows
     * @param string $sheetname
     * @param string $doctitle
     * @return string
     */
    public static function pack_workbook(array $rows, string $sheetname, string $doctitle) {
        $xml = self::build_sheet_xml($rows);
        return self::build_xlsx_zip($xml, $sheetname, $doctitle);
    }

    /**
     * Отправка XLSX в браузер.
     *
     * @param \stdClass $course
     * @param array<int, \stdClass> $submissions
     */
    public static function send_download(\stdClass $course, array $submissions) {
        if (!class_exists('ZipArchive')) {
            throw new \moodle_exception('noziparchive', 'userstatement');
        }

        while (ob_get_level()) {
            ob_end_clean();
        }

        $zipdata = self::generate_bytes($course, $submissions);

        $fname = 'fis_frdo_' . clean_filename(format_string($course->shortname, true)) . '_'
            . userdate(time(), '%Y%m%d%H%M', 99, false) . '.xlsx';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $fname . '"');
        header('Content-Length: ' . strlen($zipdata));
        header('Cache-Control: private, must-revalidate, pre-check=0, post-check=0, max-age=0');
        echo $zipdata;
        exit;
    }

    /**
     * Одна строка данных (40 ячеек).
     *
     * @param \stdClass $course
     * @param \stdClass $user
     * @param \stdClass $data
     * @return array<int, string>
     */
    public static function data_row(\stdClass $course, \stdClass $user, \stdClass $data) {

        $program = trim(format_string($course->fullname));
        $diplomats = self::format_date_cell($data->diploma_date ?? null);
        $diplomay = self::year_from_value($data->diploma_date ?? null);
        $births = self::format_date_cell($data->birthdate ?? null);
        $gender = self::gender_ru($data->gender ?? '');
        $snilsmasked = userstatement_format_snils_display($data->snils ?? '');
        $cit = self::citizenship_oksm_code($data->citizenship ?? '');

        $patronymic = '';
        if (!empty($user->middlename)) {
            $patronymic = trim($user->middlename);
        } else if (!empty($user->alternatename)) {
            $patronymic = trim($user->alternatename);
        }

        $row = array_fill(0, 40, '');
        $row[9] = 'Повышение квалификации';
        $row[10] = $program;
        $row[13] = trim((string) ($data->qualification ?? ''));
        $row[14] = trim((string) ($data->edu_level ?? ''));
        $row[15] = trim((string) ($data->diploma_lastname ?? ''));
        $row[16] = trim((string) ($data->diploma_series ?? ''));
        $row[17] = trim((string) ($data->diploma_number ?? ''));
        $row[19] = $diplomay;
        $row[21] = trim((string) ($user->lastname ?? ''));
        $row[22] = trim((string) ($user->firstname ?? ''));
        $row[23] = $patronymic;
        $row[24] = $births;
        $row[25] = $gender;
        $row[26] = $snilsmasked;
        $row[30] = $cit;
        $row[7] = $diplomats;
        $row[35] = $diplomats;

        return $row;
    }

    /**
     * @param mixed $gender
     * @return string
     */
    /**
     * Код страны по ОКСМ для колонки «Гражданство» (шаблон ФИС ФРДО).
     *
     * @param mixed $raw
     * @return string
     */
    protected static function citizenship_oksm_code($raw) {
        $s = trim((string) $raw);
        if ($s === '') {
            return '';
        }
        if (preg_match('/^\d{3}$/', $s)) {
            return $s;
        }
        $lower = mb_strtolower($s, 'UTF-8');
        if ($lower === 'рф' || $lower === 'россия' || $lower === 'российская федерация'
            || strpos($lower, 'росси') === 0) {
            return '643';
        }
        return $s;
    }

    /**
     * @param mixed $gender
     * @return string
     */
    protected static function gender_ru($gender) {
        if ($gender === 'female') {
            return 'Жен';
        }
        if ($gender === 'male') {
            return 'Муж';
        }
        return '';
    }

    /**
     * @param mixed $value
     * @return string
     */
    protected static function year_from_value($value) {
        $parts = userstatement_date_parts($value);
        return $parts ? (string) $parts['year'] : '';
    }

    /**
     * @param mixed $value
     * @return string d.m.Y
     */
    protected static function format_date_cell($value) {
        return userstatement_date_format_display($value);
    }

    /**
     * @param mixed $value
     * @return int
     * @deprecated use userstatement_date_parts()
     */
    protected static function value_to_timestamp($value) {
        if ($value === null || $value === '' || $value === 0) {
            return 0;
        }
        if (is_numeric($value)) {
            return (int) $value;
        }
        if (is_array($value)) {
            $d = (int) ($value['day'] ?? 0);
            $m = (int) ($value['month'] ?? 0);
            $y = (int) ($value['year'] ?? 0);
            if ($d < 1 || $m < 1 || $y < 1) {
                return 0;
            }
            return make_timestamp($y, $m, $d, 12, 0, 0);
        }
        if (is_object($value)) {
            $d = (int) ($value->day ?? 0);
            $m = (int) ($value->month ?? 0);
            $y = (int) ($value->year ?? 0);
            if ($d < 1 || $m < 1 || $y < 1) {
                return 0;
            }
            return make_timestamp($y, $m, $d, 12, 0, 0);
        }
        return 0;
    }

    /**
     * @param int $index 0-based
     * @return string
     */
    protected static function col_letter($index) {
        $letters = '';
        $i = $index;
        while ($i >= 0) {
            $letters = chr(65 + ($i % 26)) . $letters;
            $i = intdiv($i, 26) - 1;
        }
        return $letters;
    }

    /**
     * @param string $s
     * @return string
     */
    protected static function xml_escape($s) {
        return htmlspecialchars((string) $s, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }

    /**
     * @param array<int, array<int, string>> $rows
     * @return string
     */
    protected static function build_sheet_xml(array $rows) {
        $nrows = count($rows);
        $ncol = 1;
        foreach ($rows as $row) {
            $ncol = max($ncol, count($row));
        }
        $lastcol = self::col_letter($ncol - 1);
        $dim = 'A1:' . $lastcol . $nrows;

        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
        $xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ';
        $xml .= 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
        $xml .= '<dimension ref="' . self::xml_escape($dim) . '"/>';
        $xml .= '<sheetViews><sheetView workbookViewId="0"/></sheetViews>';
        $xml .= '<sheetFormatPr defaultRowHeight="15"/>';
        $xml .= '<sheetData>';

        $r = 0;
        foreach ($rows as $row) {
            $r++;
            $xml .= '<row r="' . $r . '">';
            for ($c = 0; $c < $ncol; $c++) {
                $cell = self::col_letter($c) . $r;
                $val = isset($row[$c]) ? (string) $row[$c] : '';
                if ($val === '') {
                    $xml .= '<c r="' . $cell . '"/>';
                } else {
                    $xml .= '<c r="' . $cell . '" t="inlineStr"><is><t>' . self::xml_escape($val) . '</t></is></c>';
                }
            }
            $xml .= '</row>';
        }

        $xml .= '</sheetData></worksheet>';
        return $xml;
    }

    /**
     * @param string $sheetxml
     * @return string binary
     */
    protected static function build_xlsx_zip($sheetxml, string $sheetname, string $doctitle) {
        global $CFG;

        $dir = make_temp_directory('userstatement');
        $tmp = $dir . '/reg_' . sha1(uniqid((string) mt_rand(), true)) . '.xlsx';

        $zip = new \ZipArchive();
        if ($zip->open($tmp, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \moodle_exception('exportwritefailed', 'userstatement');
        }

        $zip->addFromString('[Content_Types].xml', self::content_types());
        $zip->addFromString('_rels/.rels', self::rels_root());
        $zip->addFromString('docProps/app.xml', self::doc_app());
        $zip->addFromString('docProps/core.xml', self::doc_core($doctitle));
        $zip->addFromString('xl/workbook.xml', self::workbook($sheetname));
        $zip->addFromString('xl/_rels/workbook.xml.rels', self::workbook_rels());
        $zip->addFromString('xl/styles.xml', self::styles());
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheetxml);

        $zip->close();
        $bin = file_get_contents($tmp);
        @unlink($tmp);
        return $bin;
    }

    /**
     * @return string
     */
    protected static function content_types() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" '
            . 'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" '
            . 'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" '
            . 'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '<Override PartName="/docProps/core.xml" '
            . 'ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            . '<Override PartName="/docProps/app.xml" '
            . 'ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            . '</Types>';
    }

    /**
     * @return string
     */
    protected static function rels_root() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
            . 'Target="xl/workbook.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" '
            . 'Target="docProps/core.xml"/>'
            . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" '
            . 'Target="docProps/app.xml"/>'
            . '</Relationships>';
    }

    /**
     * @return string
     */
    protected static function workbook(string $sheetname) {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="' . self::xml_escape($sheetname) . '" sheetId="1" r:id="rId1"/></sheets></workbook>';
    }

    /**
     * @return string
     */
    protected static function workbook_rels() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
            . 'Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
            . 'Target="styles.xml"/>'
            . '</Relationships>';
    }

    /**
     * @return string
     */
    protected static function styles() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>'
            . '<fills count="1"><fill><patternFill patternType="none"/></fill></fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>'
            . '</styleSheet>';
    }

    /**
     * @return string
     */
    protected static function doc_app() {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
            . '<Application>Moodle mod_userstatement</Application></Properties>';
    }

    /**
     * @return string
     */
    protected static function doc_core(string $title) {
        $t = gmdate('c');
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            . 'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            . 'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            . '<dc:title>' . self::xml_escape($title) . '</dc:title>'
            . '<dcterms:created xsi:type="dcterms:W3CDTF">' . $t . '</dcterms:created>'
            . '</cp:coreProperties>';
    }
}
