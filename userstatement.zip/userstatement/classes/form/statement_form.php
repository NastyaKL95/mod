<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\form;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/formslib.php');

/**
 * Форма заявления (в контексте модуля курса).
 */
class statement_form extends \moodleform {

    /**
     * Описание полей формы.
     */
    public function definition() {
        $mform = $this->_form;
        $user = $this->_customdata['user'];

        $mform->updateAttributes(['class' => 'mform userstatement-statement-form']);

        $mform->addElement('static', 'userfirstname', get_string('field_firstname', 'userstatement'),
            s(userstatement_user_firstname($user)));
        $mform->addElement('static', 'useremail', get_string('email'), s($user->email));

        $mform->addElement('header', 'hdr_personal', get_string('section_personal', 'userstatement'));

        [$birthstart, $birthstop] = userstatement_birthdate_year_range();
        userstatement_form_add_date_group(
            $mform,
            'birthdate',
            get_string('field_birthdate', 'userstatement'),
            $birthstart,
            $birthstop
        );
        $mform->addElement('static', 'birthdate_hint', '',
            \html_writer::div(get_string('field_birthdate_help', 'userstatement'), 'userstatement-date-hint'));

        $mform->addElement('text', 'snils', get_string('field_snils', 'userstatement'),
            userstatement_statement_text_attrs(['userstatement-snils', 'userstatement-validated-text'], [
                'title' => get_string('snils_mask_title', 'userstatement'),
                'spellcheck' => 'false',
                'inputmode' => 'numeric',
                'autocomplete' => 'off',
            ]));
        $mform->setType('snils', PARAM_TEXT);
        $mform->addRule('snils', get_string('fieldempty', 'userstatement'), 'required', null, 'client');
        $mform->addRule('snils', get_string('fieldempty', 'userstatement'), 'required', null, 'server');

        $genderchoices = [
            'female' => get_string('gender_female', 'userstatement'),
            'male' => get_string('gender_male', 'userstatement'),
        ];
        $mform->addElement('select', 'gender', get_string('field_gender', 'userstatement'), $genderchoices, [
            'class' => 'userstatement-field-full',
        ]);

        $lettersattrs = ['userstatement-validated-text', 'userstatement-letters-only'];
        $letterscommaattrs = ['userstatement-validated-text', 'userstatement-letters-comma'];
        $textattrs = ['userstatement-validated-text'];
        $fieldempty = get_string('fieldempty', 'userstatement');

        $mform->addElement('text', 'citizenship', get_string('field_citizenship', 'userstatement'),
            userstatement_statement_text_attrs($lettersattrs));
        $mform->setType('citizenship', PARAM_TEXT);

        $mform->addElement('header', 'hdr_edu', get_string('section_education', 'userstatement'));

        $mform->addElement('text', 'edu_level', get_string('field_edu_level', 'userstatement'),
            userstatement_statement_text_attrs($lettersattrs));
        $mform->setType('edu_level', PARAM_TEXT);

        $mform->addElement('textarea', 'edu_institution', get_string('field_edu_institution', 'userstatement'),
            userstatement_statement_textarea_attrs($textattrs));
        $mform->setType('edu_institution', PARAM_TEXT);

        $mform->addElement('text', 'diploma_lastname', get_string('field_diploma_lastname', 'userstatement'),
            userstatement_statement_text_attrs($lettersattrs));
        $mform->setType('diploma_lastname', PARAM_TEXT);

        $mform->addElement('text', 'diploma_series', get_string('field_diploma_series', 'userstatement'),
            userstatement_statement_text_attrs($textattrs, ['maxlength' => 64]));
        $mform->setType('diploma_series', PARAM_TEXT);

        $mform->addElement('text', 'diploma_number', get_string('field_diploma_number', 'userstatement'),
            userstatement_statement_text_attrs($textattrs, ['maxlength' => 64]));
        $mform->setType('diploma_number', PARAM_TEXT);

        $mform->addElement('text', 'qualification', get_string('field_qualification', 'userstatement'),
            userstatement_statement_text_attrs($textattrs));
        $mform->setType('qualification', PARAM_TEXT);

        [$diplomastart, $diplomastop] = userstatement_diploma_date_year_range();
        userstatement_form_add_date_group(
            $mform,
            'diploma_date',
            get_string('field_diploma_date', 'userstatement'),
            $diplomastart,
            $diplomastop
        );
        $mform->addElement('static', 'diploma_date_hint', '',
            \html_writer::div(get_string('field_diploma_date_help', 'userstatement'), 'userstatement-date-hint'));

        $mform->addElement('header', 'hdr_work', get_string('section_work', 'userstatement'));

        $mform->addElement('textarea', 'workplace', get_string('field_workplace', 'userstatement'),
            userstatement_statement_textarea_attrs($textattrs));
        $mform->setType('workplace', PARAM_TEXT);

        $mform->addElement('text', 'position', get_string('field_position', 'userstatement'),
            userstatement_statement_text_attrs($letterscommaattrs));
        $mform->setType('position', PARAM_TEXT);

        $mform->addElement('text', 'experience_position', get_string('field_experience_position', 'userstatement'),
            userstatement_statement_text_attrs($textattrs));
        $mform->setType('experience_position', PARAM_TEXT);

        $mform->addElement('text', 'pedagogical_experience', get_string('field_pedagogical_experience', 'userstatement'),
            userstatement_statement_text_attrs($textattrs));
        $mform->setType('pedagogical_experience', PARAM_TEXT);

        $mform->addElement('textarea', 'subjects', get_string('field_subjects', 'userstatement'),
            userstatement_statement_textarea_attrs($letterscommaattrs));
        $mform->setType('subjects', PARAM_TEXT);

        $mform->addElement('text', 'degree_title', get_string('field_degree_title', 'userstatement'),
            userstatement_statement_text_attrs($textattrs));
        $mform->setType('degree_title', PARAM_TEXT);

        $mform->addElement('text', 'phone', get_string('field_phone', 'userstatement'),
            userstatement_statement_text_attrs(['userstatement-phone', 'userstatement-validated-text'], [
                'title' => get_string('phone_mask_title', 'userstatement'),
                'spellcheck' => 'false',
                'inputmode' => 'tel',
                'autocomplete' => 'tel',
            ]));
        $mform->setType('phone', PARAM_TEXT);
        $mform->addRule('phone', $fieldempty, 'required', null, 'client');
        $mform->addRule('phone', $fieldempty, 'required', null, 'server');

        foreach (userstatement_required_text_fields() as $fieldname) {
            if ($fieldname === 'snils' || $fieldname === 'phone') {
                continue;
            }
            $mform->addRule($fieldname, $fieldempty, 'required', null, 'client');
            $mform->addRule($fieldname, $fieldempty, 'required', null, 'server');
        }

        $mform->addElement('header', 'hdr_confirm', get_string('confirmaccuracy', 'userstatement'));
        $mform->addElement('checkbox', 'confirmaccuracy', '', get_string('confirmaccuracy', 'userstatement'));
        $mform->setType('confirmaccuracy', PARAM_INT);

        $this->add_action_buttons(false, get_string('saveanddownload', 'userstatement'));

        global $PAGE;
        if ($PAGE) {
            userstatement_statement_form_layout_init();
            userstatement_snils_mask_init();
            userstatement_phone_mask_init();
            userstatement_text_fields_blur_validation_init();
            userstatement_date_fields_validation_init();
        }
    }

    /**
     * Подстановка масок при загрузке сохранённых данных.
     *
     * @param mixed $default_values
     */
    public function set_data($default_values) {
        if (is_object($default_values) && property_exists($default_values, 'gender')) {
            if (!in_array($default_values->gender ?? '', ['female', 'male'], true)) {
                $default_values->gender = 'female';
            }
        } else if (is_array($default_values) && array_key_exists('gender', $default_values)) {
            if (!in_array($default_values['gender'] ?? '', ['female', 'male'], true)) {
                $default_values['gender'] = 'female';
            }
        }
        if (is_object($default_values) && property_exists($default_values, 'snils')) {
            $digits = userstatement_normalize_snils_digits($default_values->snils);
            if (strlen($digits) === 11) {
                $default_values->snils = userstatement_format_snils_masked($digits);
            }
        } else if (is_array($default_values) && array_key_exists('snils', $default_values)) {
            $digits = userstatement_normalize_snils_digits($default_values['snils'] ?? '');
            if (strlen($digits) === 11) {
                $default_values['snils'] = userstatement_format_snils_masked($digits);
            }
        }
        if (is_object($default_values) && property_exists($default_values, 'phone')) {
            $pdigits = userstatement_normalize_phone_digits($default_values->phone);
            if (userstatement_phone_digits_valid($pdigits)) {
                $default_values->phone = userstatement_format_phone_masked($pdigits);
            }
        } else if (is_array($default_values) && array_key_exists('phone', $default_values)) {
            $pdigits = userstatement_normalize_phone_digits($default_values['phone'] ?? '');
            if (userstatement_phone_digits_valid($pdigits)) {
                $default_values['phone'] = userstatement_format_phone_masked($pdigits);
            }
        }
        foreach (userstatement_required_date_fields() as $field) {
            if (is_object($default_values)) {
                $source = property_exists($default_values, $field) ? $default_values->$field : null;
                $default_values->$field = userstatement_date_to_form_group_value($source, $field);
            } else if (is_array($default_values)) {
                $source = array_key_exists($field, $default_values) ? $default_values[$field] : null;
                $default_values[$field] = userstatement_date_to_form_group_value($source, $field);
            }
        }
        parent::set_data($default_values);
    }

    /**
     * @return \stdClass|false
     */
    public function get_data() {
        $data = parent::get_data();
        if ($data && property_exists($data, 'snils')) {
            $data->snils = userstatement_normalize_snils_digits($data->snils);
        }
        if ($data && property_exists($data, 'phone')) {
            $data->phone = userstatement_normalize_phone_digits($data->phone);
        }
        foreach (userstatement_required_date_fields() as $field) {
            if ($data && property_exists($data, $field)) {
                $stored = userstatement_form_date_to_storage($data->$field, $field);
                if ($stored !== null) {
                    $data->$field = $stored;
                }
            }
        }
        return $data;
    }

    /**
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        return $errors + userstatement_form_validation_errors($data);
    }
}
