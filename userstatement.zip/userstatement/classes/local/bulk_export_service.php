<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\local;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->dirroot . '/mod/userstatement/lib.php');

/**
 * Полная выгрузка PDF по шагам в браузере (без cron).
 */
class bulk_export_service {

    public const STATUS_PENDING = 'pending';
    public const STATUS_PROCESSING = 'processing';
    public const STATUS_COMPLETE = 'complete';
    public const STATUS_FAILED = 'failed';

    public const FILEAREA = 'bulkexport';

    public static function sync_zip_limit(): int {
        return userstatement_zip_pdf_limit();
    }

    public static function chunk_size(): int {
        return 100;
    }

    /**
     * Создать задание выгрузки (обработка — на export_bulk_run.php).
     *
     * @param int $instanceid
     * @param int $userid
     * @param int $groupid
     * @return int
     */
    public static function create_job(int $instanceid, int $userid, int $groupid): int {
        global $DB;

        if ($DB->record_exists_select(
            'userstatement_export',
            'userstatement = ? AND requestedby = ? AND status IN (?, ?)',
            [$instanceid, $userid, self::STATUS_PENDING, self::STATUS_PROCESSING]
        )) {
            throw new \moodle_exception('bulkexportalreadyrunning', 'userstatement');
        }

        self::cleanup_old_exports($instanceid);

        $now = time();
        return (int) $DB->insert_record('userstatement_export', (object) [
            'userstatement' => $instanceid,
            'requestedby' => $userid,
            'groupid' => $groupid,
            'status' => self::STATUS_PENDING,
            'partcount' => 0,
            'pdfcount' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
        ]);
    }

    /**
     * Один шаг: одна ZIP-часть (до chunk_size PDF). Вызывается из браузера многократно.
     *
     * @param int $exportid
     * @return \stdClass complete, failed, message, processed, total, parts, percent
     */
    public static function process_next_step(int $exportid): \stdClass {
        global $DB;

        @ignore_user_abort(true);
        userstatement_raise_export_limits();

        $result = (object) [
            'complete' => false,
            'failed' => false,
            'message' => '',
            'processed' => 0,
            'total' => 0,
            'parts' => 0,
            'percent' => 0,
        ];

        $export = $DB->get_record('userstatement_export', ['id' => $exportid], '*', MUST_EXIST);

        if ($export->status === self::STATUS_COMPLETE) {
            $result->complete = true;
            $result->processed = (int) $export->pdfcount;
            $result->total = (int) $export->pdfcount;
            $result->parts = (int) $export->partcount;
            $result->percent = 100;
            return $result;
        }
        if ($export->status === self::STATUS_FAILED) {
            $result->failed = true;
            $result->message = (string) ($export->errormsg ?? '');
            return $result;
        }

        if (!class_exists('ZipArchive')) {
            self::fail($exportid, get_string('noziparchive', 'userstatement'));
            return self::process_next_step($exportid);
        }

        $instance = $DB->get_record('userstatement', ['id' => $export->userstatement], '*', MUST_EXIST);
        $cm = get_coursemodule_from_instance('userstatement', $instance->id, 0, false, MUST_EXIST);
        $course = get_course($cm->course);
        $context = \context_module::instance($cm->id);

        try {
            if ($export->status === self::STATUS_PENDING) {
                self::initialize_job($exportid, $export, $instance, $context);
                $export = $DB->get_record('userstatement_export', ['id' => $exportid], '*', MUST_EXIST);
            }

            $state = self::decode_state($export->statedata);
            $total = count($state->validids);
            $result->total = $total;
            $result->processed = min((int) $state->nextindex, $total);
            $result->parts = (int) $export->partcount;

            if ($total === 0) {
                self::fail($exportid, get_string('bulkexportnopdfs', 'userstatement'));
                return self::process_next_step($exportid);
            }

            if ($state->nextindex >= $total) {
                self::finalize_job($exportid, $export, $instance, $cm, $course, $context);
                return self::process_next_step($exportid);
            }

            $chunksize = self::chunk_size();
            $sliceids = array_slice($state->validids, $state->nextindex, $chunksize);
            $chunk = self::load_submissions_chunk($sliceids, $instance->id);

            $registrybytes = null;
            if (!$state->registrydone) {
                $allsubs = self::load_submissions_chunk($state->allids, $instance->id);
                $registrybytes = \mod_userstatement\export\registry_xlsx::generate_bytes($course, $allsubs);
                $state->registrydone = true;
            }

            $partnum = (int) $export->partcount + 1;
            $tmppath = self::build_part_zip($instance, $course, $chunk, $registrybytes, $partnum === 1 && $registrybytes !== null);
            unset($registrybytes);

            $courseshort = clean_filename(format_string($course->shortname, true));
            $filename = 'zayavleniya_' . $courseshort . '_part' . sprintf('%02d', $partnum) . '.zip';
            $fs = get_file_storage();
            if ($partnum === 1) {
                $fs->delete_area_files($context->id, 'mod_userstatement', self::FILEAREA, $exportid);
            }
            $fs->create_file_from_pathname([
                'contextid' => $context->id,
                'component' => 'mod_userstatement',
                'filearea' => self::FILEAREA,
                'itemid' => $exportid,
                'filepath' => '/',
                'filename' => $filename,
            ], $tmppath);
            @unlink($tmppath);

            $state->nextindex += count($sliceids);
            $pdfcount = (int) $export->pdfcount + count($sliceids);

            $DB->update_record('userstatement_export', (object) [
                'id' => $exportid,
                'status' => self::STATUS_PROCESSING,
                'partcount' => $partnum,
                'pdfcount' => $pdfcount,
                'statedata' => self::encode_state($state),
                'timemodified' => time(),
            ]);

            $result->processed = $state->nextindex;
            $result->parts = $partnum;
            $result->percent = $total > 0 ? round(100 * $state->nextindex / $total) : 0;

            if ($state->nextindex >= $total) {
                self::finalize_job($exportid, $export, $instance, $cm, $course, $context);
                return self::process_next_step($exportid);
            }

            return $result;
        } catch (\Throwable $e) {
            self::fail($exportid, $e->getMessage());
            return self::process_next_step($exportid);
        }
    }

    /** @deprecated cron; loops steps */
    public static function run(int $exportid): void {
        while (true) {
            $r = self::process_next_step($exportid);
            if ($r->complete || $r->failed) {
                break;
            }
        }
    }

    public static function create_and_queue(int $instanceid, int $userid, int $groupid): int {
        return self::create_job($instanceid, $userid, $groupid);
    }

    public static function list_recent(int $instanceid, int $limit = 8): array {
        global $DB;
        return $DB->get_records(
            'userstatement_export',
            ['userstatement' => $instanceid],
            'timecreated DESC',
            '*',
            0,
            $limit
        );
    }

    public static function part_download_url(\stdClass $export, \context_module $context, int $part): ?\moodle_url {
        if ($export->status !== self::STATUS_COMPLETE || $part < 1 || $part > (int) $export->partcount) {
            return null;
        }
        $fs = get_file_storage();
        $files = $fs->get_area_files($context->id, 'mod_userstatement', self::FILEAREA, $export->id, 'filename', false);
        $index = 0;
        foreach ($files as $file) {
            $index++;
            if ($index === $part) {
                return \moodle_url::make_pluginfile_url(
                    $context->id,
                    'mod_userstatement',
                    self::FILEAREA,
                    $export->id,
                    $file->get_filepath(),
                    $file->get_filename(),
                    true
                );
            }
        }
        return null;
    }

    protected static function initialize_job(
        int $exportid,
        \stdClass $export,
        \stdClass $instance,
        \context_module $context
    ): void {
        global $DB;

        $subs = self::fetch_submissions($instance->id, (int) $export->groupid);
        $valid = self::filter_valid_submissions($subs);
        $validids = [];
        foreach ($valid as $sub) {
            $validids[] = (int) $sub->id;
        }

        $state = (object) [
            'validids' => $validids,
            'allids' => array_map('intval', array_keys($subs)),
            'nextindex' => 0,
            'registrydone' => false,
        ];

        $DB->update_record('userstatement_export', (object) [
            'id' => $exportid,
            'status' => self::STATUS_PROCESSING,
            'statedata' => self::encode_state($state),
            'timemodified' => time(),
        ]);
    }

    protected static function finalize_job(
        int $exportid,
        \stdClass $export,
        \stdClass $instance,
        \stdClass $cm,
        \stdClass $course,
        \context_module $context
    ): void {
        global $DB;

        $export = $DB->get_record('userstatement_export', ['id' => $exportid], '*', MUST_EXIST);
        $DB->update_record('userstatement_export', (object) [
            'id' => $exportid,
            'status' => self::STATUS_COMPLETE,
            'timemodified' => time(),
            'statedata' => null,
            'errormsg' => null,
        ]);
        $export = $DB->get_record('userstatement_export', ['id' => $exportid], '*', MUST_EXIST);
        self::notify_ready($export, $instance, $cm, $course, $context);
    }

    protected static function encode_state(\stdClass $state): string {
        return json_encode($state);
    }

    protected static function decode_state(?string $raw): \stdClass {
        $state = json_decode($raw ?? '');
        if (!is_object($state)) {
            $state = (object) [];
        }
        if (empty($state->validids) || !is_array($state->validids)) {
            $state->validids = [];
        }
        if (empty($state->allids) || !is_array($state->allids)) {
            $state->allids = [];
        }
        $state->nextindex = isset($state->nextindex) ? (int) $state->nextindex : 0;
        $state->registrydone = !empty($state->registrydone);
        return $state;
    }

    /**
     * @param array<int> $ids
     * @param int $instanceid
     * @return array<int, \stdClass>
     */
    protected static function load_submissions_chunk(array $ids, int $instanceid): array {
        global $DB;
        if (!$ids) {
            return [];
        }
        list($insql, $params) = $DB->get_in_or_equal($ids, SQL_PARAMS_NAMED);
        $params['usid'] = $instanceid;
        $records = $DB->get_records_sql(
            "SELECT s.* FROM {userstatement_submission} s WHERE s.userstatement = :usid AND s.id $insql",
            $params
        );
        return self::filter_valid_submissions($records);
    }

    protected static function set_status(int $exportid, string $status): void {
        global $DB;
        $DB->update_record('userstatement_export', (object) [
            'id' => $exportid,
            'status' => $status,
            'timemodified' => time(),
        ]);
    }

    protected static function fail(int $exportid, string $message): void {
        global $DB;
        $DB->update_record('userstatement_export', (object) [
            'id' => $exportid,
            'status' => self::STATUS_FAILED,
            'timemodified' => time(),
            'errormsg' => $message,
            'statedata' => null,
        ]);
    }

    protected static function cleanup_old_exports(int $instanceid): void {
        global $DB;
        $limit = time() - (7 * DAYSECS);
        $old = $DB->get_records_select(
            'userstatement_export',
            'userstatement = ? AND timecreated < ?',
            [$instanceid, $limit]
        );
        if (!$old) {
            return;
        }
        $modid = (int) $DB->get_field('modules', 'id', ['name' => 'userstatement']);
        if (!$modid) {
            return;
        }
        $fs = get_file_storage();
        foreach ($old as $export) {
            $cm = $DB->get_record('course_modules', ['module' => $modid, 'instance' => $instanceid], 'id', IGNORE_MISSING);
            if ($cm) {
                $context = \context_module::instance($cm->id);
                $fs->delete_area_files($context->id, 'mod_userstatement', self::FILEAREA, $export->id);
            }
            $DB->delete_records('userstatement_export', ['id' => $export->id]);
        }
    }

    protected static function fetch_submissions(int $instanceid, int $groupid): array {
        global $DB;
        $gjs = userstatement_submissions_group_join_sql($groupid);
        $sql = "SELECT s.*
                  FROM {userstatement_submission} s
                       {$gjs['join']}
                 WHERE s.userstatement = :usid
              ORDER BY s.timemodified ASC";
        return $DB->get_records_sql($sql, array_merge(['usid' => $instanceid], $gjs['params']));
    }

    protected static function filter_valid_submissions(array $subs): array {
        $valid = [];
        foreach ($subs as $sub) {
            $data = json_decode($sub->data);
            if (is_array($data)) {
                $data = (object) $data;
            }
            if (!is_object($data) || userstatement_validate_submission_for_save($data) !== '') {
                continue;
            }
            $sub->_exportdata = $data;
            $valid[] = $sub;
        }
        return $valid;
    }

    protected static function build_part_zip(
        \stdClass $instance,
        \stdClass $course,
        array $chunk,
        ?string $registrybytes,
        bool $includeregistry
    ): string {
        $dir = make_temp_directory('userstatement');
        $tmppath = $dir . '/bulk_' . sha1(uniqid((string) mt_rand(), true)) . '.zip';
        $zip = new \ZipArchive();
        if ($zip->open($tmppath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \moodle_exception('exportwritefailed', 'userstatement');
        }
        if ($includeregistry && $registrybytes !== null && $registrybytes !== '') {
            $xlsxname = 'fis_frdo_' . clean_filename(format_string($course->shortname, true)) . '_'
                . userdate(time(), '%Y%m%d', 99, false) . '.xlsx';
            $zip->addFromString($xlsxname, $registrybytes);
        }
        foreach ($chunk as $sub) {
            $data = $sub->_exportdata;
            $user = \core_user::get_user((int) $sub->userid, '*', IGNORE_MISSING);
            if (!$user) {
                continue;
            }
            $pdfbytes = \mod_userstatement\statement_pdf::render_binary($instance, $user, $data);
            $pdfname = 'zayavlenie_' . (int) $user->id . '_' . clean_filename(userstatement_user_firstname($user)) . '.pdf';
            $zip->addFromString($pdfname, $pdfbytes);
            unset($pdfbytes, $user);
            if (function_exists('gc_collect_cycles')) {
                gc_collect_cycles();
            }
        }
        if (!$zip->close()) {
            @unlink($tmppath);
            throw new \moodle_exception('exportwritefailed', 'userstatement');
        }
        return $tmppath;
    }

    protected static function notify_ready(
        \stdClass $export,
        \stdClass $instance,
        \stdClass $cm,
        \stdClass $course,
        \context_module $context
    ): void {
        global $DB;
        $user = $DB->get_record('user', ['id' => $export->requestedby], '*', MUST_EXIST);
        $viewurl = new \moodle_url('/mod/userstatement/view.php', ['id' => $cm->id, 'tab' => 'submissions']);
        $message = new \core\message\message();
        $message->component = 'mod_userstatement';
        $message->name = 'bulkexportready';
        $message->userfrom = \core_user::get_noreply_user();
        $message->userto = $user;
        $message->subject = get_string('bulkexportreadysubject', 'userstatement', format_string($instance->name));
        $message->fullmessage = get_string('bulkexportreadybody', 'userstatement', (object) [
            'name' => format_string($instance->name),
            'parts' => $export->partcount,
            'pdfs' => $export->pdfcount,
            'url' => $viewurl->out(false),
        ]);
        $message->fullmessageformat = FORMAT_PLAIN;
        $message->fullmessagehtml = get_string('bulkexportreadybodyhtml', 'userstatement', (object) [
            'name' => format_string($instance->name),
            'parts' => $export->partcount,
            'pdfs' => $export->pdfcount,
            'url' => $viewurl->out(false),
        ]);
        $message->smallmessage = get_string('bulkexportreadysmall', 'userstatement');
        $message->notification = 1;
        $message->contexturl = $viewurl;
        $message->contexturlname = format_string($instance->name);
        @message_send($message);
    }
}
