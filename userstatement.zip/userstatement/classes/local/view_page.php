<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Общая инициализация страницы элемента курса (контекст, группы, URL, права, кэш своей заявки).
 */
class view_page {

    /** @var \stdClass */
    public $cm;
    /** @var \stdClass */
    public $course;
    /** @var \context_module */
    public $context;
    /** @var \stdClass */
    public $instance;
    /** @var int */
    public $exportgroupid = 0;
    /** @var bool */
    public $canviewall;
    /** @var bool */
    public $cansubmit;

    /** @var \stdClass|false|null */
    protected $ownsubmission = null;

    /**
     * @param int $cmid id элемента курса (course_modules).
     */
    protected function __construct(int $cmid) {
        global $DB, $CFG, $PAGE, $USER;

        $this->cm = get_coursemodule_from_id('userstatement', $cmid, 0, false, MUST_EXIST);
        $this->course = get_course($this->cm->course);
        $this->context = \context_module::instance($this->cm->id);
        $this->instance = $DB->get_record('userstatement', ['id' => $this->cm->instance], '*', MUST_EXIST);

        require_login($this->course, true, $this->cm);
        require_capability('mod/userstatement:view', $this->context);

        $PAGE->set_context($this->context);
        $PAGE->set_cm($this->cm, $this->course, $this->instance);

        require_once($CFG->dirroot . '/group/lib.php');
        if (groups_get_activity_groupmode($this->cm, $this->course)) {
            $this->exportgroupid = (int) groups_get_activity_group($this->cm, true);
            $allowed = userstatement_get_activity_allowed_groups($this->cm, $USER->id);
            if ($this->exportgroupid && !isset($allowed[$this->exportgroupid])) {
                $this->exportgroupid = 0;
            }
        }

        $this->canviewall = has_capability('mod/userstatement:viewall', $this->context);
        $this->cansubmit = has_capability('mod/userstatement:submit', $this->context);
    }

    /**
     * Канонический URL страницы просмотра (для навигации и форм).
     */
    public function set_page_url_view(): void {
        global $PAGE;
        $pageparams = ['id' => $this->cm->id];
        if ($this->exportgroupid > 0) {
            $pageparams['group'] = $this->exportgroupid;
        }
        $PAGE->set_url('/mod/userstatement/view.php', $pageparams);
    }

    /**
     * @param int $cmid
     * @return self
     */
    public static function from_cm_id(int $cmid): self {
        return new self($cmid);
    }

    /**
     * Одна выборка заявки текущего пользователя (кэш на запрос).
     *
     * @return \stdClass|false
     */
    public function get_own_submission() {
        global $DB, $USER;

        if ($this->ownsubmission !== null) {
            return $this->ownsubmission;
        }
        $this->ownsubmission = $DB->get_record('userstatement_submission', [
            'userstatement' => $this->instance->id,
            'userid' => $USER->id,
        ], '*', IGNORE_MISSING);
        return $this->ownsubmission;
    }

    /**
     * @return bool
     */
    public function is_listener_locked(): bool {
        return !$this->canviewall && ($sub = $this->get_own_submission()) && userstatement_submission_is_locked_payload($sub->data);
    }

    /**
     * Допустимая вкладка для текущего пользователя.
     *
     * @param string $requested form|submissions|''
     * @return string form|submissions
     */
    public function resolve_tab(string $requested): string {
        $requested = strtolower(trim($requested));
        if ($this->cansubmit && $this->canviewall) {
            if ($requested === 'form') {
                return 'form';
            }
            return 'submissions';
        }
        if ($this->canviewall) {
            return 'submissions';
        }
        return 'form';
    }

    /**
     * @param string $search
     * @param int $verifiedfilter -1 все, 0 непроверенные, 1 проверенные
     * @return array{from: string, params: array<string, mixed>}
     */
    protected function submissions_sql_parts(string $search, int $verifiedfilter = -1): array {
        global $DB;

        $gjs = userstatement_submissions_group_join_sql($this->exportgroupid);
        $params = array_merge(['usid' => $this->instance->id], $gjs['params']);
        $whereextra = '';
        $search = trim($search);
        if ($search !== '') {
            $whereextra .= userstatement_submissions_search_where($search, $params, 'us');
        }
        if ($verifiedfilter === 0 || $verifiedfilter === 1) {
            $params['usverified'] = $verifiedfilter;
            $whereextra .= ' AND s.verified = :usverified';
        }
        $from = " FROM {userstatement_submission} s
                  JOIN {user} u ON u.id = s.userid
                       {$gjs['join']}
                 WHERE s.userstatement = :usid{$whereextra}";
        return ['from' => $from, 'params' => $params];
    }

    /**
     * @param string $search
     * @param int $verifiedfilter
     * @return int
     */
    public function count_submissions(string $search = '', int $verifiedfilter = -1): int {
        global $DB;
        $parts = $this->submissions_sql_parts($search, $verifiedfilter);
        return (int) $DB->count_records_sql('SELECT COUNT(1)' . $parts['from'], $parts['params']);
    }

    /**
     * Страница списка заявлений.
     *
     * @param string $search
     * @param int $pageindex с нуля
     * @param int $perpage
     * @param int $verifiedfilter
     * @return array<int, \stdClass>
     */
    public function get_submissions_page(
        string $search,
        int $pageindex,
        int $perpage,
        int $verifiedfilter = -1,
        string $sort = 'timemodified',
        string $sortdir = 'desc'
    ): array {
        global $DB;
        $parts = $this->submissions_sql_parts($search, $verifiedfilter);
        $sql = 'SELECT s.*, u.firstname, u.lastname, u.email' . $parts['from']
            . userstatement_submissions_order_sql($sort, $sortdir);
        return $DB->get_records_sql($sql, $parts['params'], max(0, $pageindex) * $perpage, $perpage);
    }

    /**
     * Показывать ли переключатель вкладок.
     *
     * @return bool
     */
    public function has_multiple_tabs(): bool {
        return $this->cansubmit && $this->canviewall;
    }

    /**
     * URL страницы view с тем же набором query (группа и т.д.).
     *
     * @param array $extra
     * @return \moodle_url
     */
    public function url_view(array $extra = []): \moodle_url {
        return new \moodle_url('/mod/userstatement/view.php', userstatement_view_page_params($this->cm->id, $this->exportgroupid, $extra));
    }

    /**
     * URL обработчика отправки формы.
     *
     * @return \moodle_url
     */
    public function url_submit(): \moodle_url {
        return new \moodle_url('/mod/userstatement/submit.php', userstatement_view_page_params($this->cm->id, $this->exportgroupid));
    }

    /**
     * URL скачивания PDF.
     *
     * @param int $userid 0 — текущий пользователь
     * @return \moodle_url
     */
    public function url_download(int $userid = 0): \moodle_url {
        $p = [
            'id' => $this->cm->id,
            'sesskey' => sesskey(),
        ];
        if ($userid > 0) {
            $p['userid'] = $userid;
        }
        return new \moodle_url('/mod/userstatement/download.php', $p);
    }

    /**
     * URL удаления заявки (первый шаг — подтверждение в delete.php).
     *
     * @param int $targetuserid
     * @return \moodle_url
     */
    public function url_delete(int $targetuserid): \moodle_url {
        return new \moodle_url('/mod/userstatement/delete.php', userstatement_view_page_params($this->cm->id, $this->exportgroupid, [
            'deleteuser' => $targetuserid,
        ]));
    }

    /**
     * URL переключения «Проверено» для заявления участника.
     *
     * @param int $targetuserid
     * @param int $verified 0|1
     * @param array $extra search, page
     * @return \moodle_url
     */
    public function url_toggle_verified(int $targetuserid, int $verified, array $extra = []): \moodle_url {
        $params = userstatement_view_page_params($this->cm->id, $this->exportgroupid, array_merge([
            'userid' => $targetuserid,
            'verified' => $verified ? 1 : 0,
            'sesskey' => sesskey(),
        ], $extra));
        return new \moodle_url('/mod/userstatement/toggle_verified.php', $params);
    }
}
