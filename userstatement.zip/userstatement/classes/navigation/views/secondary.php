<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\navigation\views;

use core\navigation\views\secondary as core_secondary;
use moodle_url;
use navigation_node;
use settings_navigation;

/**
 * Вкладки модуля в верхней secondary-навигации (Moodle 4+).
 */
class secondary extends core_secondary {

    /**
     * @param settings_navigation $settingsnav
     * @param navigation_node|null $rootnode
     */
    protected function load_module_navigation(settings_navigation $settingsnav, ?navigation_node $rootnode = null): void {
        $rootnode = $rootnode ?? $this;
        $mainnode = $settingsnav->find('modulesettings', self::TYPE_SETTING);
        $nodes = $this->get_default_module_mapping();

        if (!$mainnode) {
            return;
        }

        $cmid = $this->page->cm->id;
        $context = \context_module::instance($cmid);
        $canviewall = has_capability('mod/userstatement:viewall', $context);
        $cansubmit = has_capability('mod/userstatement:submit', $context);
        $currenttab = $this->page->url->get_param('tab');

        if ($canviewall && $cansubmit) {
            $listurl = new moodle_url('/mod/userstatement/view.php', ['id' => $cmid, 'tab' => 'submissions']);
            $listnode = $rootnode->add(
                get_string('tab_submissions', 'userstatement'),
                $listurl,
                null,
                null,
                'modulepage'
            );
            if ($currenttab !== 'form') {
                $listnode->make_active();
            }

            $formurl = new moodle_url('/mod/userstatement/view.php', ['id' => $cmid, 'tab' => 'form']);
            $formnode = $rootnode->add(
                get_string('tab_form', 'userstatement'),
                $formurl,
                null,
                null,
                'userstatementsubmissions'
            );
            if ($currenttab === 'form') {
                $formnode->make_active();
            }
        } else if ($cansubmit) {
            $formurl = new moodle_url('/mod/userstatement/view.php', ['id' => $cmid, 'tab' => 'form']);
            $formnode = $rootnode->add(
                get_string('modulename', 'userstatement'),
                $formurl,
                null,
                null,
                'modulepage'
            );
            if ($currenttab !== 'submissions') {
                $formnode->make_active();
            }
        } else if ($canviewall) {
            $listurl = new moodle_url('/mod/userstatement/view.php', ['id' => $cmid, 'tab' => 'submissions']);
            $listnode = $rootnode->add(
                get_string('modulename', 'userstatement'),
                $listurl,
                null,
                null,
                'modulepage'
            );
            if ($currenttab === 'submissions' || $currenttab === '' || $currenttab === null) {
                $listnode->make_active();
            }
        }

        $nodesordered = $this->get_leaf_nodes($mainnode, $nodes);
        $this->add_ordered_nodes($nodesordered, $rootnode);
        $this->load_remaining_nodes($mainnode, $nodes, $rootnode);
    }
}
