<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\transform;
use core_privacy\local\request\writer;

defined('MOODLE_INTERNAL') || die();

/**
 * Провайдер приватности для сохранённых заявлений.
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider {

    /**
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection) {
        $collection->add_database_table(
            'userstatement_submission',
            [
                'userid' => 'privacy:metadata:userstatement_submission:userid',
                'data' => 'privacy:metadata:userstatement_submission:data',
                'timecreated' => 'privacy:metadata:userstatement_submission:timecreated',
                'timemodified' => 'privacy:metadata:userstatement_submission:timemodified',
                'verified' => 'privacy:metadata:userstatement_submission:verified',
                'verifiedby' => 'privacy:metadata:userstatement_submission:verifiedby',
                'verifiedtime' => 'privacy:metadata:userstatement_submission:verifiedtime',
            ],
            'privacy:metadata:userstatement_submission'
        );
        return $collection;
    }

    /**
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        $sql = "SELECT ctx.id
                  FROM {context} ctx
                  JOIN {course_modules} cm ON cm.id = ctx.instanceid AND ctx.contextlevel = :contextlevel
                  JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                  JOIN {userstatement} ust ON ust.id = cm.instance
                  JOIN {userstatement_submission} sub ON sub.userstatement = ust.id AND sub.userid = :userid";
        $params = [
            'contextlevel' => CONTEXT_MODULE,
            'modname' => 'userstatement',
            'userid' => $userid,
        ];
        $contextlist->add_from_sql($sql, $params);

        return $contextlist;
    }

    /**
     * @param approved_contextlist $contextlist
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;

        if (empty($contextlist->get_contextids())) {
            return;
        }

        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel != CONTEXT_MODULE) {
                continue;
            }
            $cm = get_coursemodule_from_id('userstatement', $context->instanceid, 0, false);
            if (!$cm || $cm->modname !== 'userstatement') {
                continue;
            }
            $sub = $DB->get_record('userstatement_submission', [
                'userstatement' => $cm->instance,
                'userid' => $userid,
            ]);
            if (!$sub) {
                continue;
            }
            $payload = json_decode($sub->data);
            writer::with_context($context)->export_data(
                [],
                (object) [
                    'timemodified' => transform::datetime($sub->timemodified),
                    'formdata' => $payload,
                ]
            );
        }
    }

    /**
     * @param \context $context
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;

        if ($context->contextlevel != CONTEXT_MODULE) {
            return;
        }
        $cm = get_coursemodule_from_id('userstatement', $context->instanceid, 0, false);
        if (!$cm || $cm->modname !== 'userstatement') {
            return;
        }
        userstatement_purge_instance_data((int) $cm->instance);
    }

    /**
     * @param approved_contextlist $contextlist
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;

        if (empty($contextlist->get_contextids())) {
            return;
        }
        $userid = $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel != CONTEXT_MODULE) {
                continue;
            }
            $cm = get_coursemodule_from_id('userstatement', $context->instanceid, 0, false);
            if (!$cm || $cm->modname !== 'userstatement') {
                continue;
            }
            $DB->delete_records('userstatement_submission', [
                'userstatement' => $cm->instance,
                'userid' => $userid,
            ]);
        }
    }
}
