<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement;

defined('MOODLE_INTERNAL') || die();

/**
 * Генерация PDF-заявления (оформление по типовому образцу).
 */
class statement_pdf {

    /**
     * Сформировать PDF в память (без вывода в браузер).
     *
     * @param \stdClass $instance Запись userstatement.
     * @param \stdClass $user Пользователь (слушатель).
     * @param \stdClass $data Данные формы.
     * @return string Содержимое PDF.
     */
    public static function render_binary(\stdClass $instance, \stdClass $user, \stdClass $data) {
        global $CFG;

        if (!file_exists($CFG->libdir . '/pdflib.php')) {
            throw new \moodle_exception('error_pdflib', 'userstatement');
        }

        require_once($CFG->libdir . '/pdflib.php');

        $pdf = new \pdf();
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $marginleftmm = 20; // 2,00 см — левое поле.
        $marginothermm = 10;
        $pdf->SetMargins($marginleftmm, $marginothermm, $marginothermm);
        $pdf->SetAutoPageBreak(true, $marginothermm);
        if (method_exists($pdf, 'setCellHeightRatio')) {
            $pdf->setCellHeightRatio(0.9);
        }
        $pdf->AddPage();
        $pdf->SetFont('freeserif', '', 8.5);

        $html = self::build_html($instance, $user, $data);
        $pdf->writeHTML($html, true, false, true, false, '');

        return $pdf->Output('', 'S');
    }

    /**
     * Отправка PDF в браузер.
     *
     * @param \stdClass $instance Запись userstatement.
     * @param \stdClass $user Пользователь (слушатель).
     * @param \stdClass $data Данные формы.
     */
    public static function send_download(\stdClass $instance, \stdClass $user, \stdClass $data) {
        while (ob_get_level()) {
            ob_end_clean();
        }

        $content = self::render_binary($instance, $user, $data);
        $firstname = trim((string) ($user->firstname ?? ''));
        $filename = 'zayavlenie_' . clean_filename($firstname) . '_' . clean_filename($user->username) . '.pdf';

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($content));
        header('Cache-Control: private, must-revalidate, pre-check=0, post-check=0, max-age=0');
        echo $content;
        exit;
    }

    /**
     * @param \stdClass $instance
     * @param \stdClass $user
     * @param \stdClass $data
     * @return string
     */
    protected static function build_html(\stdClass $instance, \stdClass $user, \stdClass $data) {
        global $DB;

        $course = $DB->get_record('course', ['id' => $instance->course], 'id,fullname,startdate', MUST_EXIST);
        $program = trim(format_string($course->fullname));

        $addraw = str_replace(["\r\n", "\r"], "\n", trim($instance->addressee ?? ''));
        $addressee = nl2br(self::h($addraw));
        $institute = trim($instance->institutename ?? '');
        $bodyintro = get_string('pdf_body_intro', 'userstatement', (object) [
            'program' => $program,
            'institute' => $institute,
        ]);

        $leader = trim($instance->courseleader ?? '');

        $coursestartts = \userstatement_resolve_coursestart_ts($instance, $course);
        $charterdateline = '';
        $coursestartline = '';
        if ($coursestartts > 0) {
            $coursestartformatted = self::format_date_value($coursestartts);
            if ($coursestartformatted !== '—') {
                $charterdateline = self::h(get_string('pdf_date_line', 'userstatement', $coursestartformatted));
                $coursestartline = '<br/>' . self::h($coursestartformatted);
            }
        }

        $rows = self::rows_for_pdf($data, $user);
        $rowshtml = '';
        foreach ($rows as $row) {
            $label = self::h($row['label']);
            $value = nl2br(self::h($row['value']));
            // Только один визуальный разрыв: после «дата выдачи диплома», перед блоком «место работы».
            $mb = !empty($row['gutter_after']) ? 'margin-bottom:2mm;' : 'margin-bottom:0;';
            $rowshtml .= '<div style="text-align:justify;margin:0;padding:0;line-height:1.02;font-size:8.5pt;' . $mb . '">'
                . $label . ': ' . $value . '</div>';
        }

        $charter = '<i>' . self::h(get_string('pdf_charter_ack', 'userstatement')) . '</i>';
        $ufirstname = self::h(trim((string) ($user->firstname ?? '')));
        $leaderline = $leader !== '' ? self::h($leader) : '—';
        $agreedbody = self::h(get_string('pdf_course_leader', 'userstatement')) . ' ' . $leaderline . $coursestartline;
        $simplesign = self::h(get_string('pdf_simple_sign', 'userstatement'));
        $signatureblockright = self::listener_signature_block_html($ufirstname, $simplesign, 'right');
        $signatureblockleft = self::listener_signature_block_html($ufirstname, $simplesign, 'left');

        $template = self::get_statement_template();
        $replacements = [
            '{{addressee}}' => $addressee,
            '{{title}}' => self::h(get_string('pdf_title', 'userstatement')),
            '{{body_intro}}' => self::h($bodyintro),
            '{{about_header}}' => self::h(get_string('pdf_about_header', 'userstatement')),
            '{{learner_rows}}' => $rowshtml,
            '{{charter}}' => $charter,
            '{{charter_date_line}}' => $charterdateline,
            '{{user_firstname}}' => $ufirstname,
            '{{user_fullname}}' => $ufirstname,
            '{{simple_sign}}' => $simplesign,
            '{{listener_signature_block}}' => $signatureblockright,
            '{{listener_signature_block_confirm}}' => $signatureblockleft,
            '{{confirm_header}}' => self::h(get_string('confirmaccuracy', 'userstatement')),
            '{{agreed_header}}' => self::h(get_string('pdf_agreed', 'userstatement')),
            '{{agreed_body}}' => $agreedbody,
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $template);
    }


    /**
     * @return string
     */
    protected static function get_statement_template(): string {
        global $CFG;

        if (file_exists($CFG->dirroot . '/local/edudocuments/lib.php')) {
            require_once($CFG->dirroot . '/local/edudocuments/lib.php');
            $html = local_edudocuments_get_statement_template();
            if (trim($html) !== '') {
                return $html;
            }
        }

        $path = $CFG->dirroot . '/local/edudocuments/defaults/statement.html';
        if (is_readable($path)) {
            return (string) file_get_contents($path);
        }

        return '<style>body{font-size:8.5pt;}.userstatement-pdf-header{text-align:right;font-size:8.5pt;line-height:1.05;margin:0 0 1px 0;}</style>'
            . '<div class="userstatement-pdf-header">{{addressee}}<br />{{user_firstname}}</div>'
            . '<h2 style="text-align:center;">{{title}}</h2>'
            . '<p>{{body_intro}}</p><p><b>{{about_header}}</b></p>{{learner_rows}}'
            . '<p>{{charter}}</p>'
            . '<table width="100%"><tr><td style="width:50%;vertical-align:top;"><br />{{charter_date_line}}</td>'
            . '<td style="width:50%;text-align:right;vertical-align:top;padding:0;">{{listener_signature_block}}</td></tr></table>'
            . '<p style="margin:1px 0 0 0;padding:0;line-height:1.05;"><b>{{confirm_header}}</b></p>'
            . '<div style="text-align:left;margin:1px 0 0 0;">{{listener_signature_block_confirm}}</div>'
            . '<p style="margin:1px 0 0 0;padding:0;line-height:1.05;"><b>{{agreed_header}}</b><br/>{{agreed_body}}</p>';
    }

    /**
     * Блок: имя слушателя, линия, подпись ПЭП.
     *
     * @param string $firstname Уже экранированное имя
     * @param string $simplesign Уже экранированная подпись ПЭП
     * @param string $align left|right
     * @return string
     */
    protected static function listener_signature_block_html(string $firstname, string $simplesign, string $align = 'right'): string {
        $align = ($align === 'left') ? 'left' : 'right';
        $line = self::listener_signature_line();

        return '<table cellpadding="0" cellspacing="0" align="' . $align . '" style="border-collapse:collapse;line-height:1.0;">'
            . '<tr><td align="' . $align . '" style="padding:0;margin:0;line-height:1.0;font-size:8.5pt;">' . $firstname . '</td></tr>'
            . '<tr><td align="' . $align . '" style="padding:0;margin:0;line-height:0.65;font-size:8.5pt;white-space:nowrap;">'
            . $line . '</td></tr>'
            . '<tr><td align="' . $align . '" style="padding:0;margin:0;padding-top:1px;line-height:1.05;font-size:6.5pt;white-space:nowrap;">'
            . $simplesign . '</td></tr></table>';
    }

    /**
     * Линия подписи — длиннее текста «подписано простой электронной подписью» (6.5 pt).
     *
     * @return string
     */
    protected static function listener_signature_line(): string {
        return '_______________________________________';
    }

    /**
     * @param string $s
     * @return string
     */
    protected static function h($s) {
        return htmlspecialchars($s, ENT_QUOTES | ENT_HTML401, 'UTF-8');
    }

    /**
     * СНИЛС в PDF: с тире/пробелом по маске; при отсутствии цифр — «—».
     *
     * @param mixed $raw
     * @return string
     */
    protected static function snils_display_value($raw) {
        $vis = \userstatement_format_snils_display($raw);
        if ($vis !== '') {
            return $vis;
        }
        return self::str($raw);
    }

    /**
     * Телефон в PDF: с маской; при отсутствии цифр — «—».
     *
     * @param mixed $raw
     * @return string
     */
    protected static function phone_display_value($raw) {
        $vis = \userstatement_format_phone_display($raw);
        if ($vis !== '') {
            return $vis;
        }
        return self::str($raw);
    }

    /**
     * @param \stdClass $data
     * @param \stdClass $user
     * @return array<int, array{label: string, value: string, gutter_after?: bool}>
     */
    protected static function rows_for_pdf(\stdClass $data, \stdClass $user) {
        $g = $data->gender ?? 'female';
        if (!in_array($g, ['female', 'male', 'other'], true)) {
            $g = 'female';
        }
        $genderlabel = get_string('gender_' . $g, 'userstatement');

        return [
            [
                'label' => get_string('field_birthdate', 'userstatement'),
                'value' => self::format_date_value($data->birthdate ?? null),
            ],
            [
                'label' => get_string('pdf_field_snils', 'userstatement'),
                'value' => self::snils_display_value($data->snils ?? ''),
            ],
            [
                'label' => get_string('field_gender', 'userstatement'),
                'value' => $genderlabel,
            ],
            [
                'label' => get_string('pdf_field_citizenship', 'userstatement'),
                'value' => self::str($data->citizenship ?? ''),
            ],
            [
                'label' => get_string('field_edu_level', 'userstatement'),
                'value' => self::str($data->edu_level ?? ''),
            ],
            [
                'label' => get_string('field_edu_institution', 'userstatement'),
                'value' => self::str($data->edu_institution ?? ''),
            ],
            [
                'label' => get_string('field_diploma_lastname', 'userstatement'),
                'value' => self::str($data->diploma_lastname ?? ''),
            ],
            [
                'label' => get_string('field_diploma_series', 'userstatement'),
                'value' => self::str($data->diploma_series ?? ''),
            ],
            [
                'label' => get_string('field_diploma_number', 'userstatement'),
                'value' => self::str($data->diploma_number ?? ''),
            ],
            [
                'label' => get_string('field_qualification', 'userstatement'),
                'value' => self::str($data->qualification ?? ''),
            ],
            [
                'label' => get_string('field_diploma_date', 'userstatement'),
                'value' => self::format_date_value($data->diploma_date ?? null),
                'gutter_after' => true,
            ],
            [
                'label' => get_string('field_workplace', 'userstatement'),
                'value' => self::str($data->workplace ?? ''),
            ],
            [
                'label' => get_string('field_position', 'userstatement'),
                'value' => self::str($data->position ?? ''),
            ],
            [
                'label' => get_string('field_experience_position', 'userstatement'),
                'value' => self::str($data->experience_position ?? ''),
            ],
            [
                'label' => get_string('field_pedagogical_experience', 'userstatement'),
                'value' => self::str($data->pedagogical_experience ?? ''),
            ],
            [
                'label' => get_string('field_subjects', 'userstatement'),
                'value' => self::str($data->subjects ?? ''),
            ],
            [
                'label' => get_string('field_degree_title', 'userstatement'),
                'value' => self::str($data->degree_title ?? ''),
            ],
            [
                'label' => get_string('field_phone', 'userstatement'),
                'value' => self::phone_display_value($data->phone ?? ''),
            ],
            [
                'label' => get_string('field_email', 'userstatement'),
                'value' => self::str($user->email ?? ''),
            ],
        ];
    }

    /**
     * @param mixed $v
     * @return string
     */
    protected static function str($v) {
        $s = trim((string) $v);
        return $s === '' ? '—' : $s;
    }

    /**
     * @param mixed $value
     * @return string
     */
    protected static function format_date_value($value) {
        $formatted = userstatement_date_format_display($value);
        return $formatted === '' ? '—' : $formatted;
    }

    /**
     * Дата в заявлении: ДД.ММ.ГГГГ (месяц цифрами).
     *
     * @param int $day
     * @param int $month
     * @param int $year
     * @return string
     */
    protected static function format_date_numeric($day, $month, $year) {
        if ($day < 1 || $month < 1 || $year < 1) {
            return '—';
        }
        return sprintf('%02d.%02d.%04d', $day, $month, $year);
    }
}
