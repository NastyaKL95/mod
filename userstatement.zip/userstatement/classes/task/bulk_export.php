<?php
// This file is part of Moodle - http://moodle.org/

namespace mod_userstatement\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Adhoc-задача: сборка ZIP-частей со всеми PDF заявлениями.
 */
class bulk_export extends \core\task\adhoc_task {

    /**
     * @return string
     */
    public function get_component() {
        return 'mod_userstatement';
    }

    /**
     * @return string
     */
    public function get_name() {
        return get_string('bulkexporttaskname', 'userstatement');
    }

    public function execute() {
        $data = $this->get_custom_data();
        if (empty($data->exportid)) {
            return;
        }
        \mod_userstatement\local\bulk_export_service::run((int) $data->exportid);
    }
}
