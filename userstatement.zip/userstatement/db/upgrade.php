<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion
 * @return bool
 */
function xmldb_userstatement_upgrade($oldversion) {
    global $DB, $CFG;

    $dbman = $DB->get_manager();

    if ($oldversion < 2024051502) {
        $table = new xmldb_table('userstatement');
        $field = new xmldb_field('coursestart', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'courseleader');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_mod_savepoint(true, 2024051502, 'userstatement');
    }

    if ($oldversion < 2024051627) {
        $table = new xmldb_table('userstatement_submission');
        $field = new xmldb_field('verified', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'timemodified');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        $field = new xmldb_field('verifiedby', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'verified');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        $field = new xmldb_field('verifiedtime', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'verifiedby');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        require_once(dirname(__DIR__) . '/lib.php');
        $modid = (int) $DB->get_field('modules', 'id', ['name' => 'userstatement']);
        if ($modid) {
            $cms = $DB->get_records('course_modules', ['module' => $modid]);
            foreach ($cms as $cm) {
                $cmrec = get_coursemodule_from_id('userstatement', $cm->id, 0, false, IGNORE_MISSING);
                if (!$cmrec) {
                    continue;
                }
                $course = get_course($cmrec->course);
                $subs = $DB->get_records('userstatement_submission', ['userstatement' => $cmrec->instance]);
                foreach ($subs as $sub) {
                    userstatement_sync_completion_for_user($cmrec, $course, (int) $sub->userid, false);
                }
            }
        }

        upgrade_mod_savepoint(true, 2024051627, 'userstatement');
    }

    if ($oldversion < 2024051628) {
        $table = new xmldb_table('userstatement');
        $field = new xmldb_field('completionverified', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1', 'timemodified');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        upgrade_mod_savepoint(true, 2024051628, 'userstatement');
    }

    if ($oldversion < 2024051638) {
        upgrade_mod_savepoint(true, 2024051638, 'userstatement');
    }

    if ($oldversion < 2024051639) {
        upgrade_mod_savepoint(true, 2024051639, 'userstatement');
    }

    if ($oldversion < 2024051640) {
        $table = new xmldb_table('userstatement_export');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('userstatement', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('requestedby', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('groupid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending');
            $table->add_field('partcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('pdfcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('errormsg', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('userstatement', XMLDB_KEY_FOREIGN, ['userstatement'], 'userstatement', ['id']);
            $table->add_key('requestedby', XMLDB_KEY_FOREIGN, ['requestedby'], 'user', ['id']);
            $table->add_index('statement_status', XMLDB_INDEX_NOTUNIQUE, ['userstatement', 'status']);
            $dbman->create_table($table);
        }
        upgrade_mod_savepoint(true, 2024051640, 'userstatement');
    }

    if ($oldversion < 2024051641) {
        upgrade_mod_savepoint(true, 2024051641, 'userstatement');
    }

    if ($oldversion < 2024051642) {
        $table = new xmldb_table('userstatement_export');
        $field = new xmldb_field('statedata', XMLDB_TYPE_TEXT, null, null, null, null, null, 'errormsg');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        upgrade_mod_savepoint(true, 2024051642, 'userstatement');
    }

    if ($oldversion < 2024051643) {
        upgrade_mod_savepoint(true, 2024051643, 'userstatement');
    }

    if ($oldversion < 2024051644) {
        upgrade_mod_savepoint(true, 2024051644, 'userstatement');
    }

    if ($oldversion < 2024051645) {
        upgrade_mod_savepoint(true, 2024051645, 'userstatement');
    }

    if ($oldversion < 2024051646) {
        upgrade_mod_savepoint(true, 2024051646, 'userstatement');
    }

    if ($oldversion < 2024051647) {
        upgrade_mod_savepoint(true, 2024051647, 'userstatement');
    }

    if ($oldversion < 2024051648) {
        upgrade_mod_savepoint(true, 2024051648, 'userstatement');
    }

    if ($oldversion < 2024051656) {
        require_once(dirname(__DIR__) . '/lib.php');
        $subs = $DB->get_records_select(
            'userstatement_submission',
            "data IS NOT NULL AND data <> '' AND data <> '{}'"
        );
        foreach ($subs as $sub) {
            $data = json_decode($sub->data, true);
            if (!is_array($data)) {
                continue;
            }
            $changed = false;
            foreach (userstatement_required_date_fields() as $field) {
                if (!array_key_exists($field, $data)) {
                    continue;
                }
                $normalized = userstatement_date_normalize_for_json($data[$field]);
                if ($normalized === null) {
                    continue;
                }
                if ($data[$field] !== $normalized) {
                    $data[$field] = $normalized;
                    $changed = true;
                }
            }
            if ($changed) {
                $sub->data = json_encode($data, JSON_UNESCAPED_UNICODE);
                $DB->update_record('userstatement_submission', $sub);
            }
        }
        upgrade_mod_savepoint(true, 2024051656, 'userstatement');
    }

    if ($oldversion < 2024051657) {
        upgrade_mod_savepoint(true, 2024051657, 'userstatement');
    }

    if ($oldversion < 2024051658) {
        upgrade_mod_savepoint(true, 2024051658, 'userstatement');
    }

    if ($oldversion < 2024051659) {
        upgrade_mod_savepoint(true, 2024051659, 'userstatement');
    }

    if ($oldversion < 2024051660) {
        upgrade_mod_savepoint(true, 2024051660, 'userstatement');
    }

    return true;
}
