<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);
$userid = optional_param('userid', 0, PARAM_INT);

require_sesskey();

$cm = get_coursemodule_from_id('userstatement', $id, 0, false, MUST_EXIST);
$course = get_course($cm->course);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);

require_capability('mod/userstatement:view', $context);

$instance = $DB->get_record('userstatement', ['id' => $cm->instance], '*', MUST_EXIST);

userstatement_send_pdf_download($context, $instance, $userid);
