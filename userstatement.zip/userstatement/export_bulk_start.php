<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_userstatement\local\bulk_export_service;

$id = required_param('id', PARAM_INT);

require_sesskey();

$page = \mod_userstatement\local\view_page::from_cm_id($id);

global $USER;

require_capability('mod/userstatement:viewall', $page->context);

if (!class_exists('ZipArchive')) {
    throw new moodle_exception('noziparchive', 'userstatement');
}

$exportall = optional_param('all', 0, PARAM_BOOL);
$groupparam = optional_param('group', -1, PARAM_INT);

$returnurl = new moodle_url('/mod/userstatement/view.php', userstatement_view_page_params(
    $page->cm->id,
    $page->exportgroupid,
    ['tab' => 'submissions']
));

$groupid = 0;

try {
    if ($exportall) {
        $groupid = 0;
    } else {
        $groupid = userstatement_resolve_bulk_export_groupid(
            $page->cm,
            $page->course,
            (int) $USER->id,
            false,
            $groupparam
        );
    }

    $exportid = bulk_export_service::create_job(
        (int) $page->instance->id,
        (int) $USER->id,
        $groupid
    );
} catch (moodle_exception $e) {
    redirect($returnurl, $e->getMessage(), null, \core\output\notification::NOTIFY_ERROR);
}

redirect(new moodle_url('/mod/userstatement/export_bulk_run.php', ['exportid' => $exportid]));
