<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

require_sesskey();

$cm = get_coursemodule_from_id('userstatement', $id, 0, false, MUST_EXIST);
$course = get_course($cm->course);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);

require_capability('mod/userstatement:viewall', $context);

$instance = $DB->get_record('userstatement', ['id' => $cm->instance], '*', MUST_EXIST);

if (!class_exists('ZipArchive')) {
    throw new moodle_exception('noziparchive', 'userstatement');
}

require_once($CFG->dirroot . '/group/lib.php');
$exportgroupid = userstatement_normalize_export_groupid($cm, $course, $USER->id);

userstatement_raise_export_limits();

$gjs = userstatement_submissions_group_join_sql($exportgroupid);
$sql = "SELECT s.*
          FROM {userstatement_submission} s
               {$gjs['join']}
         WHERE s.userstatement = :usid
      ORDER BY s.timemodified ASC";
$params = array_merge(['usid' => $instance->id], $gjs['params']);

$subs = $DB->get_records_sql($sql, $params);

$includeusername = userstatement_registry_export_includes_username();
\mod_userstatement\export\fields_xlsx::send_download($course, $subs, $includeusername);
