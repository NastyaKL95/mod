<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

require_sesskey();

$cm = get_coursemodule_from_id('userstatement', $id, 0, false, MUST_EXIST);
$course = get_course($cm->course);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);

require_capability('mod/userstatement:viewall', $context);

$instance = $DB->get_record('userstatement', ['id' => $cm->instance], '*', MUST_EXIST);

if (!class_exists('ZipArchive')) {
    throw new moodle_exception('noziparchive', 'userstatement');
}

require_once($CFG->dirroot . '/group/lib.php');
$exportgroupid = userstatement_normalize_export_groupid($cm, $course, $USER->id);

userstatement_raise_export_limits();

$gjs = userstatement_submissions_group_join_sql($exportgroupid);
$sql = "SELECT s.*
          FROM {userstatement_submission} s
               {$gjs['join']}
         WHERE s.userstatement = :usid
      ORDER BY s.timemodified ASC";
$params = array_merge(['usid' => $instance->id], $gjs['params']);

$subs = $DB->get_records_sql($sql, $params);

$subcount = count($subs);
$maxzip = userstatement_zip_pdf_limit();
if ($subcount > $maxzip) {
    throw new moodle_exception('exportziptoomany', 'userstatement', (object) [
        'max' => $maxzip,
        'count' => $subcount,
    ]);
}

$xlsxbytes = \mod_userstatement\export\registry_xlsx::generate_bytes($course, $subs);
$xlsxname = 'fis_frdo_' . clean_filename(format_string($course->shortname, true)) . '_'
    . userdate(time(), '%Y%m%d%H%M', 99, false) . '.xlsx';

$dir = make_temp_directory('userstatement');
$tmpzip = $dir . '/full_' . sha1(uniqid((string) mt_rand(), true)) . '.zip';

$zip = new ZipArchive();
$zipopened = false;
try {
    if ($zip->open($tmpzip, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new moodle_exception('exportwritefailed', 'userstatement');
    }
    $zipopened = true;

    $zip->addFromString($xlsxname, $xlsxbytes);
    unset($xlsxbytes);

    foreach ($subs as $sub) {
        $data = json_decode($sub->data);
        if (is_array($data)) {
            $data = (object) $data;
        }
        if (!is_object($data)) {
            continue;
        }
        $user = core_user::get_user((int) $sub->userid, '*', IGNORE_MISSING);
        if (!$user) {
            continue;
        }
        if (userstatement_validate_submission_for_save($data) !== '') {
            continue;
        }
        $pdfbytes = \mod_userstatement\statement_pdf::render_binary($instance, $user, $data);
        $pdfname = 'zayavlenie_' . (int) $user->id . '_' . clean_filename(userstatement_user_firstname($user)) . '.pdf';
        $zip->addFromString($pdfname, $pdfbytes);
        unset($pdfbytes, $user, $data);
        if (function_exists('gc_collect_cycles')) {
            gc_collect_cycles();
        }
    }

    if (!$zip->close()) {
        throw new moodle_exception('exportwritefailed', 'userstatement');
    }
    $zipopened = false;

    while (ob_get_level()) {
        ob_end_clean();
    }

    $zipfname = 'zayavleniya_' . clean_filename(format_string($course->shortname, true)) . '_'
        . userdate(time(), '%Y%m%d%H%M', 99, false) . '.zip';

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipfname . '"');
    header('Content-Length: ' . filesize($tmpzip));
    header('Cache-Control: private, must-revalidate, pre-check=0, post-check=0, max-age=0');
    readfile($tmpzip);
} finally {
    if ($zipopened) {
        @$zip->close();
    }
    if (file_exists($tmpzip)) {
        @unlink($tmpzip);
    }
}
exit;
