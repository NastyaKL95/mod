<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

$id = required_param('id', PARAM_INT);

$course = $DB->get_record('course', ['id' => $id], '*', MUST_EXIST);
require_course_login($course);

$PAGE->set_url('/mod/userstatement/index.php', ['id' => $id]);
$PAGE->set_title(format_string($course->shortname) . ': ' . get_string('modulenameplural', 'userstatement'));
$PAGE->set_heading($course->fullname);
$PAGE->set_pagelayout('incourse');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('modulenameplural', 'userstatement'));

if (!$cms = get_coursemodules_in_course('userstatement', $course->id)) {
    echo $OUTPUT->notification(get_string('norecords', 'userstatement'), 'notifymessage');
} else {
    $table = new html_table();
    $table->head = [get_string('name'), get_string('intro')];
    $table->attributes['class'] = 'generaltable';
    foreach ($cms as $cm) {
        if (!$cm->uservisible) {
            continue;
        }
        $inst = $DB->get_record('userstatement', ['id' => $cm->instance], 'id,name,intro', MUST_EXIST);
        $link = html_writer::link(new moodle_url('/mod/userstatement/view.php', ['id' => $cm->id]), format_string($inst->name));
        $intro = format_string($inst->intro);
        $table->data[] = [$link, $intro];
    }
    if (empty($table->data)) {
        echo $OUTPUT->notification(get_string('norecords', 'userstatement'), 'notifymessage');
    } else {
        echo html_writer::table($table);
    }
}

echo $OUTPUT->footer();
