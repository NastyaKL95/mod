<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/course/moodleform_mod.php');

/**
 * Настройки элемента курса «Заявление».
 */
class mod_userstatement_mod_form extends moodleform_mod {

    /**
     * Форма создания/редактирования модуля.
     */
    public function definition() {
        global $CFG;
        $mform = $this->_form;

        $mform->addElement('header', 'generalhdr', get_string('general', 'form'));
        $mform->addElement('text', 'name', get_string('modulename', 'userstatement'), ['size' => 64]);
        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('name', PARAM_TEXT);
        } else {
            $mform->setType('name', PARAM_CLEANHTML);
        }
        $mform->addRule('name', null, 'required', null, 'client');

        $this->standard_intro_elements();

        $course = $this->get_course();
        $coursename = format_string($course->fullname);

        $mform->addElement('header', 'hdr_letter', get_string('settings_letter', 'userstatement'));
        $mform->addElement('textarea', 'addressee', get_string('field_addressee', 'userstatement'),
            ['rows' => 4, 'cols' => 60]);
        $mform->setType('addressee', PARAM_RAW);
        $mform->addHelpButton('addressee', 'field_addressee', 'userstatement');

        $mform->addElement('static', 'programfromcourse', get_string('field_programname', 'userstatement'),
            get_string('programfromcourse_static', 'userstatement', (object) ['coursename' => $coursename]));
        $mform->addHelpButton('programfromcourse', 'field_programname', 'userstatement');

        $mform->addElement('date_selector', 'coursestart', get_string('field_coursestart', 'userstatement'),
            ['optional' => true]);
        $mform->addHelpButton('coursestart', 'field_coursestart', 'userstatement');

        $mform->addElement('textarea', 'institutename', get_string('field_institutename', 'userstatement'),
            ['rows' => 3, 'cols' => 60]);
        $mform->setType('institutename', PARAM_RAW);

        $mform->addElement('text', 'courseleader', get_string('field_courseleader', 'userstatement'),
            ['size' => 80, 'maxlength' => 255]);
        $mform->setType('courseleader', PARAM_TEXT);

        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }

    /**
     * Значения по умолчанию для нового элемента.
     *
     * @param array $defaultvalues
     */
    public function data_preprocessing(&$defaultvalues) {
        parent::data_preprocessing($defaultvalues);

        if (empty($defaultvalues['addressee'])) {
            $defaultvalues['addressee'] = get_string('default_addressee', 'userstatement');
        }
        if (empty($defaultvalues['institutename'])) {
            $defaultvalues['institutename'] = get_string('default_institutename', 'userstatement');
        }
        if (!isset($defaultvalues['courseleader'])) {
            $defaultvalues['courseleader'] = '';
        }

        if (!empty($defaultvalues['coursestart']) && is_numeric($defaultvalues['coursestart'])) {
            $t = (int) $defaultvalues['coursestart'];
            if ($t > 0) {
                $defaultvalues['coursestart'] = [
                    'enabled' => 1,
                    'day' => (int) userdate($t, '%d', 99, false),
                    'month' => (int) userdate($t, '%m', 99, false),
                    'year' => (int) userdate($t, '%Y', 99, false),
                ];
            }
        } else if (empty($defaultvalues['coursestart'])) {
            $course = $this->get_course();
            if (!empty($course->startdate)) {
                $t = (int) $course->startdate;
                $defaultvalues['coursestart'] = [
                    'enabled' => 1,
                    'day' => (int) userdate($t, '%d', 99, false),
                    'month' => (int) userdate($t, '%m', 99, false),
                    'year' => (int) userdate($t, '%Y', 99, false),
                ];
            }
        } else if (is_array($defaultvalues['coursestart'])) {
            $cs = $defaultvalues['coursestart'];
            $hasdate = !empty($cs['year']) && !empty($cs['month']) && !empty($cs['day']);
            if ($hasdate && empty($cs['enabled'])) {
                $defaultvalues['coursestart']['enabled'] = 1;
            }
        }
    }

    /**
     * Суффикс полей завершения в Moodle 4+; в 3.8 поля без суффикса.
     *
     * @return string
     */
    protected function completion_field_suffix() {
        if (method_exists($this, 'get_suffix')) {
            return (string) $this->get_suffix();
        }
        return '';
    }

    /**
     * @return string
     */
    protected function completion_verified_element_name() {
        return 'completionverified' . $this->completion_field_suffix();
    }

    /**
     * @return array
     */
    public function add_completion_rules() {
        $mform = $this->_form;
        $element = $this->completion_verified_element_name();
        $mform->addElement('checkbox', $element, '', get_string('completionverified', 'userstatement'));
        $mform->setDefault($element, 1);
        return [$element];
    }

    /**
     * @param array $data
     * @return bool
     */
    public function completion_rule_enabled($data) {
        $element = $this->completion_verified_element_name();
        return !empty($data[$element]);
    }

    /**
     * @param \stdClass $data
     */
    public function data_postprocessing($data) {
        parent::data_postprocessing($data);
        if (empty($data->completionunlocked)) {
            return;
        }
        $suffix = $this->completion_field_suffix();
        $completionfield = 'completion' . $suffix;
        $verifiedfield = $this->completion_verified_element_name();
        $completion = isset($data->{$completionfield}) ? $data->{$completionfield} : ($data->completion ?? null);
        $autocompletion = !empty($completion) && (int) $completion === COMPLETION_TRACKING_AUTOMATIC;
        if (!$autocompletion || empty($data->{$verifiedfield})) {
            $data->{$verifiedfield} = 0;
        }
    }
}
