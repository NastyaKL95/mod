<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_userstatement\local\view_page;

$id = required_param('id', PARAM_INT);

$page = view_page::from_cm_id($id);

global $PAGE, $USER, $DB, $OUTPUT, $CFG;

$PAGE->set_url($page->url_submit());

if (!$page->cansubmit || ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    redirect($page->url_view(['tab' => 'form']));
}

if (!$page->canviewall) {
    $earlyown = $page->get_own_submission();
    if ($earlyown && userstatement_submission_is_locked_payload($earlyown->data)) {
        redirect(
            $page->url_view(['tab' => 'form']),
            get_string('alreadysubmitted', 'userstatement'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }
}

require_once($CFG->dirroot . '/user/profile/lib.php');
$user = $USER;
profile_load_data($user);

$statementform = new \mod_userstatement\form\statement_form($page->url_submit(), ['user' => $user]);

if ($statementform->is_cancelled()) {
    redirect(course_get_url($page->course->id));
}

if ($data = $statementform->get_data()) {
    require_sesskey();
    $vkey = userstatement_validate_submission_for_save($data);
    if ($vkey !== '') {
        redirect(
            $page->url_view(['tab' => 'form']),
            get_string($vkey, 'userstatement'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }
    $payload = userstatement_serialize_submission($data);
    $now = time();
    $existing = $page->get_own_submission();

    if (!$page->canviewall && $existing && userstatement_submission_is_locked_payload($existing->data)) {
        redirect(
            $page->url_view(['tab' => 'form']),
            get_string('alreadysubmitted', 'userstatement'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }

    $rec = (object) [
        'userstatement' => $page->instance->id,
        'userid' => $USER->id,
        'data' => $payload,
        'timemodified' => $now,
        'verified' => 0,
        'verifiedby' => 0,
        'verifiedtime' => 0,
    ];
    if ($existing) {
        $rec->id = $existing->id;
        $rec->timecreated = $existing->timecreated;
        $DB->update_record('userstatement_submission', $rec);
    } else {
        $rec->timecreated = $now;
        $DB->insert_record('userstatement_submission', $rec);
    }

    userstatement_sync_completion_for_user($page->cm, $page->course, (int) $USER->id, false);

    redirect(
        $page->url_view(['saved' => 1, 'tab' => 'form']),
        get_string('applicationsaved', 'userstatement'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($statementform->is_submitted()) {
    $PAGE->set_title(format_string($page->instance->name));
    $PAGE->set_heading($page->course->fullname);
    $PAGE->set_pagelayout('incourse');
    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('formheading', 'userstatement'), 3);
    echo $OUTPUT->notification(get_string('formhaserrors', 'userstatement'), 'notifyproblem');
    if (!userstatement_instance_has_visible_intro($page->instance)) {
        echo $OUTPUT->box(get_string('intro', 'userstatement'), 'generalbox mod_introbox', 'userstatementintro');
    }
    $statementform->display();
    echo $OUTPUT->footer();
    exit;
}

redirect($page->url_view(['tab' => 'form']));
