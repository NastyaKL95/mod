<?php
// This file is part of Moodle - http://moodle.org/

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

use mod_userstatement\local\view_page;

$id = required_param('id', PARAM_INT);

$page = view_page::from_cm_id($id);

global $OUTPUT, $USER, $CFG, $PAGE;

$currenttab = $page->resolve_tab(optional_param('tab', '', PARAM_ALPHA));
$search = trim(optional_param('search', '', PARAM_TEXT));
$verifiedfilter = userstatement_normalize_verified_filter(optional_param('verifiedfilter', -1, PARAM_INT));
$sort = userstatement_normalize_submissions_sort(optional_param('sort', 'timemodified', PARAM_ALPHA));
$sortdir = userstatement_normalize_submissions_sortdir(optional_param('sortdir', 'desc', PARAM_ALPHA));
$pageindex = optional_param('page', 0, PARAM_INT);
$perpage = userstatement_submissions_per_page();
$justsaved = optional_param('saved', 0, PARAM_INT);

$urlopts = userstatement_submissions_list_url_extra($search, $verifiedfilter, $pageindex, $sort, $sortdir);
$urlopts['tab'] = $currenttab;
$page->set_page_url_view();
$PAGE->set_url($page->url_view($urlopts));

$ownsubmission = $page->get_own_submission();
$listenerlocked = $page->is_listener_locked();

$PAGE->set_title(format_string($page->instance->name));
$PAGE->set_heading($page->course->fullname);

if (method_exists($PAGE, 'set_secondary_active_tab')) {
    if ($page->canviewall && $page->cansubmit) {
        $PAGE->set_secondary_active_tab($currenttab === 'form' ? 'userstatementsubmissions' : 'modulepage');
    } else {
        $PAGE->set_secondary_active_tab('modulepage');
    }
}

echo $OUTPUT->header();

if ($page->has_multiple_tabs() && !method_exists($PAGE, 'set_secondary_active_tab')) {
    $tabs = [
        new tabobject('submissions', $page->url_view(['tab' => 'submissions']), get_string('tab_submissions', 'userstatement')),
        new tabobject('form', $page->url_view(['tab' => 'form']), get_string('tab_form', 'userstatement')),
    ];
    echo $OUTPUT->tabtree($tabs, $currenttab);
}

if ($currenttab === 'submissions' && $page->canviewall) {
    userstatement_statement_form_layout_init();
    echo $OUTPUT->heading(get_string('submissionsheading', 'userstatement'), 3, 'userstatement-submissions-heading');

    if (groups_get_activity_groupmode($page->cm, $page->course)) {
        echo html_writer::start_div('mb-2');
        groups_print_activity_menu($page->cm, $PAGE->url);
        echo html_writer::end_div();
    }

    userstatement_render_submissions_filter_block($page, $search, $verifiedfilter, $sort, $sortdir);
    userstatement_render_submissions_download_block($page);
    userstatement_render_bulk_export_panel($page);

    $total = $page->count_submissions($search, $verifiedfilter);
    if ($total === 0) {
        $msg = ($search !== '' || $verifiedfilter >= 0) ? 'nosubmissionsfilter' : 'nosubmissions';
        echo $OUTPUT->notification(get_string($msg, 'userstatement'), 'notifymessage');
    } else {
        $subs = $page->get_submissions_page($search, $pageindex, $perpage, $verifiedfilter, $sort, $sortdir);
        $table = new html_table();
        $table->head = [
            get_string('field_firstname', 'userstatement'),
            get_string('email'),
            get_string('field_phone', 'userstatement'),
            get_string('field_workplace', 'userstatement'),
            userstatement_submissions_sort_header($page, 'timemodified', get_string('lastmodified'), $search, $verifiedfilter, $sort, $sortdir),
            userstatement_submissions_sort_header($page, 'verified', get_string('verified', 'userstatement'), $search, $verifiedfilter, $sort, $sortdir),
            get_string('download'),
            get_string('deletesubmission', 'userstatement'),
        ];
        $table->attributes['class'] = 'generaltable';
        foreach ($subs as $s) {
            $name = userstatement_user_firstname($s);
            $dlurl = $page->url_download((int) $s->userid);
            $delurl = $page->url_delete((int) $s->userid);
            $dlacc = get_string('downloadpdfuser', 'userstatement', $name);
            $delacc = get_string('deletesubmissionuser', 'userstatement', $name);
            $iscomplete = userstatement_submission_is_locked_payload($s->data);
            $isverified = userstatement_submission_is_verified($s);
            $verifiedcell = html_writer::start_tag('form', [
                'method' => 'post',
                'action' => (new moodle_url('/mod/userstatement/toggle_verified.php'))->out(false),
                'class' => 'userstatement-verified-form',
                'style' => 'margin:0;',
            ]);
            $verifiedcell .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'sesskey',
                'value' => sesskey(),
            ]);
            $verifiedcell .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'id',
                'value' => $page->cm->id,
            ]);
            $verifiedcell .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'userid',
                'value' => (int) $s->userid,
            ]);
            $verifiedcell .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'verified',
                'value' => $isverified ? 1 : 0,
                'class' => 'userstatement-verified-value',
            ]);
            if ($search !== '') {
                $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'search', 'value' => s($search)]);
            }
            if ($verifiedfilter >= 0) {
                $verifiedcell .= html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'verifiedfilter',
                    'value' => $verifiedfilter,
                ]);
            }
            if ($pageindex > 0) {
                $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'page', 'value' => $pageindex]);
            }
            $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sort', 'value' => $sort]);
            $verifiedcell .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sortdir', 'value' => $sortdir]);
            if ($page->exportgroupid > 0) {
                $verifiedcell .= html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'group',
                    'value' => $page->exportgroupid,
                ]);
            }
            $cbattrs = [
                'type' => 'checkbox',
                'name' => 'verifiedtoggle',
                'value' => '1',
                'id' => 'verified-' . (int) $s->userid,
                'onchange' => 'var h=this.form.querySelector(".userstatement-verified-value");h.value=this.checked?1:0;this.form.submit();',
                'aria-label' => get_string('verified', 'userstatement') . ': ' . $name,
            ];
            if ($isverified) {
                $cbattrs['checked'] = 'checked';
            }
            if (!$iscomplete) {
                $cbattrs['disabled'] = 'disabled';
                $cbattrs['title'] = get_string('verifiedrequirescomplete', 'userstatement');
            }
            $verifiedcell .= html_writer::empty_tag('input', $cbattrs);
            $verifiedcell .= html_writer::tag('label', get_string('verified', 'userstatement'), [
                'for' => 'verified-' . (int) $s->userid,
                'class' => 'ms-1',
            ]);
            $verifiedcell .= html_writer::end_tag('form');
            $phone = userstatement_submission_display_phone($s->data);
            $workplace = userstatement_submission_display_workplace($s->data);
            $table->data[] = [
                $name,
                s($s->email),
                $phone !== '' ? s($phone) : '—',
                $workplace !== '' ? s($workplace) : '—',
                userdate($s->timemodified),
                $verifiedcell,
                html_writer::link($dlurl, get_string('downloadpdf', 'userstatement'), [
                    'title' => $dlacc,
                    'aria-label' => $dlacc,
                ]),
                html_writer::link($delurl, get_string('deletesubmission', 'userstatement'), [
                    'title' => $delacc,
                    'aria-label' => $delacc,
                ]),
            ];
        }
        echo html_writer::table($table);

        echo $OUTPUT->paging_bar(
            $total,
            $pageindex,
            $perpage,
            $page->url_view(userstatement_submissions_list_url_extra($search, $verifiedfilter, 0, $sort, $sortdir))
        );
    }

} else if ($currenttab === 'form' && $page->cansubmit) {
    echo $OUTPUT->heading(get_string('formheading', 'userstatement'), 3);

    $completiontracking = !empty($page->cm->completion) && (int) $page->cm->completion !== COMPLETION_TRACKING_NONE;

    if ($listenerlocked) {
        if ($justsaved) {
            echo $OUTPUT->box(get_string('applicationsaved_detail', 'userstatement'), 'generalbox');
        } else {
            echo $OUTPUT->notification(get_string('statementsubmittedlocked', 'userstatement'), 'notifysuccess');
        }
        if ($ownsubmission && userstatement_submission_is_verified($ownsubmission)) {
            if (!$completiontracking) {
                echo $OUTPUT->notification(get_string('applicationverified', 'userstatement'), 'notifysuccess');
            }
        } else if ($ownsubmission) {
            echo $OUTPUT->notification(get_string('completionrequiresverified', 'userstatement'), 'notifymessage');
        }
        $dlown = $page->url_download(0);
        $courseurl = course_get_url($page->course);
        echo html_writer::start_div('', ['style' => 'margin-top:0.75em;']);
        echo $OUTPUT->single_button($dlown, get_string('downloadpdf', 'userstatement'), 'get');
        echo ' ';
        echo $OUTPUT->single_button($courseurl, get_string('returntocourse', 'userstatement'), 'get');
        echo html_writer::end_div();
    } else {
        require_once($CFG->dirroot . '/user/profile/lib.php');
        $user = $USER;
        profile_load_data($user);

        $statementform = new \mod_userstatement\form\statement_form($page->url_submit(), ['user' => $user]);

        if ($ownsubmission && $ownsubmission->data) {
            $decoded = json_decode($ownsubmission->data, true);
            if (is_array($decoded)) {
                $statementform->set_data((object) $decoded);
            }
        } else if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            $statementform->set_data((object) [
                'phone' => $user->phone1 ?? '',
                'gender' => 'female',
                'birthdate' => userstatement_date_to_form_group_value(null, 'birthdate'),
                'diploma_date' => userstatement_date_to_form_group_value(null, 'diploma_date'),
            ]);
        }

        // Описание элемента выводит Moodle в шапке активности; здесь — только запасной текст, если описание пустое.
        if (!userstatement_instance_has_visible_intro($page->instance)) {
            echo $OUTPUT->box(get_string('intro', 'userstatement'), 'generalbox mod_introbox', 'userstatementintro');
        }
        $statementform->display();
    }

} else if (!$page->canviewall && !$page->cansubmit) {
    echo $OUTPUT->notification(get_string('noaccess', 'userstatement'), 'notifyproblem');
}

echo $OUTPUT->footer();
